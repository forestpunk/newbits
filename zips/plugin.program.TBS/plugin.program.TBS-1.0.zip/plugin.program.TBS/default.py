import urllib , urllib2 , re , xbmcplugin , xbmcgui , xbmc , xbmcaddon , os , sys , time , xbmcvfs , glob , shutil , subprocess , datetime , threading , zipfile , ntpath
import extract , downloader , yt
try :
 from sqlite3 import dbapi2 as database
except :
 from pysqlite2 import dbapi2 as database
from addon . common . addon import Addon
from addon . common . net import Net
if 64 - 64: i11iIiiIii
OO0o = 'http://totalxbmc.tv/totalrevolution/art/' + os . sep
Oo0Ooo = xbmcaddon . Addon ( id = 'plugin.program.TBS' )
O0O0OO0O0O0 = 'plugin.program.TBS'
iiiii = "[COLOR=blue]T[/COLOR]otal[COLOR=dodgerblue]R[/COLOR]evolution"
zip = Oo0Ooo . getSetting ( 'zip' )
ooo0OO = Oo0Ooo . getSetting ( 'localcopy' )
II1 = Oo0Ooo . getSetting ( 'private' )
O00ooooo00 = Oo0Ooo . getSetting ( 'reseller' )
I1IiiI = Oo0Ooo . getSetting ( 'resellername' )
IIi1IiiiI1Ii = Oo0Ooo . getSetting ( 'resellerid' )
I11i11Ii = Oo0Ooo . getSetting ( 'mastercopy' )
oO00oOo = Oo0Ooo . getSetting ( 'username' )
OOOo0 = Oo0Ooo . getSetting ( 'password' )
Oooo000o = Oo0Ooo . getSetting ( 'login' )
IiIi11iIIi1Ii = Oo0Ooo . getSetting ( 'trcheck' )
Oo0O = xbmcgui . Dialog ( )
IiI = xbmcgui . DialogProgress ( )
ooOo = xbmc . translatePath ( 'special://home/' )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/media' , '' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( Oo , 'autoexec.py' ) )
IiII = xbmc . translatePath ( os . path . join ( Oo , 'autoexec_bak.py' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( Oo , 'addon_data' ) )
i1i1II = xbmc . translatePath ( os . path . join ( Oo , 'playlists' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( Oo , 'Database' ) )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( Oo , 'Thumbnails' ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
o0oO0 = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , O0O0OO0O0O0 , 'default.py' ) )
oo00 = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , O0O0OO0O0O0 , 'fanart.jpg' ) )
o00 = os . path . join ( Oo , 'guisettings.xml' )
Oo0oO0ooo = xbmc . translatePath ( os . path . join ( Oo , 'guisettings.xml' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( Oo , 'guifix.xml' ) )
i1 = xbmc . translatePath ( os . path . join ( Oo , 'install.xml' ) )
oOOoo00O0O = xbmc . translatePath ( os . path . join ( Oo , 'favourites.xml' ) )
i1111 = xbmc . translatePath ( os . path . join ( Oo , 'sources.xml' ) )
i11 = xbmc . translatePath ( os . path . join ( Oo , 'advancedsettings.xml' ) )
I11 = xbmc . translatePath ( os . path . join ( Oo , 'profiles.xml' ) )
Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( Oo , 'RssFeeds.xml' ) )
oOo0oooo00o = xbmc . translatePath ( os . path . join ( Oo , 'keymaps' , 'keyboard.xml' ) )
oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( zip ) )
oo0o0O00 = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Community Builds' , '' ) )
oO = xbmc . translatePath ( os . path . join ( iI1Ii11111iIi , O0O0OO0O0O0 , 'cookiejar' ) )
i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( iI1Ii11111iIi , O0O0OO0O0O0 , 'startup.xml' ) )
oooOOOOO = xbmc . translatePath ( os . path . join ( iI1Ii11111iIi , O0O0OO0O0O0 , 'temp.xml' ) )
i1iiIII111ii = xbmc . translatePath ( os . path . join ( iI1Ii11111iIi , O0O0OO0O0O0 , 'id.xml' ) )
i1iIIi1 = xbmc . translatePath ( os . path . join ( iI1Ii11111iIi , O0O0OO0O0O0 , 'idtemp.xml' ) )
ii11iIi1I = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , O0O0OO0O0O0 , 'resources/' ) )
iI111I11I1I1 = xbmc . getSkinDir ( )
OOooO0OOoo = xbmc . translatePath ( 'special://logpath/' )
iIii1 = Net ( )
oOOoO0 = xbmc . translatePath ( os . path . join ( iI1Ii11111iIi , O0O0OO0O0O0 ) )
O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oOOoO0 , 'guinew.xml' ) )
iiI1IiI = xbmc . translatePath ( os . path . join ( oOOoO0 , 'guitemp' , '' ) )
II = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Database' ) )
ooOoOoo0O = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
OooO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
II11iiii1Ii = 'None'
OO0oOoo = 0.0
O0o0Oo = 0.0
if 78 - 78: IIIIII11i1I - o0o0OOO0o0 % IIII % o0O0 . ii1I11II1ii1i % oO0o0ooo
#-----------------------------------------------------------------------------------------------------------------    
#Popup class - thanks to whoever codes the help popup in TVAddons Maintenance for this section. Unfortunately there doesn't appear to be any author details in that code so unable to credit by name.
class i1iiI11I ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) : self . shut = kwargs [ 'close_time' ] ; xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" ) ; xbmc . executebuiltin ( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
 def onFocus ( self , controlID ) : pass
 def onClick ( self , controlID ) :
  if controlID == 12 : xbmc . Player ( ) . stop ( ) ; self . _close_dialog ( )
 def onAction ( self , action ) :
  if action in [ 5 , 6 , 7 , 9 , 10 , 92 , 117 ] or action . getButtonCode ( ) in [ 275 , 257 , 261 ] : xbmc . Player ( ) . stop ( ) ; self . _close_dialog ( )
 def _close_dialog ( self ) :
  xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" ) ; time . sleep ( .4 ) ; self . close ( )
  if 29 - 29: iiIi
def Oo0O0OOOoo ( numblocks , blocksize , filesize , dp , start_time ) :
 if 95 - 95: iiiIi1i1I % II11iII % OoOo
 global OO0oOoo
 global O0o0Oo
 if 18 - 18: iii11I111
 try :
  OOOO00ooo0Ooo = min ( numblocks * blocksize * 100 / filesize , 100 )
  O0o0Oo = float ( numblocks ) * blocksize
  OOOooOooo00O0 = O0o0Oo / ( 1024 * 1024 )
  Oo0OO = O0o0Oo / ( time . time ( ) - start_time )
  if Oo0OO > 0 :
   oOOoOo00o = ( filesize - numblocks * blocksize ) / Oo0OO
   if Oo0OO > OO0oOoo : OO0oOoo = Oo0OO
  else :
   oOOoOo00o = 0
  o0OOoo0OO0OOO = Oo0OO * 8 / 1024
  iI1iI1I1i1I = o0OOoo0OO0OOO / 1024
  iIi11Ii1 = float ( filesize ) / ( 1024 * 1024 )
  Ii11iII1 = '%.02f MB of %.02f MB' % ( OOOooOooo00O0 , iIi11Ii1 )
  Oo0O0O0ooO0O = 'Speed: %.02f Mb/s ' % iI1iI1I1i1I
  Oo0O0O0ooO0O += 'ETA: %02d:%02d' % divmod ( oOOoOo00o , 60 )
  dp . update ( OOOO00ooo0Ooo , Ii11iII1 , Oo0O0O0ooO0O )
 except :
  O0o0Oo = float ( filesize )
  OOOO00ooo0Ooo = 100
  dp . update ( OOOO00ooo0Ooo )
 if dp . iscanceled ( ) :
  dp . close ( )
  raise Exception ( "Cancelled" )
  if 15 - 15: Ooo0Oo0 + OOO00OoOO00 . oOOoO0O0O0 + Oo000o
  if 7 - 7: OoO0O00 * ooOO0o . O0oO . i1OOO
def Oo0oOOo ( name , url , mode , iconimage , fanart , video , description , skins , guisettingslink , artpack ) :
 Oo0OoO00oOO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&video=" + urllib . quote_plus ( video ) + "&description=" + urllib . quote_plus ( description ) + "&skins=" + urllib . quote_plus ( skins ) + "&guisettingslink=" + urllib . quote_plus ( guisettingslink ) + "&artpack=" + urllib . quote_plus ( artpack )
 OOO00O = True
 OOoOO0oo0ooO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOoOO0oo0ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 OOoOO0oo0ooO . setProperty ( "Fanart_Image" , fanart )
 OOoOO0oo0ooO . setProperty ( "Build.Video" , video )
 if ( mode == None ) or ( mode == 'restore_option' ) or ( mode == 'backup_option' ) or ( mode == 'cb_root_menu' ) or ( mode == 'genres' ) or ( mode == 'grab_builds' ) or ( mode == 'community_menu' ) or ( mode == 'instructions' ) or ( mode == 'countries' ) or ( url == None ) or ( len ( url ) < 1 ) :
  OOO00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo0OoO00oOO0o , listitem = OOoOO0oo0ooO , isFolder = True )
 else :
  OOO00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo0OoO00oOO0o , listitem = OOoOO0oo0ooO , isFolder = False )
 return OOO00O
 if 98 - 98: OoO0O00 * OoO0O00 / OoO0O00 + oOOoO0O0O0
 if 34 - 34: i1OOO
def I1111I1iII11 ( handle , url , listitem , isFolder ) :
 xbmcplugin . addDirectoryItem ( handle , url , listitem , isFolder )
 if 59 - 59: o0o0OOO0o0 * i11iIiiIii / iii11I111 * o0O0 * IIIIII11i1I
 if 83 - 83: iiiIi1i1I / O0oO . II11iII / ooOO0o . II11iII . OOO00OoOO00
def O0oOoOO ( name , url , mode , iconimage , fanart , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 iconimage = OO0o + iconimage
 Oo0OoO00oOO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&author=" + urllib . quote_plus ( author ) + "&description=" + urllib . quote_plus ( description ) + "&version=" + urllib . quote_plus ( version ) + "&buildname=" + urllib . quote_plus ( buildname ) + "&updated=" + urllib . quote_plus ( updated ) + "&skins=" + urllib . quote_plus ( skins ) + "&videoaddons=" + urllib . quote_plus ( videoaddons ) + "&audioaddons=" + urllib . quote_plus ( audioaddons ) + "&buildname=" + urllib . quote_plus ( buildname ) + "&programaddons=" + urllib . quote_plus ( programaddons ) + "&pictureaddons=" + urllib . quote_plus ( pictureaddons ) + "&sources=" + urllib . quote_plus ( sources ) + "&adult=" + urllib . quote_plus ( adult )
 OOO00O = True
 OOoOO0oo0ooO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOoOO0oo0ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 OOoOO0oo0ooO . setProperty ( "Fanart_Image" , fanart )
 OOoOO0oo0ooO . setProperty ( "Build.Video" , oO00o0 )
 OOO00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo0OoO00oOO0o , listitem = OOoOO0oo0ooO , isFolder = False )
 return OOO00O
 if 55 - 55: iiIi + o0o0OOO0o0 / II11iII * Ooo0Oo0 - i11iIiiIii - Oo000o
def ii1ii1ii ( title , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' , zip_link = '' , repo_link = '' , repo_id = '' , addon_id = '' , provider_name = '' , forum = '' , data_path = '' ) :
 if len ( iconimage ) > 0 :
  iconimage = OO0o + iconimage
 else :
  iconimage = 'DefaultFolder.png'
 if fanart == '' :
  fanart = oo00
 Oo0OoO00oOO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&zip_link=" + urllib . quote_plus ( zip_link ) + "&repo_link=" + urllib . quote_plus ( repo_link ) + "&data_path=" + urllib . quote_plus ( data_path ) + "&provider_name=" + str ( provider_name ) + "&forum=" + str ( forum ) + "&repo_id=" + str ( repo_id ) + "&addon_id=" + str ( addon_id ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&video=" + urllib . quote_plus ( video ) + "&description=" + urllib . quote_plus ( description )
 OOO00O = True
 OOoOO0oo0ooO = xbmcgui . ListItem ( title , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOoOO0oo0ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 OOoOO0oo0ooO . setProperty ( "Fanart_Image" , fanart )
 OOoOO0oo0ooO . setProperty ( "Build.Video" , video )
 I1111I1iII11 ( handle = int ( sys . argv [ 1 ] ) , url = Oo0OoO00oOO0o , listitem = OOoOO0oo0ooO , isFolder = False )
 if 91 - 91: ooOO0o
 if 15 - 15: ii1I11II1ii1i
def Ii ( type , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' ) :
 if type != 'folder2' and type != 'addon' :
  if len ( iconimage ) > 0 :
   iconimage = OO0o + iconimage
  else :
   iconimage = 'DefaultFolder.png'
 if type == 'addon' :
  if len ( iconimage ) > 0 :
   iconimage = iconimage
  else :
   iconimage = 'http://totalxbmc.tv/addons/cache/images/4c79319887e240789ca125f144d989_addon-dummy.png'
 if fanart == '' :
  fanart = oo00
 Oo0OoO00oOO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&video=" + urllib . quote_plus ( video ) + "&description=" + urllib . quote_plus ( description )
 OOO00O = True
 OOoOO0oo0ooO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOoOO0oo0ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 OOoOO0oo0ooO . setProperty ( "Fanart_Image" , fanart )
 OOoOO0oo0ooO . setProperty ( "Build.Video" , video )
 if ( type == 'folder' ) or ( type == 'folder2' ) or ( type == 'tutorial_folder' ) or ( type == 'news_folder' ) :
  OOO00O = I1111I1iII11 ( handle = int ( sys . argv [ 1 ] ) , url = Oo0OoO00oOO0o , listitem = OOoOO0oo0ooO , isFolder = True )
 else :
  OOO00O = I1111I1iII11 ( handle = int ( sys . argv [ 1 ] ) , url = Oo0OoO00oOO0o , listitem = OOoOO0oo0ooO , isFolder = False )
 return OOO00O
 if 79 - 79: IIII / IIIIII11i1I
 if 75 - 75: II11iII % OoOo % OoOo . O0oO
def III1iII1I1ii ( ) :
 Ii ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Audio' , '&typex=audio' , 'grab_addons' , 'audio.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Image (Picture)' , '&typex=image' , 'grab_addons' , 'pictures.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Program' , '&typex=program' , 'grab_addons' , 'programs.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Video' , '&typex=video' , 'grab_addons' , 'video.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Movies (Used for library scanning)' , '&typex=movie%20scraper' , 'grab_addons' , 'movies.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] TV Shows (Used for library scanning)' , '&typex=tv%20show%20scraper' , 'grab_addons' , 'tvshows.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Artists (Used for library scanning)' , '&typex=artist%20scraper' , 'grab_addons' , 'artists.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Videos (Used for library scanning)' , '&typex=music%20video%20scraper' , 'grab_addons' , 'musicvideos.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] All Services' , '&typex=service' , 'grab_addons' , 'services.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] Weather Service' , '&typex=weather' , 'grab_addons' , 'weather.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Repositories' , '&typex=repository' , 'grab_addons' , 'repositories.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Scripts (Program Add-ons)' , '&typex=executable' , 'grab_addons' , 'scripts.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Screensavers' , '&typex=screensaver' , 'grab_addons' , 'screensaver.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Script Modules' , '&typex=script%20module' , 'grab_addons' , 'scriptmodules.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Skins' , '&typex=skin' , 'grab_addons' , 'skins.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Subtitles' , '&typex=subtitles' , 'grab_addons' , 'subtitles.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Web Interface' , '&typex=web%20interface' , 'grab_addons' , 'webinterface.png' , '' , '' , '' )
 if 61 - 61: ii1I11II1ii1i
 if 64 - 64: i1OOO / II11iII - IIIIII11i1I - oOOoO0O0O0
 if 86 - 86: oOOoO0O0O0 % II11iII / oO0o0ooo / II11iII
def iIIi1i1 ( ) :
 Ii ( 'folder' , 'African' , '&genre=african' , 'grab_addons' , 'african.png' , '' , '' , '' )
 Ii ( 'folder' , 'Arabic' , '&genre=arabic' , 'grab_addons' , 'arabic.png' , '' , '' , '' )
 Ii ( 'folder' , 'Asian' , '&genre=asian' , 'grab_addons' , 'asian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Australian' , '&genre=australian' , 'grab_addons' , 'australian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Austrian' , '&genre=austrian' , 'grab_addons' , 'austrian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Belgian' , '&genre=belgian' , 'grab_addons' , 'belgian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Brazilian' , '&genre=brazilian' , 'grab_addons' , 'brazilian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Canadian' , '&genre=canadian' , 'grab_addons' , 'canadian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Columbian' , '&genre=columbian' , 'grab_addons' , 'columbian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Czech' , '&genre=czech' , 'grab_addons' , 'czech.png' , '' , '' , '' )
 Ii ( 'folder' , 'Danish' , '&genre=danish' , 'grab_addons' , 'danish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Dominican' , '&genre=dominican' , 'grab_addons' , 'dominican.png' , '' , '' , '' )
 Ii ( 'folder' , 'Dutch' , '&genre=dutch' , 'grab_addons' , 'dutch.png' , '' , '' , '' )
 Ii ( 'folder' , 'Egyptian' , '&genre=egyptian' , 'grab_addons' , 'egyptian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Filipino' , '&genre=filipino' , 'grab_addons' , 'filipino.png' , '' , '' , '' )
 Ii ( 'folder' , 'Finnish' , '&genre=finnish' , 'grab_addons' , 'finnish.png' , '' , '' , '' )
 Ii ( 'folder' , 'French' , '&genre=french' , 'grab_addons' , 'french.png' , '' , '' , '' )
 Ii ( 'folder' , 'German' , '&genre=german' , 'grab_addons' , 'german.png' , '' , '' , '' )
 Ii ( 'folder' , 'Greek' , '&genre=greek' , 'grab_addons' , 'greek.png' , '' , '' , '' )
 Ii ( 'folder' , 'Hebrew' , '&genre=hebrew' , 'grab_addons' , 'hebrew.png' , '' , '' , '' )
 Ii ( 'folder' , 'Hungarian' , '&genre=hungarian' , 'grab_addons' , 'hungarian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Icelandic' , '&genre=icelandic' , 'grab_addons' , 'icelandic.png' , '' , '' , '' )
 Ii ( 'folder' , 'Indian' , '&genre=indian' , 'grab_addons' , 'indian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Irish' , '&genre=irish' , 'grab_addons' , 'irish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Italian' , '&genre=italian' , 'grab_addons' , 'italian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Japanese' , '&genre=japanese' , 'grab_addons' , 'japanese.png' , '' , '' , '' )
 Ii ( 'folder' , 'Korean' , '&genre=korean' , 'grab_addons' , 'korean.png' , '' , '' , '' )
 Ii ( 'folder' , 'Lebanese' , '&genre=lebanese' , 'grab_addons' , 'lebanese.png' , '' , '' , '' )
 Ii ( 'folder' , 'Mongolian' , '&genre=mongolian' , 'grab_addons' , 'mongolian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Nepali' , '&genre=nepali' , 'grab_addons' , 'nepali.png' , '' , '' , '' )
 Ii ( 'folder' , 'New Zealand' , '&genre=newzealand' , 'grab_addons' , 'newzealand.png' , '' , '' , '' )
 Ii ( 'folder' , 'Norwegian' , '&genre=norwegian' , 'grab_addons' , 'norwegian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Pakistani' , '&genre=pakistani' , 'grab_addons' , 'pakistani.png' , '' , '' , '' )
 Ii ( 'folder' , 'Polish' , '&genre=polish' , 'grab_addons' , 'polish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Portuguese' , '&genre=portuguese' , 'grab_addons' , 'portuguese.png' , '' , '' , '' )
 Ii ( 'folder' , 'Romanian' , '&genre=romanian' , 'grab_addons' , 'romanian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Russian' , '&genre=russian' , 'grab_addons' , 'russian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Singapore' , '&genre=singapore' , 'grab_addons' , 'singapore.png' , '' , '' , '' )
 Ii ( 'folder' , 'Spanish' , '&genre=spanish' , 'grab_addons' , 'spanish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Swedish' , '&genre=swedish' , 'grab_addons' , 'swedish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Swiss' , '&genre=swiss' , 'grab_addons' , 'swiss.png' , '' , '' , '' )
 Ii ( 'folder' , 'Syrian' , '&genre=syrian' , 'grab_addons' , 'syrian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Tamil' , '&genre=tamil' , 'grab_addons' , 'tamil.png' , '' , '' , '' )
 Ii ( 'folder' , 'Thai' , '&genre=thai' , 'grab_addons' , 'thai.png' , '' , '' , '' )
 Ii ( 'folder' , 'Turkish' , '&genre=turkish' , 'grab_addons' , 'turkish.png' , '' , '' , '' )
 Ii ( 'folder' , 'UK' , '&genre=uk' , 'grab_addons' , 'uk.png' , '' , '' , '' )
 Ii ( 'folder' , 'USA' , '&genre=usa' , 'grab_addons' , 'usa.png' , '' , '' , '' )
 Ii ( 'folder' , 'Vietnamese' , '&genre=vietnamese' , 'grab_addons' , 'vietnamese.png' , '' , '' , '' )
 if 10 - 10: oOOoO0O0O0
 if 82 - 82: iii11I111 - o0o0OOO0o0 / OOO00OoOO00 + Oo000o
def OOOOoOoo0O0O0 ( url ) :
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/AddonPortal/addondetails.php?id=%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iIi = re . compile ( 'name="(.+?)"' ) . findall ( IIiIi1iI )
 ooOOoooooo = re . compile ( 'UID="(.+?)"' ) . findall ( IIiIi1iI )
 II1I = re . compile ( 'id="(.+?)"' ) . findall ( IIiIi1iI )
 O0 = re . compile ( 'provider_name="(.+?)"' ) . findall ( IIiIi1iI )
 i1II1Iiii1I11 = re . compile ( 'version="(.+?)"' ) . findall ( IIiIi1iI )
 IIIIiiIiI = re . compile ( 'created="(.+?)"' ) . findall ( IIiIi1iI )
 o00oooO0Oo = re . compile ( 'addon_types="(.+?)"' ) . findall ( IIiIi1iI )
 o0O0OOO0Ooo = re . compile ( 'updated="(.+?)"' ) . findall ( IIiIi1iI )
 iiIiI = re . compile ( 'downloads="(.+?)"' ) . findall ( IIiIi1iI )
 if 6 - 6: ooOO0o . Ooo0Oo0 * II11iII - Oo000o - ooOO0o
 IiIiii1I1 = re . compile ( 'description="(.+?)"' ) . findall ( IIiIi1iI )
 oOOO = re . compile ( 'devbroke="(.+?)"' ) . findall ( IIiIi1iI )
 iIII1 = re . compile ( 'broken="(.+?)"' ) . findall ( IIiIi1iI )
 o0o = re . compile ( 'deleted="(.+?)"' ) . findall ( IIiIi1iI )
 O0OOoO00OO0o = re . compile ( 'mainbranch_notes="(.+?)"' ) . findall ( IIiIi1iI )
 if 38 - 38: OOO00OoOO00 % oOOoO0O0O0 % OoOo % iiiIi1i1I - iiIi
 i1Ii = re . compile ( 'repo_url="(.+?)"' ) . findall ( IIiIi1iI )
 ii111iI1iIi1 = re . compile ( 'data_url="(.+?)"' ) . findall ( IIiIi1iI )
 OOO = re . compile ( 'zip_url="(.+?)"' ) . findall ( IIiIi1iI )
 oo0OOo0 = re . compile ( 'genres="(.+?)"' ) . findall ( IIiIi1iI )
 I11IiI = re . compile ( 'forum="(.+?)"' ) . findall ( IIiIi1iI )
 O0ooO0Oo00o = re . compile ( 'repo_id="(.+?)"' ) . findall ( IIiIi1iI )
 ooO0oOOooOo0 = re . compile ( 'license="(.+?)"' ) . findall ( IIiIi1iI )
 i1I1ii11i1Iii = re . compile ( 'platform="(.+?)"' ) . findall ( IIiIi1iI )
 I1IiiiiI = re . compile ( 'visible="(.+?)"' ) . findall ( IIiIi1iI )
 o0OIiII = re . compile ( 'script="(.+?)"' ) . findall ( IIiIi1iI )
 ii1iII1II = re . compile ( 'program_plugin="(.+?)"' ) . findall ( IIiIi1iI )
 Iii1I1I11iiI1 = re . compile ( 'script_module="(.+?)"' ) . findall ( IIiIi1iI )
 I1I1i1I = re . compile ( 'video_plugin="(.+?)"' ) . findall ( IIiIi1iI )
 ii1I = re . compile ( 'audio_plugin="(.+?)"' ) . findall ( IIiIi1iI )
 O0oO0 = re . compile ( 'image_plugin="(.+?)"' ) . findall ( IIiIi1iI )
 oO0 = re . compile ( 'repository="(.+?)"' ) . findall ( IIiIi1iI )
 O0OO0O = re . compile ( 'weather_service="(.+?)"' ) . findall ( IIiIi1iI )
 OO = re . compile ( 'skin="(.+?)"' ) . findall ( IIiIi1iI )
 OoOoO = re . compile ( 'service="(.+?)"' ) . findall ( IIiIi1iI )
 Ii1I1i = re . compile ( 'warning="(.+?)"' ) . findall ( IIiIi1iI )
 OOI1iI1ii1II = re . compile ( 'web_interface="(.+?)"' ) . findall ( IIiIi1iI )
 O0O0OOOOoo = re . compile ( 'movie_scraper="(.+?)"' ) . findall ( IIiIi1iI )
 oOooO0 = re . compile ( 'tv_scraper="(.+?)"' ) . findall ( IIiIi1iI )
 Ii1I1Ii = re . compile ( 'artist_scraper="(.+?)"' ) . findall ( IIiIi1iI )
 OOoO0 = re . compile ( 'music_video_scraper="(.+?)"' ) . findall ( IIiIi1iI )
 OO0Oooo0oOO0O = re . compile ( 'subtitles="(.+?)"' ) . findall ( IIiIi1iI )
 o00O0 = re . compile ( 'requires="(.+?)"' ) . findall ( IIiIi1iI )
 oOO0O00Oo0O0o = re . compile ( 'modules="(.+?)"' ) . findall ( IIiIi1iI )
 ii1 = re . compile ( 'icon="(.+?)"' ) . findall ( IIiIi1iI )
 I1iIIiiIIi1i = re . compile ( 'video_preview="(.+?)"' ) . findall ( IIiIi1iI )
 O0O0ooOOO = re . compile ( 'video_guide="(.+?)"' ) . findall ( IIiIi1iI )
 oOOo0O00o = re . compile ( 'video_guide1="(.+?)"' ) . findall ( IIiIi1iI )
 iIiIi11 = re . compile ( 'video_guide2="(.+?)"' ) . findall ( IIiIi1iI )
 OOOiiiiI = re . compile ( 'video_guide3="(.+?)"' ) . findall ( IIiIi1iI )
 oooOo0OOOoo0 = re . compile ( 'video_guide4="(.+?)"' ) . findall ( IIiIi1iI )
 OOoO = re . compile ( 'video_guide5="(.+?)"' ) . findall ( IIiIi1iI )
 OO0O000 = re . compile ( 'video_guide6="(.+?)"' ) . findall ( IIiIi1iI )
 iiIiI1i1 = re . compile ( 'video_guide7="(.+?)"' ) . findall ( IIiIi1iI )
 oO0O00oOOoooO = re . compile ( 'video_guide8="(.+?)"' ) . findall ( IIiIi1iI )
 IiIi11iI = re . compile ( 'video_guide9="(.+?)"' ) . findall ( IIiIi1iI )
 Oo0O00O000 = re . compile ( 'video_guide10="(.+?)"' ) . findall ( IIiIi1iI )
 i11I1IiII1i1i = re . compile ( 'video_label1="(.+?)"' ) . findall ( IIiIi1iI )
 oo = re . compile ( 'video_label2="(.+?)"' ) . findall ( IIiIi1iI )
 I1111i = re . compile ( 'video_label3="(.+?)"' ) . findall ( IIiIi1iI )
 iIIii = re . compile ( 'video_label4="(.+?)"' ) . findall ( IIiIi1iI )
 o00O0O = re . compile ( 'video_label5="(.+?)"' ) . findall ( IIiIi1iI )
 ii1iii1i = re . compile ( 'video_label6="(.+?)"' ) . findall ( IIiIi1iI )
 Iii1I1111ii = re . compile ( 'video_label7="(.+?)"' ) . findall ( IIiIi1iI )
 ooOoO00 = re . compile ( 'video_label8="(.+?)"' ) . findall ( IIiIi1iI )
 Ii1IIiI1i = re . compile ( 'video_label9="(.+?)"' ) . findall ( IIiIi1iI )
 o0O00Oo0 = re . compile ( 'video_label10="(.+?)"' ) . findall ( IIiIi1iI )
 if 33 - 33: IIIIII11i1I * OoOo - O0oO % O0oO
 if 18 - 18: O0oO / iiIi * O0oO + O0oO * i11iIiiIii * iii11I111
 I1II1 = i1iIi [ 0 ] if ( len ( i1iIi ) > 0 ) else ''
 oooO = ooOOoooooo [ 0 ] if ( len ( ooOOoooooo ) > 0 ) else ''
 i1I1i111Ii = II1I [ 0 ] if ( len ( II1I ) > 0 ) else ''
 ooo = O0 [ 0 ] if ( len ( O0 ) > 0 ) else ''
 i1i1iI1iiiI = i1II1Iiii1I11 [ 0 ] if ( len ( i1II1Iiii1I11 ) > 0 ) else ''
 Ooo0oOooo0 = IIIIiiIiI [ 0 ] if ( len ( IIIIiiIiI ) > 0 ) else ''
 oOOOoo00 = o00oooO0Oo [ 0 ] if ( len ( o00oooO0Oo ) > 0 ) else ''
 iiIiIIIiiI = o0O0OOO0Ooo [ 0 ] if ( len ( o0O0OOO0Ooo ) > 0 ) else ''
 iiI1IIIi = iiIiI [ 0 ] if ( len ( iiIiI ) > 0 ) else ''
 if 47 - 47: iiIi % oOOoO0O0O0 % i11iIiiIii - IIIIII11i1I + i1OOO
 ooO000OO0O00O = '[CR][CR][COLOR=dodgerblue]Description: [/COLOR]' + IiIiii1I1 [ 0 ] if ( len ( IiIiii1I1 ) > 0 ) else ''
 OOOoOO0o = oOOO [ 0 ] if ( len ( oOOO ) > 0 ) else ''
 i1II1 = iIII1 [ 0 ] if ( len ( iIII1 ) > 0 ) else ''
 i11i1 = '[CR]' + o0o [ 0 ] if ( len ( o0o ) > 0 ) else ''
 IiiiiI1i1Iii = '[CR][CR][COLOR=dodgerblue]User Notes: [/COLOR]' + O0OOoO00OO0o [ 0 ] if ( len ( O0OOoO00OO0o ) > 0 ) else ''
 if 87 - 87: OoOo
 IiI1iiiIii = i1Ii [ 0 ] if ( len ( i1Ii ) > 0 ) else ''
 I1III1111iIi = ii111iI1iIi1 [ 0 ] if ( len ( ii111iI1iIi1 ) > 0 ) else ''
 I1i111I = OOO [ 0 ] if ( len ( OOO ) > 0 ) else ''
 Ooo = oo0OOo0 [ 0 ] if ( len ( oo0OOo0 ) > 0 ) else ''
 Oo0oo0O0o00O = '[CR][CR][COLOR=dodgerblue]Support Forum: [/COLOR]' + I11IiI [ 0 ] if ( len ( I11IiI ) > 0 ) else ''
 I1i11 = O0ooO0Oo00o [ 0 ] if ( len ( O0ooO0Oo00o ) > 0 ) else ''
 license = ooO0oOOooOo0 [ 0 ] if ( len ( ooO0oOOooOo0 ) > 0 ) else ''
 IiIi1I1 = '[COLOR=gold]     Platform: [/COLOR]' + i1I1ii11i1Iii [ 0 ] if ( len ( i1I1ii11i1Iii ) > 0 ) else ''
 IiIIi1 = I1IiiiiI [ 0 ] if ( len ( I1IiiiiI ) > 0 ) else ''
 IIIIiii1IIii = o0OIiII [ 0 ] if ( len ( o0OIiII ) > 0 ) else ''
 II1i11I = ii1iII1II [ 0 ] if ( len ( ii1iII1II ) > 0 ) else ''
 ii1I1IIii11 = Iii1I1I11iiI1 [ 0 ] if ( len ( Iii1I1I11iiI1 ) > 0 ) else ''
 O0o0oO = I1I1i1I [ 0 ] if ( len ( I1I1i1I ) > 0 ) else ''
 IIIIiIiIi1 = ii1I [ 0 ] if ( len ( ii1I ) > 0 ) else ''
 I11iiiiI1i = O0oO0 [ 0 ] if ( len ( O0oO0 ) > 0 ) else ''
 iI1i11 = oO0 [ 0 ] if ( len ( oO0 ) > 0 ) else ''
 OoOOoooOO0O = OoOoO [ 0 ] if ( len ( OoOoO ) > 0 ) else ''
 iI111I11I1I1 = OO [ 0 ] if ( len ( OO ) > 0 ) else ''
 ooo00Ooo = Ii1I1i [ 0 ] if ( len ( Ii1I1i ) > 0 ) else ''
 Oo0o0O00 = OOI1iI1ii1II [ 0 ] if ( len ( OOI1iI1ii1II ) > 0 ) else ''
 ii1I1i11 = O0OO0O [ 0 ] if ( len ( O0OO0O ) > 0 ) else ''
 OOo0O0oo0OO0O = O0O0OOOOoo [ 0 ] if ( len ( O0O0OOOOoo ) > 0 ) else ''
 OO0 = oOooO0 [ 0 ] if ( len ( oOooO0 ) > 0 ) else ''
 o0Oooo = Ii1I1Ii [ 0 ] if ( len ( Ii1I1Ii ) > 0 ) else ''
 iiI = OOoO0 [ 0 ] if ( len ( OOoO0 ) > 0 ) else ''
 oOIIiIi = OO0Oooo0oOO0O [ 0 ] if ( len ( OO0Oooo0oOO0O ) > 0 ) else ''
 OOoOooOoOOOoo = o00O0 [ 0 ] if ( len ( o00O0 ) > 0 ) else ''
 Iiii1iI1i = oOO0O00Oo0O0o [ 0 ] if ( len ( oOO0O00Oo0O0o ) > 0 ) else ''
 I1ii1ii11i1I = ii1 [ 0 ] if ( len ( ii1 ) > 0 ) else ''
 o0OoOO = I1iIIiiIIi1i [ 0 ] if ( len ( I1iIIiiIIi1i ) > 0 ) else 'None'
 O0O0Oo00 = O0O0ooOOO [ 0 ] if ( len ( O0O0ooOOO ) > 0 ) else 'None'
 oOoO00o = oOOo0O00o [ 0 ] if ( len ( oOOo0O00o ) > 0 ) else 'None'
 oO00O0 = iIiIi11 [ 0 ] if ( len ( iIiIi11 ) > 0 ) else 'None'
 IIi1IIIi = OOOiiiiI [ 0 ] if ( len ( OOOiiiiI ) > 0 ) else 'None'
 O00Ooo = oooOo0OOOoo0 [ 0 ] if ( len ( oooOo0OOOoo0 ) > 0 ) else 'None'
 OOOO0OOO = OOoO [ 0 ] if ( len ( OOoO ) > 0 ) else 'None'
 i1i1ii = OO0O000 [ 0 ] if ( len ( OO0O000 ) > 0 ) else 'None'
 iII1ii1 = iiIiI1i1 [ 0 ] if ( len ( iiIiI1i1 ) > 0 ) else 'None'
 I1i1iiiI1 = oO0O00oOOoooO [ 0 ] if ( len ( oO0O00oOOoooO ) > 0 ) else 'None'
 iIIi = IiIi11iI [ 0 ] if ( len ( IiIi11iI ) > 0 ) else 'None'
 oO0o00oo0 = Oo0O00O000 [ 0 ] if ( len ( Oo0O00O000 ) > 0 ) else 'None'
 ii1IIII = i11I1IiII1i1i [ 0 ] if ( len ( i11I1IiII1i1i ) > 0 ) else 'None'
 oO00oOooooo0 = oo [ 0 ] if ( len ( oo ) > 0 ) else 'None'
 oOo = I1111i [ 0 ] if ( len ( I1111i ) > 0 ) else 'None'
 O0OOooOoO = iIIii [ 0 ] if ( len ( iIIii ) > 0 ) else 'None'
 i1II1I1Iii1 = o00O0O [ 0 ] if ( len ( o00O0O ) > 0 ) else 'None'
 iiI11Iii = ii1iii1i [ 0 ] if ( len ( ii1iii1i ) > 0 ) else 'None'
 O0o0O0 = Iii1I1111ii [ 0 ] if ( len ( Iii1I1111ii ) > 0 ) else 'None'
 Ii1II1I11i1 = ooOoO00 [ 0 ] if ( len ( ooOoO00 ) > 0 ) else 'None'
 oOoooooOoO = Ii1IIiI1i [ 0 ] if ( len ( Ii1IIiI1i ) > 0 ) else 'None'
 Ii111 = o0O00Oo0 [ 0 ] if ( len ( o0O00Oo0 ) > 0 ) else 'None'
 if i11i1 != '' :
  I111i1i1111 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=red]This add-on is depreciated, it\'s no longer available.[/COLOR]'
 elif i1II1 == '' and OOOoOO0o == '' and ooo00Ooo == '' :
  I111i1i1111 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=lime]No reported problems[/COLOR]'
 elif i1II1 == '' and OOOoOO0o == '' and ooo00Ooo != '' and i11i1 == '' :
  I111i1i1111 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=orange]Although there have been no reported problems there may be issues with this add-on, see below.[/COLOR]'
 elif i1II1 == '' and OOOoOO0o != '' :
  I111i1i1111 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by the add-on developer.[CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + OOOoOO0o
 elif i1II1 != '' and OOOoOO0o == '' :
  I111i1i1111 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by a member of the community at [COLOR=lime]www.totalxbmc.tv[/COLOR][CR][COLOR=dodgerblue]User Comments: [/COLOR]' + i1II1
 elif i1II1 != '' and OOOoOO0o != '' :
  I111i1i1111 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by both the add-on developer and a member of the community at [COLOR=lime]www.totalxbmc.tv[/COLOR][CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + OOOoOO0o + '[CR][COLOR=dodgerblue]User Comments: [/COLOR]' + i1II1
 IIII1 = str ( '[COLOR=gold]Name: [/COLOR]' + I1II1 + '[COLOR=gold]     Author(s): [/COLOR]' + ooo + '[COLOR=gold][CR][CR]Version: [/COLOR]' + i1i1iI1iiiI + '[COLOR=gold]     Created: [/COLOR]' + Ooo0oOooo0 + '[COLOR=gold]     Updated: [/COLOR]' + iiIiIIIiiI + '[COLOR=gold][CR][CR]Repository: [/COLOR]' + I1i11 + IiIi1I1 + '[COLOR=gold]     Add-on Type(s): [/COLOR]' + oOOOoo00 + OOoOooOoOOOoo + I111i1i1111 + i11i1 + ooo00Ooo + Oo0oo0O0o00O + ooO000OO0O00O + IiiiiI1i1Iii )
 if 10 - 10: O0oO / i1OOO + i11iIiiIii / Oo000o
 if ( i1II1 == '' ) and ( OOOoOO0o == '' ) and ( i11i1 == '' ) and ( ooo00Ooo == '' ) :
  Ii ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=lime] No problems reported[/COLOR]' , IIII1 , 'text_guide' , I1ii1ii11i1I , '' , '' , IIII1 )
 if ( i1II1 != '' and i11i1 == '' ) or ( OOOoOO0o != '' and i11i1 == '' ) or ( ooo00Ooo != '' and i11i1 == '' ) :
  Ii ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=orange] Possbile problems reported[/COLOR]' , IIII1 , 'text_guide' , I1ii1ii11i1I , '' , '' , IIII1 )
 if i11i1 != '' :
  Ii ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=red] Add-on now depreciated[/COLOR]' , IIII1 , 'text_guide' , I1ii1ii11i1I , '' , '' , IIII1 )
 if i11i1 == '' :
  ii1ii1ii ( '[COLOR=lime][INSTALL] [/COLOR]' + I1II1 , I1II1 , '' , 'addon_install' , 'Install.png' , '' , '' , ooO000OO0O00O , I1i111I , IiI1iiiIii , I1i11 , i1I1i111Ii , ooo , Oo0oo0O0o00O , I1III1111iIi )
 if o0OoOO != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  Preview' , oOoO00o , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if oOoO00o != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + ii1IIII , oOoO00o , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if oO00O0 != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oO00oOooooo0 , oO00O0 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if IIi1IIIi != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oOo , IIi1IIIi , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if O00Ooo != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + O0OOooOoO , O00Ooo , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if OOOO0OOO != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + i1II1I1Iii1 , OOOO0OOO , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if i1i1ii != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + iiI11Iii , i1i1ii , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if iII1ii1 != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + O0o0O0 , iII1ii1 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if I1i1iiiI1 != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + Ii1II1I11i1 , I1i1iiiI1 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if iIIi != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oOoooooOoO , iIIi , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
 if oO0o00oo0 != 'None' :
  Ii ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + Ii111 , oO0o00oo0 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
  if 74 - 74: OOO00OoOO00 + IIIIII11i1I + o0O0 - o0O0 + ii1I11II1ii1i
  if 83 - 83: iii11I111 - oO0o0ooo + OOO00OoOO00
def iIi1Ii1i1iI ( ) :
 Ii ( 'folder' , 'Anime' , '&genre=anime' , 'grab_addons' , 'anime.png' , '' , '' , '' )
 Ii ( 'folder' , 'Audiobooks' , '&genre=audiobooks' , 'grab_addons' , 'audiobooks.png' , '' , '' , '' )
 Ii ( 'folder' , 'Comedy' , '&genre=comedy' , 'grab_addons' , 'comedy.png' , '' , '' , '' )
 Ii ( 'folder' , 'Comics' , '&genre=comics' , 'grab_addons' , 'comics.png' , '' , '' , '' )
 Ii ( 'folder' , 'Documentary' , '&genre=documentary' , 'grab_addons' , 'documentary.png' , '' , '' , '' )
 Ii ( 'folder' , 'Downloads' , '&genre=downloads' , 'grab_addons' , 'downloads.png' , '' , '' , '' )
 Ii ( 'folder' , 'Food' , '&genre=food' , 'grab_addons' , 'food.png' , '' , '' , '' )
 Ii ( 'folder' , 'Gaming' , '&genre=gaming' , 'grab_addons' , 'gaming.png' , '' , '' , '' )
 Ii ( 'folder' , 'Health' , '&genre=health' , 'grab_addons' , 'health.png' , '' , '' , '' )
 Ii ( 'folder' , 'How To...' , '&genre=howto' , 'grab_addons' , 'howto.png' , '' , '' , '' )
 Ii ( 'folder' , 'Kids' , '&genre=kids' , 'grab_addons' , 'kids.png' , '' , '' , '' )
 Ii ( 'folder' , 'Live TV' , '&genre=livetv' , 'grab_addons' , 'livetv.png' , '' , '' , '' )
 Ii ( 'folder' , 'Movies' , '&genre=movies' , 'grab_addons' , 'movies.png' , '' , '' , '' )
 Ii ( 'folder' , 'Music' , '&genre=music' , 'grab_addons' , 'music.png' , '' , '' , '' )
 Ii ( 'folder' , 'News' , '&genre=news' , 'grab_addons' , 'news.png' , '' , '' , '' )
 Ii ( 'folder' , 'Photos' , '&genre=photos' , 'grab_addons' , 'photos.png' , '' , '' , '' )
 Ii ( 'folder' , 'Podcasts' , '&genre=podcasts' , 'grab_addons' , 'podcasts.png' , '' , '' , '' )
 Ii ( 'folder' , 'Radio' , '&genre=radio' , 'grab_addons' , 'radio.png' , '' , '' , '' )
 Ii ( 'folder' , 'Religion' , '&genre=religion' , 'grab_addons' , 'religion.png' , '' , '' , '' )
 Ii ( 'folder' , 'Space' , '&genre=space' , 'grab_addons' , 'space.png' , '' , '' , '' )
 Ii ( 'folder' , 'Sports' , '&genre=sports' , 'grab_addons' , 'sports.png' , '' , '' , '' )
 Ii ( 'folder' , 'Technology' , '&genre=tech' , 'grab_addons' , 'tech.png' , '' , '' , '' )
 Ii ( 'folder' , 'Trailers' , '&genre=trailers' , 'grab_addons' , 'trailers.png' , '' , '' , '' )
 Ii ( 'folder' , 'TV Shows' , '&genre=tv' , 'grab_addons' , 'tv.png' , '' , '' , '' )
 Ii ( 'folder' , 'Misc.' , '&genre=other' , 'grab_addons' , 'other.png' , '' , '' , '' )
 if Oo0Ooo . getSetting ( 'adult' ) == 'true' :
  Ii ( 'folder' , 'XXX' , '&genre=adult' , 'grab_addons' , 'adult.png' , '' , '' , '' )
  if 16 - 16: OOO00OoOO00 / iiIi / IIII * oO0o0ooo + o0O0 % OOO00OoOO00
  if 71 - 71: II11iII
def ii111IiiI1 ( name , zip_link , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 print "############# ADDON INSTALL #################"
 forum = str ( forum )
 repo_id = str ( repo_id )
 ii11i1iIiII1 = 1
 o00oo0 = 1
 oooooOOO000Oo = 1
 Ooo00OoOOO = xbmc . translatePath ( os . path . join ( OooO0 , name + '.zip' ) )
 Oo0OO0000oooo = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , addon_id ) )
 IiI . create ( "Installing Addon" , "Please wait whilst your addon is installed" , '' , '' )
 try :
  downloader . download ( repo_link , Ooo00OoOOO , IiI )
  extract . all ( Ooo00OoOOO , ooOoOoo0O , IiI )
 except :
  try :
   downloader . download ( zip_link , Ooo00OoOOO , IiI )
   extract . all ( Ooo00OoOOO , ooOoOoo0O , IiI )
  except :
   try :
    if not os . path . exists ( Oo0OO0000oooo ) :
     os . makedirs ( Oo0OO0000oooo )
    IIiIi1iI = i1IiiiI1iI ( data_path ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    IIII1iII = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IIiIi1iI )
    for ii1III11 in IIII1iII :
     I1iiIIIi11 = xbmc . translatePath ( os . path . join ( Oo0OO0000oooo , ii1III11 ) )
     if addon_id not in ii1III11 and '/' not in ii1III11 :
      try :
       IiI . update ( 0 , "Downloading [COLOR=yellow]" + ii1III11 + '[/COLOR]' , '' , 'Please wait...' )
       print "downloading: " + data_path + ii1III11
       downloader . download ( data_path + ii1III11 , I1iiIIIi11 , IiI )
      except : print "failed to install" + ii1III11
     if '/' in ii1III11 and '..' not in ii1III11 and 'http' not in ii1III11 :
      Ii1I11ii1i = data_path + ii1III11
      O0iIiIIIIIii ( I1iiIIIi11 , Ii1I11ii1i )
   except :
    Oo0O . ok ( "Error downloading add-on" , 'There was an error downloading [COLOR=yellow]' + name , '[/COLOR]Please consider updating the add-on portal with details' , 'or report the error on the forum at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B]' )
    ii11i1iIiII1 = 0
 if ii11i1iIiII1 == 1 :
  time . sleep ( 1 )
  IiI . update ( 0 , "[COLOR=yellow]" + name + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing repository' )
  time . sleep ( 1 )
  OOo0 = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , repo_id ) )
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( OOo0 ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   ii11I1 ( repo_id )
  oO0oo = 'http://totalxbmc.com/totalrevolution/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
  i1IiiiI1iI ( oO0oo )
  Ii111iIi1iIi ( name , addon_id )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  if o00oo0 == 0 :
   Oo0O . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing the repository.' , 'This will mean the add-on fails to update' )
  if oooooOOO000Oo == 0 :
   Oo0O . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing modules.' , 'This could result in errors with the add-on.' )
  if oooooOOO000Oo != 0 and o00oo0 != 0 and forum != '' :
   Oo0O . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]Support for this add-on can be found at [COLOR=yellow]' + forum , '[/COLOR][CR]Remember to visit [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B] for all your Kodi needs.' )
  if oooooOOO000Oo != 0 and o00oo0 != 0 and forum == '' :
   Oo0O . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]No details of forum support have been given but' , 'we\'ll be happy to help at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B]' )
   if 21 - 21: Ooo0Oo0 / iii11I111 + Oo000o + IIII
   if 91 - 91: i11iIiiIii / o0O0 + OoO0O00 + i1OOO * i11iIiiIii
def OoOoOo00o0 ( ) :
 for file in glob . glob ( os . path . join ( iiIIIII1i1iI , '*' ) ) :
  I1II1 = str ( file ) . replace ( iiIIIII1i1iI , '[COLOR=red]REMOVE [/COLOR]' ) . replace ( 'plugin.' , '[COLOR=dodgerblue](PLUGIN) [/COLOR]' ) . replace ( 'audio.' , '' ) . replace ( 'video.' , '' ) . replace ( 'skin.' , '[COLOR=yellow](SKIN) [/COLOR]' ) . replace ( 'repository.' , '[COLOR=orange](REPOSITORY) [/COLOR]' ) . replace ( 'script.' , '[COLOR=cyan](SCRIPT) [/COLOR]' ) . replace ( 'metadata.' , '[COLOR=gold](METADATA) [/COLOR]' ) . replace ( 'service.' , '[COLOR=pink](SERVICE) [/COLOR]' ) . replace ( 'weather.' , '[COLOR=green](WEATHER) [/COLOR]' ) . replace ( 'module.' , '[COLOR=gold](MODULE) [/COLOR]' )
  OO0ooo0oOO = ( os . path . join ( file , 'icon.png' ) )
  oo000 = ( os . path . join ( file , 'fanart.jpg' ) )
  Ii ( '' , I1II1 , file , 'remove_addons' , OO0ooo0oOO , oo000 , '' , '' )
  if 32 - 32: o0O0 . Oo000o
  if 59 - 59: IIII
def i1iiiii1 ( ) :
 Oo0Ooo . openSettings ( sys . argv [ 0 ] )
 if 83 - 83: OoO0O00 . IIIIII11i1I / iiIi / OOO00OoOO00 - ii1I11II1ii1i
 if 100 - 100: iiiIi1i1I
def II1i ( ) :
 Ii ( '' , '[COLOR=lime]T[/COLOR]otal[COLOR=lime]B[/COLOR]ox[COLOR=lime]S[/COLOR]hop Storage Folder Check' , 'url' , 'check_storage' , 'Check_Download.png' , '' , '' , '' )
 Ii ( 'folder' , 'Completely remove an add-on (inc. passwords)' , 'plugin' , 'addon_removal_menu' , 'Remove_Addon.png' , '' , '' , '' )
 Ii ( '' , 'Make Add-ons Gotham/Helix Compatible' , 'none' , 'gotham' , 'Gotham_Compatible.png' , '' , '' , '' )
 Ii ( '' , 'Make Skins Kodi (Helix) Compatible' , 'none' , 'helix' , 'Kodi_Compatible.png' , '' , '' , '' )
 Ii ( '' , 'Hide my add-on passwords' , 'none' , 'hide_passwords' , 'Hide_Passwords.png' , '' , '' , '' )
 if IiIi11iIIi1Ii == 'true' :
  Ii ( 'folder' , 'OnTapp.TV / OSS Integration' , 'none' , 'addonfix' , 'Addon_Fixes.png' , '' , '' , '' )
 Ii ( 'folder' , 'Test My Download Speed' , 'none' , 'speedtest_menu' , 'Speed_Test.png' , '' , '' , '' )
 Ii ( '' , 'Unhide my add-on passwords' , 'none' , 'unhide_passwords' , 'Unhide_Passwords.png' , '' , '' , '' )
 Ii ( '' , 'Update My Add-ons (Force Refresh)' , 'none' , 'update' , 'Update_Addons.png' , '' , '' , '' )
 Ii ( '' , 'Wipe All Add-on Settings (addon_data)' , 'url' , 'remove_addon_data' , 'Delete_Addon_Data.png' , '' , '' , '' )
 if 2 - 2: o0o0OOO0o0 * iiIi % Ooo0Oo0 - ii1I11II1ii1i - OoO0O00
 if 3 - 3: O0oO
def i1iiIiI1Ii1i ( ) :
 Ii ( 'folder' , '[COLOR=yellow][Manual Search][/COLOR] Search By Name' , 'name=' , 'search_addons' , 'Search_Addons.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=yellow][Manual Search][/COLOR] Search By Author' , 'author=' , 'search_addons' , 'Search_Addons.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=yellow][Manual Search][/COLOR] Search In Description' , 'desc=' , 'search_addons' , 'Search_Addons.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Filter Results][/COLOR] By Genres' , '' , 'addon_genres' , 'Search_Genre.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Filter Results][/COLOR] By Countries' , '' , 'addon_countries' , 'Search_Country.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Filter Results][/COLOR] By Kodi Categories' , '' , 'addon_categories' , 'Search_Category.png' , '' , '' , '' )
 if IiIi11iIIi1Ii == 'true' :
  Ii ( 'folder' , '[COLOR=dodgerblue]Install Popular Packs[/COLOR]' , 'none' , 'popular' , 'Addon_Packs.png' , '' , '' , '' )
  if 22 - 22: ooOO0o / i11iIiiIii
  if 62 - 62: iiiIi1i1I / iii11I111
def all ( _in , _out , dp = None ) :
 if dp :
  return ii1O000OOO0OOo ( _in , _out , dp )
  if 32 - 32: Oo000o * IIIIII11i1I
 return O00oOo00o0o ( _in , _out )
 if 85 - 85: OoO0O00 + IIII * OoO0O00 - O0oO % i11iIiiIii
 if 71 - 71: iii11I111 - i1OOO / II11iII * II11iII / o0O0 . o0O0
def O00oOo00o0o ( _in , _out ) :
 try :
  ooo000ooO0000 = zipfile . ZipFile ( _in , 'r' )
  ooo000ooO0000 . extractall ( _out )
 except Exception , Oo0O0O0ooO0O :
  return False
 return True
 if 97 - 97: iiIi * oO0o0ooo . o0o0OOO0o0
 if 16 - 16: i1OOO % IIII - OOO00OoOO00 * Oo000o * iii11I111 / IIII
def ii1O000OOO0OOo ( _in , _out , dp ) :
 ooo000ooO0000 = zipfile . ZipFile ( _in , 'r' )
 I11o0oO00oO0o0o0 = float ( len ( ooo000ooO0000 . infolist ( ) ) )
 I1I = 0
 try :
  for ooooo in ooo000ooO0000 . infolist ( ) :
   I1I += 1
   i11IIIiI1I = I1I / I11o0oO00oO0o0o0 * 100
   dp . update ( int ( i11IIIiI1I ) )
   ooo000ooO0000 . extract ( ooooo , _out )
 except Exception , Oo0O0O0ooO0O :
  return False
 return True
 if 69 - 69: IIIIII11i1I
 if 85 - 85: i1OOO / IIIIII11i1I
def iI1iIIIi1i ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 oooOooooO0oOO = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 Iiiiii1iI = len ( sourcefile )
 IIi = [ ]
 ooOooo0 = [ ]
 IiI . create ( message_header , message1 , message2 , message3 )
 for oO0OO0 , o0O0Oo00 , O0Oo0o000oO in os . walk ( sourcefile ) :
  for file in O0Oo0o000oO :
   ooOooo0 . append ( file )
 oO0o00oOOooO0 = len ( ooOooo0 )
 for oO0OO0 , o0O0Oo00 , O0Oo0o000oO in os . walk ( sourcefile ) :
  o0O0Oo00 [ : ] = [ OOOoO000 for OOOoO000 in o0O0Oo00 if OOOoO000 not in exclude_dirs ]
  O0Oo0o000oO [ : ] = [ oOOOO for oOOOO in O0Oo0o000oO if oOOOO not in exclude_files ]
  for file in O0Oo0o000oO :
   IIi . append ( file )
   IiIi1ii111i1 = len ( IIi ) / float ( oO0o00oOOooO0 ) * 100
   IiI . update ( int ( IiIi1ii111i1 ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
   i1i1i1I = os . path . join ( oO0OO0 , file )
   if not 'temp' in o0O0Oo00 :
    if not 'plugin.program.TBS' in o0O0Oo00 :
     import time
     oOoo000 = '01/01/1980'
     OooOo00o = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( i1i1i1I ) ) )
     if OooOo00o > oOoo000 :
      oooOooooO0oOO . write ( i1i1i1I , i1i1i1I [ Iiiiii1iI : ] )
 oooOooooO0oOO . close ( )
 IiI . close ( )
 if 20 - 20: o0O0 * O0oO + ii1I11II1ii1i % OoOo % Ooo0Oo0
 if 13 - 13: iiIi
def oOOo000oOoO0 ( sourcefile , destfile ) :
 oooOooooO0oOO = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 Iiiiii1iI = len ( sourcefile )
 IIi = [ ]
 ooOooo0 = [ ]
 IiI . create ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "Archiving..." , '' , 'Please Wait' )
 for oO0OO0 , o0O0Oo00 , O0Oo0o000oO in os . walk ( sourcefile ) :
  for file in O0Oo0o000oO :
   ooOooo0 . append ( file )
 oO0o00oOOooO0 = len ( ooOooo0 )
 for oO0OO0 , o0O0Oo00 , O0Oo0o000oO in os . walk ( sourcefile ) :
  for file in O0Oo0o000oO :
   IIi . append ( file )
   IiIi1ii111i1 = len ( IIi ) / float ( oO0o00oOOooO0 ) * 100
   IiI . update ( int ( IiIi1ii111i1 ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
   i1i1i1I = os . path . join ( oO0OO0 , file )
   if not 'temp' in o0O0Oo00 :
    if not 'plugin.program.TBS' in o0O0Oo00 :
     import time
     oOoo000 = '01/01/1980'
     OooOo00o = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( i1i1i1I ) ) )
     if OooOo00o > oOoo000 :
      oooOooooO0oOO . write ( i1i1i1I , i1i1i1I [ Iiiiii1iI : ] )
 oooOooooO0oOO . close ( )
 IiI . close ( )
 if 86 - 86: ii1I11II1ii1i % i11iIiiIii + Oo000o % i11iIiiIii
 if 92 - 92: i11iIiiIii - OoO0O00 / i1OOO / Ooo0Oo0
def iiI11I ( ) :
 Ii ( '' , '[COLOR=lime]Full Backup[/COLOR]' , 'url' , 'community_backup' , 'Backup.png' , '' , '' , 'Back Up Your Full System' )
 Ii ( '' , 'Backup Just Your Addons' , 'addons' , 'restore_zip' , 'Backup.png' , '' , '' , 'Back Up Your Addons' )
 Ii ( '' , 'Backup Just Your Addon UserData' , 'addon_data' , 'restore_zip' , 'Backup.png' , '' , '' , 'Back Up Your Addon Userdata' )
 Ii ( '' , 'Backup Guisettings.xml' , Oo0oO0ooo , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your guisettings.xml' )
 if os . path . exists ( oOOoo00O0O ) :
  Ii ( '' , 'Backup Favourites.xml' , oOOoo00O0O , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your favourites.xml' )
 if os . path . exists ( i1111 ) :
  Ii ( '' , 'Backup Source.xml' , i1111 , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your sources.xml' )
 if os . path . exists ( i11 ) :
  Ii ( '' , 'Backup Advancedsettings.xml' , i11 , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your advancedsettings.xml' )
 if os . path . exists ( oOo0oooo00o ) :
  Ii ( '' , 'Backup Advancedsettings.xml' , oOo0oooo00o , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your keyboard.xml' )
 if os . path . exists ( Oo0o0000o0o0 ) :
  Ii ( '' , 'Backup RssFeeds.xml' , Oo0o0000o0o0 , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your RssFeeds.xml' )
  if 11 - 11: OoO0O00 - Ooo0Oo0 + ii1I11II1ii1i - o0o0OOO0o0
  if 7 - 7: ooOO0o - oOOoO0O0O0 / ii1I11II1ii1i * Oo000o . OoO0O00 * OoO0O00
def O0O0oOOo0O ( ) :
 Ii ( 'folder' , 'Backup My Content' , 'none' , 'backup_option' , 'Backup.png' , '' , '' , '' )
 Ii ( 'folder' , 'Restore My Content' , 'none' , 'restore_option' , 'Restore.png' , '' , '' , '' )
 if 19 - 19: OoOo / O0oO % OoOo % OoO0O00 * ooOO0o
 if 19 - 19: o0o0OOO0o0
def Ii1IiI1i1ii ( localbuildcheck , localversioncheck , id , welcometext ) :
 I1I1i1Ioo0oo = 0
 IIi11IIiIii1 = Oo0Ooo . getSetting ( 'addonportal' )
 I1iIII1 = Oo0Ooo . getSetting ( 'maintenance' )
 iIii = Oo0Ooo . getSetting ( 'hardwareportal' )
 oOo0OoOOo0 = Oo0Ooo . getSetting ( 'maintenance' )
 iII11I1Ii1 = Oo0Ooo . getSetting ( 'latestnews' )
 o0o0 = Oo0Ooo . getSetting ( 'tutorialportal' )
 if ( oO00oOo in welcometext ) and ( 'elc' in welcometext ) :
  I1I1i1Ioo0oo = 1
  Ii ( '' , welcometext , 'show' , 'user_info' , 'TOTALXBMC.png' , '' , '' , '' )
  if id != 'None' :
   if id != 'Local' :
    oOo0oO = IIi1IIIIi ( localbuildcheck , localversioncheck , id )
    if oOo0oO == True :
     Ii ( '' , '[COLOR=dodgerblue]' + localbuildcheck + ':[/COLOR] [COLOR=lime]NEW VERSION AVAILABLE[/COLOR]' , id , 'showinfo' , 'TOTALXBMC.png' , '' , '' , '' )
    else :
     Ii ( '' , '[COLOR=lime]Current Build Installed: [/COLOR][COLOR=dodgerblue]' + localbuildcheck + '[/COLOR]' , id , 'showinfo' , 'TOTALXBMC.png' , '' , '' , '' )
   else :
    if localbuildcheck == 'Incomplete' :
     Ii ( '' , '[COLOR=lime]Your last restore is not yet completed[/COLOR]' , 'url' , OOOoO ( ) , 'TOTALXBMC.png' , '' , '' , '' )
    else :
     Ii ( '' , '[COLOR=lime]Current Build Installed: [/COLOR][COLOR=dodgerblue]Local Build (' + localbuildcheck + ')[/COLOR]' , 'TOTALXBMC.png' , '' , '' , '' , '' , '' )
  Ii ( '' , '[COLOR=gold]----------------------------------------------[/COLOR]' , 'None' , '' , 'TOTALXBMC.png' , '' , '' , '' )
 if oO00oOo != '' and OOOo0 != '' and I1I1i1Ioo0oo != 1 and IiIi11iIIi1Ii == 'true' :
  Ii ( '' , '[COLOR=lime]Unable to login, please check your details[/COLOR]' , 'None' , 'addon_settings' , 'TOTALXBMC.png' , '' , '' , '' )
 if IiIi11iIIi1Ii == 'true' and I1I1i1Ioo0oo != 1 :
  Ii ( '' , welcometext , 'None' , 'register' , 'TOTALXBMC.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=yellow]Settings[/COLOR]' , 'settings' , 'addon_settings' , 'SETTINGS.png' , '' , '' , '' )
 if IIi11IIiIii1 == 'true' :
  Ii ( 'folder' , 'Add-on Portal' , 'none' , 'addonmenu' , 'Search_Addons.png' , '' , '' , '' )
 if I1iIII1 == 'true' and I1IiiI != '' and IIi1IiiiI1Ii != '' :
  Ii ( 'folder' , 'Community Builds' , 'none' , 'community' , 'Community_Builds.png' , '' , '' , '' )
 if iIii == 'true' :
  Ii ( 'folder' , 'Hardware Reviews' , 'none' , 'hardware_root_menu' , 'hardware.png' , '' , '' , '' )
 if iII11I1Ii1 == 'true' :
  Ii ( 'folder' , 'Latest News' , 'none' , 'news_root_menu' , 'LatestNews.png' , '' , '' , '' )
 if o0o0 == 'true' :
  Ii ( 'folder' , 'Tutorials' , '' , 'tutorial_root_menu' , 'TotalXBMC_Guides.png' , '' , '' , '' )
 if oOo0OoOOo0 == 'true' :
  Ii ( 'folder' , 'Maintenance' , 'none' , 'tools' , 'Additional_Tools.png' , '' , '' , '' )
  if 14 - 14: oOOoO0O0O0 . o0o0OOO0o0 . IIII . ii1I11II1ii1i / OoOo
  if 21 - 21: i11iIiiIii / o0O0 + oO0o0ooo * OOO00OoOO00 . O0oO
def OoO ( ) :
 oo0oO = xbmc . getInfoLabel ( "System.BuildVersion" )
 i1i1iI1iiiI = float ( oo0oO [ : 4 ] )
 if O00ooooo00 == 'true' :
  ii ( )
 if II1 == 'true' :
  Ii ( 'folder' , '[COLOR=lime]Show My Private List[/COLOR]' , '&visibility=private' , 'grab_builds' , 'Private_builds.png' , '' , '' , '' )
 if i1i1iI1iiiI < 14 :
  Ii ( 'folder' , '[COLOR=orange]Show All Gotham Compatible Builds[/COLOR]' , '&visibility=public' , 'grab_builds' , 'TRCOMMUNITYGOTHAMBUILDS.png' , '' , '' , '' )
 if i1i1iI1iiiI >= 14 :
  Ii ( 'folder' , '[COLOR=orange]Show All Helix Compatible Builds[/COLOR]' , '&visibility=public' , 'grab_builds' , 'TRCOMMUNITYHELIXBUILDS.png' , '' , '' , '' )
 Ii ( 'folder' , 'Restore a locally stored Community Build' , 'url' , 'restore_local_CB' , 'Restore.png' , '' , '' , 'Back Up Your Full System' )
 Ii ( 'folder' , 'Create My Own Community Build' , 'url' , 'community_backup' , 'Backup.png' , '' , '' , 'Back Up Your Full System' )
 if 81 - 81: IIIIII11i1I % Oo000o
 if 5 - 5: IIII - iiiIi1i1I + ooOO0o - OoO0O00 . iiiIi1i1I / i1OOO
def i1I1i1i1iII1 ( skin ) :
 oOo000 = '<onleft>%s</onleft>'
 IIii11II11II1 = '<onright>%s</onright>'
 II1IOoOo000oOo0oo = '<onup>%s</onup>'
 oO0O = '<ondown>%s</ondown>'
 oOO = '<control type="button" id="%s">'
 iiiIIiIi = [ ( '65' , '140' ) , ( '66' , '164' ) , ( '67' , '162' ) , ( '68' , '142' ) , ( '69' , '122' ) , ( '70' , '143' ) , ( '71' , '144' ) , ( '72' , '145' ) , ( '73' , '127' ) , ( '74' , '146' ) , ( '75' , '147' ) , ( '76' , '148' ) , ( '77' , '166' ) , ( '78' , '165' ) , ( '79' , '128' ) , ( '80' , '129' ) , ( '81' , '120' ) , ( '82' , '123' ) , ( '83' , '141' ) , ( '84' , '124' ) , ( '85' , '126' ) , ( '86' , '163' ) , ( '87' , '121' ) , ( '88' , '161' ) , ( '89' , '125' ) , ( '90' , '160' ) ]
 for OooOOO , Ii1iI11iI1 in iiiIIiIi :
  i11I1II = open ( skin ) . read ( )
  OO0OOO0oOOo00O = i11I1II . replace ( oOO % OooOOO , oOO % Ii1iI11iI1 ) . replace ( oOo000 % OooOOO , oOo000 % Ii1iI11iI1 ) . replace ( IIii11II11II1 % OooOOO , IIii11II11II1 % Ii1iI11iI1 ) . replace ( II1IOoOo000oOo0oo % OooOOO , II1IOoOo000oOo0oo % Ii1iI11iI1 ) . replace ( oO0O % OooOOO , oO0O % Ii1iI11iI1 )
  oOOOO = open ( skin , mode = 'w' )
  oOOOO . write ( OO0OOO0oOOo00O )
  oOOOO . close ( )
  if 51 - 51: iii11I111 / o0o0OOO0o0 % Ooo0Oo0 + OoOo * i1OOO + O0oO
def o0OoO00o0000O ( u , skin ) :
 oOo000 = '<onleft>%s</onleft>'
 IIii11II11II1 = '<onright>%s</onright>'
 II1IOoOo000oOo0oo = '<onup>%s</onup>'
 oO0O = '<ondown>%s</ondown>'
 oOO = '<control type="button" id="%s">'
 if u < 49 :
  II11I = u + 61
 else :
  II11I = u + 51
 i11I1II = open ( skin ) . read ( )
 OO0OOO0oOOo00O = i11I1II . replace ( oOo000 % u , oOo000 % II11I ) . replace ( IIii11II11II1 % u , IIii11II11II1 % II11I ) . replace ( II1IOoOo000oOo0oo % u , II1IOoOo000oOo0oo % II11I ) . replace ( oO0O % u , oO0O % II11I ) . replace ( oOO % u , oOO % II11I )
 oOOOO = open ( skin , mode = 'w' )
 oOOOO . write ( OO0OOO0oOOo00O )
 oOOOO . close ( )
 if 96 - 96: oO0o0ooo % iiIi . iii11I111 + OOO00OoOO00
 if 42 - 42: ii1I11II1ii1i * OoO0O00 * i11iIiiIii - OOO00OoOO00 . IIII
def oo00o ( ) :
 oo0000Oo00o = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 if not os . path . exists ( zip ) :
  Oo0O . ok ( '[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]' , 'The download location you have stored does not exist .\nPlease update the addon settings and try again.' , '' , '' )
  Oo0Ooo . openSettings ( sys . argv [ 0 ] )
  if 67 - 67: i1OOO + oO0o0ooo * i11iIiiIii - Ooo0Oo0 / ooOO0o % OoO0O00
  if 92 - 92: Oo000o - Ooo0Oo0 - i1OOO % IIII / OOO00OoOO00
def IIi1IIIIi ( localbuildcheck , localversioncheck , id ) :
 OOOo00oo0oO = 'http://totalxbmc.tv/totalrevolution/Community_Builds/buildupdate.php?id=%s' % ( id )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if id != 'None' :
  iIIIiIii = re . compile ( 'version="(.+?)"' ) . findall ( IIiIi1iI )
  oooOOOO0oooo = iIIIiIii [ 0 ] if ( len ( iIIIiIii ) > 0 ) else ''
 if localversioncheck < oooOOOO0oooo :
  return True
 else :
  return False
  if 51 - 51: IIIIII11i1I - o0O0 / oO0o0ooo
  if 37 - 37: OoOo % i1OOO
def O0II11i11II ( url ) :
 time . sleep ( 120 )
 if os . path . exists ( iiI1IiI ) :
  II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( 'Run step 2 of install' , 'You still haven\'t completed step 2 of the' , 'install. Would you like to complete it now?' , '' , nolabel = 'No, not yet' , yeslabel = 'Yes, complete setup' )
  if II1Ii1iI1i1 == 0 :
   O0II11i11II ( url )
  elif II1Ii1iI1i1 == 1 :
   try : xbmc . executebuiltin ( "PlayerControl(Stop)" )
   except : pass
   xbmc . executebuiltin ( "ActivateWindow(appearancesettings)" )
   o0 ( url )
   if 78 - 78: o0o0OOO0o0 + oOOoO0O0O0 - Oo000o * O0oO - IIII % II11iII
   if 34 - 34: IIIIII11i1I
def OOOoO ( ) :
 OooOOOo0 = open ( i1iiIII111ii , mode = 'r' )
 O0O0o0o0o = file . read ( OooOOOo0 )
 file . close ( OooOOOo0 )
 IIIIIiI = re . compile ( 'name="(.+?)"' ) . findall ( O0O0o0o0o )
 Oo0000O0OOooO = IIIIIiI [ 0 ] if ( len ( IIIIIiI ) > 0 ) else ''
 if Oo0000O0OOooO == "Incomplete" :
  II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( "Finish Restore Process" , 'If you\'re certain the correct skin has now been set click OK' , 'to finish the install process, once complete XBMC/Kodi will' , ' then close. Do you want to finish the install process?' , yeslabel = 'Yes' , nolabel = 'No' )
  if II1Ii1iI1i1 == 1 :
   O00OO ( )
  elif II1Ii1iI1i1 == 0 :
   return
   if 65 - 65: o0O0 . IIII * Oo000o / ooOO0o
def OOOooo0OooOoO ( ) :
 oo0000Oo00o = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 try :
  os . makedirs ( oo0000Oo00o )
  os . removedirs ( oo0000Oo00o )
  Oo0O . ok ( '[COLOR=lime]SUCCESS[/COLOR]' , 'Great news, the path you chose is writeable.' , 'Some of these builds are rather big, we recommend' , 'a minimum of 1GB storage space.' )
 except :
  Oo0O . ok ( '[COLOR=red]CANNOT WRITE TO PATH[/COLOR]' , 'Kodi cannot write to the path you\'ve chosen. Please click OK' , 'in the settings menu to save the path then try again.' , 'Some devices give false results, we recommend using a USB stick as the backup path.' )
  if 91 - 91: Ooo0Oo0 + oO0o0ooo
  if 59 - 59: oO0o0ooo + i11iIiiIii + o0O0 / oOOoO0O0O0
def I11iIiI1 ( data ) :
 data = data . replace ( '</p><p>' , '[CR][CR]' ) . replace ( '&ndash;' , '-' ) . replace ( '&mdash;' , '-' ) . replace ( "\n" , " " ) . replace ( "\r" , " " ) . replace ( "&rsquo;" , "'" ) . replace ( "&rdquo;" , '"' ) . replace ( "</a>" , " " ) . replace ( "&hellip;" , '...' ) . replace ( "&lsquo;" , "'" ) . replace ( "&ldquo;" , '"' )
 data = " " . join ( data . split ( ) )
 oo0oooOo = re . compile ( r'< script[^<>]*?>.*?< / script >' )
 data = oo0oooOo . sub ( '' , data )
 oo0oooOo = re . compile ( r'< style[^<>]*?>.*?< / style >' )
 data = oo0oooOo . sub ( '' , data )
 oo0oooOo = re . compile ( r'' )
 data = oo0oooOo . sub ( '' , data )
 oo0oooOo = re . compile ( r'<[^<]*?>' )
 data = oo0oooOo . sub ( '' , data )
 data = data . replace ( '&nbsp;' , ' ' )
 return data
 if 59 - 59: O0oO - OoOo - i1OOO
 if 48 - 48: o0O0 + oOOoO0O0O0 % II11iII / iiIi - OoOo
def OOoOOo0O00O ( ) :
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( 'Clear All Known Cache?' , 'This will clear all known cache files and can help' , 'if you\'re encountering kick-outs during playback.' , 'as well as other random issues. There is no harm in using this.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if II1Ii1iI1i1 == 1 :
  iiIii1I ( )
  i1I11iIiII ( )
  if 66 - 66: iiIi - OoOo * ooOO0o + II11iII + OoOo - o0o0OOO0o0
  if 17 - 17: Ooo0Oo0
def i1ii11 ( url ) :
 Ii ( 'folder' , 'African' , str ( url ) + '&genre=african' , 'grab_builds' , 'african.png' , '' , '' , '' )
 Ii ( 'folder' , 'Arabic' , str ( url ) + '&genre=arabic' , 'grab_builds' , 'arabic.png' , '' , '' , '' )
 Ii ( 'folder' , 'Asian' , str ( url ) + '&genre=asian' , 'grab_builds' , 'asian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Australian' , str ( url ) + '&genre=australian' , 'grab_builds' , 'australian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Austrian' , str ( url ) + '&genre=austrian' , 'grab_builds' , 'austrian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Belgian' , str ( url ) + '&genre=belgian' , 'grab_builds' , 'belgian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Brazilian' , str ( url ) + '&genre=brazilian' , 'grab_builds' , 'brazilian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Canadian' , str ( url ) + '&genre=canadian' , 'grab_builds' , 'canadian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Columbian' , str ( url ) + '&genre=columbian' , 'grab_builds' , 'columbian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Czech' , str ( url ) + '&genre=czech' , 'grab_builds' , 'czech.png' , '' , '' , '' )
 Ii ( 'folder' , 'Danish' , str ( url ) + '&genre=danish' , 'grab_builds' , 'danish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Dominican' , str ( url ) + '&genre=dominican' , 'grab_builds' , 'dominican.png' , '' , '' , '' )
 Ii ( 'folder' , 'Dutch' , str ( url ) + '&genre=dutch' , 'grab_builds' , 'dutch.png' , '' , '' , '' )
 Ii ( 'folder' , 'Egyptian' , str ( url ) + '&genre=egyptian' , 'grab_builds' , 'egyptian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Filipino' , str ( url ) + '&genre=filipino' , 'grab_builds' , 'filipino.png' , '' , '' , '' )
 Ii ( 'folder' , 'Finnish' , str ( url ) + '&genre=finnish' , 'grab_builds' , 'finnish.png' , '' , '' , '' )
 Ii ( 'folder' , 'French' , str ( url ) + '&genre=french' , 'grab_builds' , 'french.png' , '' , '' , '' )
 Ii ( 'folder' , 'German' , str ( url ) + '&genre=german' , 'grab_builds' , 'german.png' , '' , '' , '' )
 Ii ( 'folder' , 'Greek' , str ( url ) + '&genre=greek' , 'grab_builds' , 'greek.png' , '' , '' , '' )
 Ii ( 'folder' , 'Hebrew' , str ( url ) + '&genre=hebrew' , 'grab_builds' , 'hebrew.png' , '' , '' , '' )
 Ii ( 'folder' , 'Hungarian' , str ( url ) + '&genre=hungarian' , 'grab_builds' , 'hungarian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Icelandic' , str ( url ) + '&genre=icelandic' , 'grab_builds' , 'icelandic.png' , '' , '' , '' )
 Ii ( 'folder' , 'Indian' , str ( url ) + '&genre=indian' , 'grab_builds' , 'indian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Irish' , str ( url ) + '&genre=irish' , 'grab_builds' , 'irish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Italian' , str ( url ) + '&genre=italian' , 'grab_builds' , 'italian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Japanese' , str ( url ) + '&genre=japanese' , 'grab_builds' , 'japanese.png' , '' , '' , '' )
 Ii ( 'folder' , 'Korean' , str ( url ) + '&genre=korean' , 'grab_builds' , 'korean.png' , '' , '' , '' )
 Ii ( 'folder' , 'Lebanese' , str ( url ) + '&genre=lebanese' , 'grab_builds' , 'lebanese.png' , '' , '' , '' )
 Ii ( 'folder' , 'Mongolian' , str ( url ) + '&genre=mongolian' , 'grab_builds' , 'mongolian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Nepali' , str ( url ) + '&genre=nepali' , 'grab_builds' , 'nepali.png' , '' , '' , '' )
 Ii ( 'folder' , 'New Zealand' , str ( url ) + '&genre=newzealand' , 'grab_builds' , 'newzealand.png' , '' , '' , '' )
 Ii ( 'folder' , 'Norwegian' , str ( url ) + '&genre=norwegian' , 'grab_builds' , 'norwegian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Pakistani' , str ( url ) + '&genre=pakistani' , 'grab_builds' , 'pakistani.png' , '' , '' , '' )
 Ii ( 'folder' , 'Polish' , str ( url ) + '&genre=polish' , 'grab_builds' , 'polish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Portuguese' , str ( url ) + '&genre=portuguese' , 'grab_builds' , 'portuguese.png' , '' , '' , '' )
 Ii ( 'folder' , 'Romanian' , str ( url ) + '&genre=romanian' , 'grab_builds' , 'romanian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Russian' , str ( url ) + '&genre=russian' , 'grab_builds' , 'russian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Singapore' , str ( url ) + '&genre=singapore' , 'grab_builds' , 'singapore.png' , '' , '' , '' )
 Ii ( 'folder' , 'Spanish' , str ( url ) + '&genre=spanish' , 'grab_builds' , 'spanish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Swedish' , str ( url ) + '&genre=swedish' , 'grab_builds' , 'swedish.png' , '' , '' , '' )
 Ii ( 'folder' , 'Swiss' , str ( url ) + '&genre=swiss' , 'grab_builds' , 'swiss.png' , '' , '' , '' )
 Ii ( 'folder' , 'Syrian' , str ( url ) + '&genre=syrian' , 'grab_builds' , 'syrian.png' , '' , '' , '' )
 Ii ( 'folder' , 'Tamil' , str ( url ) + '&genre=tamil' , 'grab_builds' , 'tamil.png' , '' , '' , '' )
 Ii ( 'folder' , 'Thai' , str ( url ) + '&genre=thai' , 'grab_builds' , 'thai.png' , '' , '' , '' )
 Ii ( 'folder' , 'Turkish' , str ( url ) + '&genre=turkish' , 'grab_builds' , 'turkish.png' , '' , '' , '' )
 Ii ( 'folder' , 'UK' , str ( url ) + '&genre=uk' , 'grab_builds' , 'uk.png' , '' , '' , '' )
 Ii ( 'folder' , 'USA' , str ( url ) + '&genre=usa' , 'grab_builds' , 'usa.png' , '' , '' , '' )
 Ii ( 'folder' , 'Vietnamese' , str ( url ) + '&genre=vietnamese' , 'grab_builds' , 'vietnamese.png' , '' , '' , '' )
 if 49 - 49: IIII / i11iIiiIii * i11iIiiIii
 if 58 - 58: Ooo0Oo0
def IiIIi1IiiI1 ( ) :
 oO00oOo0OOO = 1
 oo00o ( )
 ii1ooO = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Community Builds' , 'My Builds' , '' ) )
 oOoOoO000OO = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Community Builds' , 'My Builds' , 'my_full_backup.zip' ) )
 ii11II11 = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Community Builds' , 'My Builds' , 'my_full_backup_GUI_Settings.zip' ) )
 if not os . path . exists ( ii1ooO ) :
  os . makedirs ( ii1ooO )
 oOooOo00OooO0oO = I1IIi ( heading = "Enter a name for this backup" )
 if ( not oOooOo00OooO0oO ) : return False , 0
 O0OOOo = urllib . quote_plus ( oOooOo00OooO0oO )
 i11I1I1iiI = xbmc . translatePath ( os . path . join ( ii1ooO , O0OOOo + '.zip' ) )
 I1i1iii1Ii = [ 'plugin.program.TBS' ]
 iI = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' ]
 O0O00OOo = [ 'plugin.program.TBS' , 'plugin.program.community.builds' , 'cache' , 'system' , 'Thumbnails' , "peripheral_data" , 'library' , 'keymaps' ]
 OoOOo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "Textures13.db" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'advancedsettings.xml' ]
 iii1 = "Creating full backup of existing build"
 oOO0oo = "Creating Community Build"
 II1iIi1IiIii = "Archiving..."
 I111I11I111 = ""
 iiiiI11ii = "Please Wait"
 if I11i11Ii == 'true' :
  iI1iIIIi1i ( ooOo , oOoOoO000OO , iii1 , II1iIi1IiIii , I111I11I111 , iiiiI11ii , I1i1iii1Ii , iI )
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( "Do you want to include your addon_data folder?" , 'This contains ALL addon settings including passwords.' , 'If you\'re intending on sharing this with others we stongly' , 'recommend against this unless all data has been manually removed.' , yeslabel = 'Yes' , nolabel = 'No' )
 if II1Ii1iI1i1 == 0 :
  O0i1i1II1i11 ( )
 elif II1Ii1iI1i1 == 1 :
  pass
 o00o ( ooOo )
 iii11II1I ( )
 iI1iIIIi1i ( ooOo , i11I1I1iiI , oOO0oo , II1iIi1IiIii , I111I11I111 , iiiiI11ii , O0O00OOo , OoOOo )
 time . sleep ( 1 )
 iI111I11i = xbmc . translatePath ( os . path . join ( ii1ooO , O0OOOo + '_guisettings.zip' ) )
 I1 = zipfile . ZipFile ( iI111I11i , mode = 'w' )
 try :
  I1 . write ( Oo0oO0ooo , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
 except : oO00oOo0OOO = 0
 try :
  I1 . write ( xbmc . translatePath ( os . path . join ( ooOo , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
 except : pass
 I1 . close ( )
 if I11i11Ii == 'true' :
  II1i11I1 = zipfile . ZipFile ( ii11II11 , mode = 'w' )
  try :
   II1i11I1 . write ( Oo0oO0ooo , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
  except : oO00oOo0OOO = 0
  if 2 - 2: oO0o0ooo - Ooo0Oo0
  try :
   II1i11I1 . write ( xbmc . translatePath ( os . path . join ( ooOo , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
  except : pass
  II1i11I1 . close ( )
 if oO00oOo0OOO == 0 :
  Oo0O . ok ( "FAILED!" , 'The guisettings.xml file could not be found on your' , 'system, please reboot and try again.' , '' )
 else :
  Oo0O . ok ( "SUCCESS!" , 'You Are Now Backed Up. If you\'d like to share this build with' , 'the community please post details on the forum at' , '[COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B]' )
  Oo0O . ok ( "Build Locations" , 'Full Backup (only used to restore on this device): [COLOR=yellow]' + oOoOoO000OO , '[/COLOR]Universal Backup (can be used on any device): [COLOR=yellow]' + i11I1I1iiI + '[/COLOR]' )
  if 26 - 26: II11iII / iiIi - o0O0 + oOOoO0O0O0
  if 38 - 38: IIII / iii11I111 . IIIIII11i1I / o0O0 / iiIi + o0o0OOO0o0
def ooO00O00oOO ( url , video ) :
 I1IIII1ii = 0
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/Community_Builds/community_builds_premium.php?id=%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IiIIi1I1I11Ii = re . compile ( 'path="(.+?)"' ) . findall ( IIiIi1iI )
 o0OO = re . compile ( 'myart="(.+?)"' ) . findall ( IIiIi1iI )
 OoiiIiI = re . compile ( 'artpack="(.+?)"' ) . findall ( IIiIi1iI )
 I1iIIiiIIi1i = re . compile ( 'videopreview="(.+?)"' ) . findall ( IIiIi1iI )
 o0Ooo0O00 = re . compile ( 'videoguide1="(.+?)"' ) . findall ( IIiIi1iI )
 ii1o0oooO = re . compile ( 'videoguide2="(.+?)"' ) . findall ( IIiIi1iI )
 ooOoo0oO0OoO0 = re . compile ( 'videoguide3="(.+?)"' ) . findall ( IIiIi1iI )
 oOOOOOoOO = re . compile ( 'videoguide4="(.+?)"' ) . findall ( IIiIi1iI )
 oooo00 = re . compile ( 'videoguide5="(.+?)"' ) . findall ( IIiIi1iI )
 i1oO = re . compile ( 'videolabel1="(.+?)"' ) . findall ( IIiIi1iI )
 iIIi1IIi = re . compile ( 'videolabel2="(.+?)"' ) . findall ( IIiIi1iI )
 i111i11I1ii = re . compile ( 'videolabel3="(.+?)"' ) . findall ( IIiIi1iI )
 OOooo = re . compile ( 'videolabel4="(.+?)"' ) . findall ( IIiIi1iI )
 oo0 = re . compile ( 'videolabel5="(.+?)"' ) . findall ( IIiIi1iI )
 i1iIi = re . compile ( 'name="(.+?)"' ) . findall ( IIiIi1iI )
 oOOII1i11i1iIi11 = re . compile ( 'author="(.+?)"' ) . findall ( IIiIi1iI )
 i1II1Iiii1I11 = re . compile ( 'version="(.+?)"' ) . findall ( IIiIi1iI )
 oo0O0oO0O0O = re . compile ( 'description="(.+?)"' ) . findall ( IIiIi1iI )
 oOo0O = re . compile ( 'DownloadURL="(.+?)"' ) . findall ( IIiIi1iI )
 o0O0OOO0Ooo = re . compile ( 'updated="(.+?)"' ) . findall ( IIiIi1iI )
 I11i = re . compile ( 'defaultskin="(.+?)"' ) . findall ( IIiIi1iI )
 Iiii1 = re . compile ( 'skins="(.+?)"' ) . findall ( IIiIi1iI )
 iIIIiiiI11I = re . compile ( 'videoaddons="(.+?)"' ) . findall ( IIiIi1iI )
 I1ii1111Ii = re . compile ( 'audioaddons="(.+?)"' ) . findall ( IIiIi1iI )
 o0OiiiI1i11Ii = re . compile ( 'programaddons="(.+?)"' ) . findall ( IIiIi1iI )
 iIiII = re . compile ( 'pictureaddons="(.+?)"' ) . findall ( IIiIi1iI )
 i1i1IIIIIIIi = re . compile ( 'sources="(.+?)"' ) . findall ( IIiIi1iI )
 oo0o0oOo = re . compile ( 'adult="(.+?)"' ) . findall ( IIiIi1iI )
 OO0oOOo0o = re . compile ( 'guisettings="(.+?)"' ) . findall ( IIiIi1iI )
 if 50 - 50: OoO0O00 . iii11I111 . iiiIi1i1I * oOOoO0O0O0 + ii1I11II1ii1i % i11iIiiIii
 i1i1IiIiIi1Ii = o0OO [ 0 ] if ( len ( o0OO ) > 0 ) else ''
 oO0ooOO = OoiiIiI [ 0 ] if ( len ( OoiiIiI ) > 0 ) else ''
 oo0000Oo00o = IiIIi1I1I11Ii [ 0 ] if ( len ( IiIIi1I1I11Ii ) > 0 ) else ''
 I1II1 = i1iIi [ 0 ] if ( len ( i1iIi ) > 0 ) else ''
 IIi1iI1 = oOOII1i11i1iIi11 [ 0 ] if ( len ( oOOII1i11i1iIi11 ) > 0 ) else ''
 i1i1iI1iiiI = i1II1Iiii1I11 [ 0 ] if ( len ( i1II1Iiii1I11 ) > 0 ) else ''
 IIII1 = oo0O0oO0O0O [ 0 ] if ( len ( oo0O0oO0O0O ) > 0 ) else 'No information available'
 iiIiIIIiiI = o0O0OOO0Ooo [ 0 ] if ( len ( o0O0OOO0Ooo ) > 0 ) else ''
 IIi11i1II = I11i [ 0 ] if ( len ( I11i ) > 0 ) else ''
 OO0ooo0o0 = Iiii1 [ 0 ] if ( len ( Iiii1 ) > 0 ) else ''
 oO0ooOoO = iIIIiiiI11I [ 0 ] if ( len ( iIIIiiiI11I ) > 0 ) else ''
 ooO0000o00O = I1ii1111Ii [ 0 ] if ( len ( I1ii1111Ii ) > 0 ) else ''
 O0Ooo = o0OiiiI1i11Ii [ 0 ] if ( len ( o0OiiiI1i11Ii ) > 0 ) else ''
 oO00oOOo0Oo = iIiII [ 0 ] if ( len ( iIiII ) > 0 ) else ''
 IIiIIIIii = i1i1IIIIIIIi [ 0 ] if ( len ( i1i1IIIIIIIi ) > 0 ) else ''
 iIiI1 = oo0o0oOo [ 0 ] if ( len ( oo0o0oOo ) > 0 ) else ''
 iIIiI1ii = OO0oOOo0o [ 0 ] if ( len ( OO0oOOo0o ) > 0 ) else 'None'
 oo0OOoOoo0O0O = oOo0O [ 0 ] if ( len ( oOo0O ) > 0 ) else 'None'
 o0OoOO = I1iIIiiIIi1i [ 0 ] if ( len ( I1iIIiiIIi1i ) > 0 ) else 'None'
 oOoO00o = o0Ooo0O00 [ 0 ] if ( len ( o0Ooo0O00 ) > 0 ) else 'None'
 oO00O0 = ii1o0oooO [ 0 ] if ( len ( ii1o0oooO ) > 0 ) else 'None'
 IIi1IIIi = ooOoo0oO0OoO0 [ 0 ] if ( len ( ooOoo0oO0OoO0 ) > 0 ) else 'None'
 O00Ooo = oOOOOOoOO [ 0 ] if ( len ( oOOOOOoOO ) > 0 ) else 'None'
 OOOO0OOO = oooo00 [ 0 ] if ( len ( oooo00 ) > 0 ) else 'None'
 ii1IIII = i1oO [ 0 ] if ( len ( i1oO ) > 0 ) else 'None'
 oO00oOooooo0 = iIIi1IIi [ 0 ] if ( len ( iIIi1IIi ) > 0 ) else 'None'
 oOo = i111i11I1ii [ 0 ] if ( len ( i111i11I1ii ) > 0 ) else 'None'
 O0OOooOoO = OOooo [ 0 ] if ( len ( OOooo ) > 0 ) else 'None'
 i1II1I1Iii1 = oo0 [ 0 ] if ( len ( oo0 ) > 0 ) else 'None'
 OooOOOo0 = open ( oooOOOOO , mode = 'w+' )
 OooOOOo0 . write ( 'id="' + str ( video ) + '"\nname="' + I1II1 + '"\nversion="' + i1i1iI1iiiI + '"' )
 OooOOOo0 . close ( )
 O0oOoOO ( 'Full description' , 'None' , 'description' , 'BUILDDETAILS.png' , oo000 , I1II1 , IIi1iI1 , i1i1iI1iiiI , IIII1 , iiIiIIIiiI , OO0ooo0o0 , oO0ooOoO , ooO0000o00O , O0Ooo , oO00oOOo0Oo , IIiIIIIii , iIiI1 )
 if o0OoOO != 'None' :
  Ii ( '' , 'Watch Preview Video' , o0OoOO , 'play_video' , 'Video_Preview.png' , oo000 , '' , '' )
 if oOoO00o != 'None' :
  Ii ( '' , '(VIDEO) ' + ii1IIII , oOoO00o , 'play_video' , 'Video_Guide.png' , oo000 , '' , '' )
 if oO00O0 != 'None' :
  Ii ( '' , '(VIDEO) ' + oO00oOooooo0 , oO00O0 , 'play_video' , 'Video_Guide.png' , oo000 , '' , '' )
 if IIi1IIIi != 'None' :
  Ii ( '' , '(VIDEO) ' + oOo , IIi1IIIi , 'play_video' , 'Video_Guide.png' , oo000 , '' , '' )
 if O00Ooo != 'None' :
  Ii ( '' , '(VIDEO) ' + O0OOooOoO , O00Ooo , 'play_video' , 'Video_Guide.png' , oo000 , '' , '' )
 if OOOO0OOO != 'None' :
  Ii ( '' , '(VIDEO) ' + i1II1I1Iii1 , OOOO0OOO , 'play_video' , 'Video_Guide.png' , oo000 , '' , '' )
 if oo0OOoOoo0O0O == 'None' :
  Oo0oOOo ( '[COLOR=gold]Sorry this build is currently unavailable[/COLOR]' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 if OOOo00oo0oO . endswith ( "visibility=premium" ) or OOOo00oo0oO . endswith ( "visibility=reseller_private" ) :
  if ( oo0000Oo00o != '' ) and ( oo0000Oo00o != 'fail' ) and ( os . path . exists ( oo0000Oo00o ) ) :
   Oo0oOOo ( '[COLOR=lime]Install Part 1: Download ' + I1II1 + '[/COLOR]' , oo0OOoOoo0O0O , 'restore_community' , OO0ooo0oOO , oo000 , i1i1IiIiIi1Ii , I1II1 , IIi11i1II , iIIiI1ii , oO0ooOO )
  if ( ( oo0000Oo00o != '' ) and not os . path . exists ( oo0000Oo00o ) and ( oo0000Oo00o != 'fail' ) ) :
   I1IIII1ii = 1
   Oo0O . ok ( "Security check failed, contact box seller" , 'This box cannot be identified as an official' , '[COLOR=lime]' + I1IiiI + '[/COLOR] product. Please contact the' , 'seller you purchased this device from for more details.' )
  if oo0000Oo00o == 'fail' :
   I1IIII1ii = 1
   Oo0O . ok ( "Subscription not paid" , 'The box seller has either opted out of the premium' , 'plan or has unpaid debts to the Community Builders.' , 'Please contact the seller you purchased this device from for more details.' )
  if oo0000Oo00o == '' :
   Oo0oOOo ( '[COLOR=lime]Install Part 1: Download ' + I1II1 + '[/COLOR]' , oo0OOoOoo0O0O , 'restore_community' , OO0ooo0oOO , oo000 , i1i1IiIiIi1Ii , I1II1 , IIi11i1II , iIIiI1ii , oO0ooOO )
 else :
  Oo0oOOo ( '[COLOR=lime]Install Part 1: Download ' + I1II1 + '[/COLOR]' , oo0OOoOoo0O0O , 'restore_community' , OO0ooo0oOO , oo000 , '' , I1II1 , IIi11i1II , iIIiI1ii , oO0ooOO )
 if I1IIII1ii == 0 :
  if iIIiI1ii == 'None' :
   pass
  else :
   Ii ( '' , '[COLOR=dodgerblue]Install Part 2: Apply guisettings.xml fix[/COLOR]' , iIIiI1ii , 'guisettingsfix' , 'FixMy_Build.png' , oo000 , '' , '' )
   if 15 - 15: OoO0O00
def i1ii1111i1i ( url , video ) :
 iIiI ( 'disclaimer.xml' )
 ooO00O00oOO ( url , video )
 if 26 - 26: o0o0OOO0o0 % i11iIiiIii % iii11I111
 if 67 - 67: IIII
def O0i1i1II1i11 ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 IiIiIi1I1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( IiIiIi1I1 ) :
  oooOOOoOOOo0O = 0
  oooOOOoOOOo0O += len ( O0Oo0o000oO )
  if 82 - 82: ooOO0o * i11iIiiIii % ii1I11II1ii1i - IIII
  if oooOOOoOOOo0O >= 0 :
   for oOOOO in O0Oo0o000oO :
    os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
   for OOOoO000 in o0O0Oo00 :
    shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
    if 90 - 90: iiIi . Ooo0Oo0 * o0O0 - o0O0
    if 16 - 16: oO0o0ooo * o0O0 - OoOo . ooOO0o % oOOoO0O0O0 / OoOo
def Ii11iI1ii1111 ( ) :
 for i111i1i in glob . glob ( os . path . join ( OOooO0OOoo , 'xbmc_crashlog*.*' ) ) :
  IiIii1I1I = i111i1i
  os . remove ( i111i1i )
  Oo0O = xbmcgui . Dialog ( )
  Oo0O . ok ( "Crash Logs Deleted" , "Your old crash logs have now been deleted." )
  if 51 - 51: iiIi % II11iII * IIII . i11iIiiIii
  if 77 - 77: ii1I11II1ii1i
def iii11II1I ( ) :
 print '############################################################       DELETING PACKAGES             ###############################################################'
 I1i111IiIiIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( I1i111IiIiIi1 ) :
  oooOOOoOOOo0O = 0
  oooOOOoOOOo0O += len ( O0Oo0o000oO )
  if 39 - 39: oOOoO0O0O0 - iii11I111
  if oooOOOoOOOo0O > 0 :
   for oOOOO in O0Oo0o000oO :
    os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
   for OOOoO000 in o0O0Oo00 :
    shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
    if 53 - 53: OoOo % OoO0O00 + i1OOO . iiIi - iii11I111 % OoOo
    if 64 - 64: ii1I11II1ii1i
def iIIIiIi1I1i ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 IiIiIi1I1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( IiIiIi1I1 ) :
  oooOOOoOOOo0O = 0
  oooOOOoOOOo0O += len ( O0Oo0o000oO )
  if 78 - 78: o0o0OOO0o0 % II11iII + iii11I111 / o0O0 % ii1I11II1ii1i + OOO00OoOO00
  if oooOOOoOOOo0O >= 0 :
   for oOOOO in O0Oo0o000oO :
    os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
   for OOOoO000 in o0O0Oo00 :
    shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
    if 91 - 91: o0o0OOO0o0 % iiiIi1i1I . OoOo + Oo000o + OoOo
    if 95 - 95: Oo000o + iii11I111 * OOO00OoOO00
def Ii111iIi1iIi ( name , addon_id ) :
 oooooOOO000Oo = 1
 ii11i1iIiII1 = 1
 I1Ii = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , addon_id , 'addon.xml' ) )
 ooooOoO0O = open ( I1Ii , mode = 'r' )
 IIIIIIII = ooooOoO0O . read ( )
 ooooOoO0O . close ( )
 oOoOo0oOo0O0O0o = re . compile ( 'import addon="(.+?)"' ) . findall ( IIIIIIII )
 for OOoOooOoOOOoo in oOoOo0oOo0O0O0o :
  if not 'xbmc.python' in OOoOooOoOOOoo :
   print 'Script Requires --- ' + OOoOooOoOOOoo
   IiiIIiIIii1iI = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , OOoOooOoOOOoo ) )
   if not os . path . exists ( IiiIIiIIii1iI ) :
    OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/AddonPortal/dependencyinstall.php?id=%s' % ( OOoOooOoOOOoo )
    IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    i1iIi = re . compile ( 'name="(.+?)"' ) . findall ( IIiIi1iI )
    i1II1Iiii1I11 = re . compile ( 'version="(.+?)"' ) . findall ( IIiIi1iI )
    i1Ii = re . compile ( 'repo_url="(.+?)"' ) . findall ( IIiIi1iI )
    ii111iI1iIi1 = re . compile ( 'data_url="(.+?)"' ) . findall ( IIiIi1iI )
    OOO = re . compile ( 'zip_url="(.+?)"' ) . findall ( IIiIi1iI )
    O0ooO0Oo00o = re . compile ( 'repo_id="(.+?)"' ) . findall ( IIiIi1iI )
    Oo0O0O000 = i1iIi [ 0 ] if ( len ( i1iIi ) > 0 ) else ''
    i1i1iI1iiiI = i1II1Iiii1I11 [ 0 ] if ( len ( i1II1Iiii1I11 ) > 0 ) else ''
    II1Ii = i1Ii [ 0 ] if ( len ( i1Ii ) > 0 ) else ''
    OOoO00ooO = ii111iI1iIi1 [ 0 ] if ( len ( ii111iI1iIi1 ) > 0 ) else ''
    I1IIIIiii1i = OOO [ 0 ] if ( len ( OOO ) > 0 ) else ''
    o0IiiiI111I = O0ooO0Oo00o [ 0 ] if ( len ( O0ooO0Oo00o ) > 0 ) else ''
    III1I11i1iIi = xbmc . translatePath ( os . path . join ( OooO0 , Oo0O0O000 + '.zip' ) )
    try :
     downloader . download ( II1Ii , III1I11i1iIi , IiI )
     extract . all ( III1I11i1iIi , ooOoOoo0O , IiI )
    except :
     try :
      downloader . download ( I1IIIIiii1i , III1I11i1iIi , IiI )
      extract . all ( III1I11i1iIi , ooOoOoo0O , IiI )
     except :
      try :
       if not os . path . exists ( IiiIIiIIii1iI ) :
        os . makedirs ( IiiIIiIIii1iI )
       IIiIi1iI = i1IiiiI1iI ( OOoO00ooO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
       IIII1iII = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IIiIi1iI )
       for ii1III11 in IIII1iII :
        I1iiIIIi11 = xbmc . translatePath ( os . path . join ( IiiIIiIIii1iI , ii1III11 ) )
        if addon_id not in ii1III11 and '/' not in ii1III11 :
         try :
          IiI . update ( 0 , "Downloading [COLOR=yellow]" + ii1III11 + '[/COLOR]' , '' , 'Please wait...' )
          print "downloading: " + OOoO00ooO + ii1III11
          downloader . download ( OOoO00ooO + ii1III11 , I1iiIIIi11 , IiI )
         except : print "failed to install" + ii1III11
        if '/' in ii1III11 and '..' not in ii1III11 and 'http' not in ii1III11 :
         Ii1I11ii1i = OOoO00ooO + ii1III11
         O0iIiIIIIIii ( I1iiIIIi11 , Ii1I11ii1i )
      except :
       Oo0O . ok ( "Error downloading dependency" , 'There was an error downloading [COLOR=yellow]' + Oo0O0O000 , '[/COLOR]Please consider updating the add-on portal with details' , 'or report the error on the forum at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B]' )
       ii11i1iIiII1 = 0
       oooooOOO000Oo = 0
    if ii11i1iIiII1 == 1 :
     time . sleep ( 1 )
     IiI . update ( 0 , "[COLOR=yellow]" + Oo0O0O000 + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Please wait...' )
     time . sleep ( 1 )
     oO0oo = 'http://totalxbmc.com/totalrevolution/AddonPortal/downloadcount.php?id=%s' % ( OOoOooOoOOOoo )
     i1IiiiI1iI ( oO0oo )
 IiI . close ( )
 time . sleep ( 1 )
 if 69 - 69: iiIi * ii1I11II1ii1i * i1OOO . OoO0O00 - iii11I111
 if 39 - 39: Oo000o * oO0o0ooo % iiiIi1i1I . II11iII
def iiii111IiIIi1 ( name , url , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 Oo0000o0O0O ( buildname + '     v.' + version , '[COLOR=yellow][B]Author:   [/B][/COLOR]' + author + '[COLOR=yellow][B]               Last Updated:   [/B][/COLOR]' + updated + '[COLOR=yellow][B]               Adult Content:   [/B][/COLOR]' + adult + '[CR][CR][COLOR=yellow][B]Description:[CR][/B][/COLOR]' + description +
 '[CR][CR][COLOR=blue][B]Skins:   [/B][/COLOR]' + skins + '[CR][CR][COLOR=blue][B]Video Addons:   [/B][/COLOR]' + videoaddons + '[CR][CR][COLOR=blue][B]Audio Addons:   [/B][/COLOR]' + audioaddons +
 '[CR][CR][COLOR=blue][B]Program Addons:   [/B][/COLOR]' + programaddons + '[CR][CR][COLOR=blue][B]Picture Addons:   [/B][/COLOR]' + pictureaddons + '[CR][CR][COLOR=blue][B]Sources:   [/B][/COLOR]' + sources +
 '[CR][CR][COLOR=gold]Disclaimer: [/COLOR]These are community builds and they may overwrite some of your existing settings, '
 'TotalXBMC take no responsibility over what content is included in these builds, it\'s up to the individual who uploads the build to state what\'s included and then the users decision to decide whether or not that content is suitable for them.' )
 if 1 - 1: iii11I111 % II11iII . OoOo . oO0o0ooo - oO0o0ooo - ooOO0o
 if 33 - 33: oO0o0ooo / iiiIi1i1I
def iiIIi ( path ) :
 IiI . create ( "[COLOR=blue]T[/COLOR]otal[COLOR=dodgerblue]R[/COLOR]evolution" , "Wiping..." , '' , 'Please Wait' )
 shutil . rmtree ( path , ignore_errors = True )
 if 36 - 36: oOOoO0O0O0 . ii1I11II1ii1i
def iIIiI1iiI ( url , dest , dp = None ) :
 if not dp :
  dp = xbmcgui . DialogProgress ( )
  dp . create ( "Speed Test" , "Testing your internet speed..." , ' ' , ' ' )
 dp . update ( 0 )
 I11Ii111I = time . time ( )
 if 98 - 98: o0o0OOO0o0 + O0oO % II11iII + oOOoO0O0O0 % II11iII
 try :
  urllib . urlretrieve ( url , dest , lambda iI1I1I11IiII , iIii11iI1II , I1II1I1I : Oo0O0OOOoo ( iI1I1I11IiII , iIii11iI1II , I1II1I1I , dp , I11Ii111I ) )
 except :
  pass
  if 79 - 79: OOO00OoOO00 / O0oO . II11iII - iii11I111
  if 47 - 47: IIII % IIIIII11i1I * OoO0O00 . Oo000o
 return ( time . time ( ) - I11Ii111I )
 if 38 - 38: IIIIII11i1I - ooOO0o % O0oO
def O00OO ( ) :
 os . remove ( i1iiIII111ii )
 os . rename ( i1iIIi1 , i1iiIII111ii )
 xbmc . executebuiltin ( 'UnloadSkin' )
 xbmc . executebuiltin ( "ReloadSkin" )
 Oo0O . ok ( "Local Restore Complete" , 'XBMC/Kodi will now close.' , '' , '' )
 xbmc . executebuiltin ( "Quit" )
 if 64 - 64: o0o0OOO0o0
 if 15 - 15: iii11I111 + OOO00OoOO00 / iii11I111 / O0oO
def o00o ( url ) :
 IiI . create ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "Renaming paths..." , '' , 'Please Wait' )
 for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( url ) :
  for file in O0Oo0o000oO :
   if file . endswith ( ".xml" ) :
    IiI . update ( 0 , "Fixing" , file , 'Please Wait' )
    i11I1II = open ( ( os . path . join ( IiI1ii1Ii , file ) ) ) . read ( )
    I1Iii1I = i11I1II . replace ( ooOo , 'special://home/' )
    oOOOO = open ( ( os . path . join ( IiI1ii1Ii , file ) ) , mode = 'w' )
    oOOOO . write ( str ( I1Iii1I ) )
    oOOOO . close ( )
    if 13 - 13: OoOo + IIIIII11i1I
    if 71 - 71: ooOO0o + o0O0 * iiIi % iiIi / iiIi
def OoO00o0 ( ) :
 IIiIi1iI = i1IiiiI1iI ( 'http://totalxbmc.tv/totalrevolution/Addon_Fix/addonfix.txt' ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIII1iII = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( IIiIi1iI )
 for I1II1 , ooo0oOOO0 , OO0ooo0oOO , oo000 , IIII1 in IIII1iII :
  Ii ( '' , I1II1 , ooo0oOOO0 , 'OSS' , OO0ooo0oOO , oo000 , '' , IIII1 )
  if 61 - 61: OoOo / II11iII - iiIi
  if 19 - 19: OoO0O00 - OoOo / OoOo + iiIi
def OoO0o0000O ( url ) :
 Ii ( 'folder' , 'Anime' , str ( url ) + '&genre=anime' , 'grab_builds' , 'anime.png' , '' , '' , '' )
 Ii ( 'folder' , 'Audiobooks' , str ( url ) + '&genre=audiobooks' , 'grab_builds' , 'audiobooks.png' , '' , '' , '' )
 Ii ( 'folder' , 'Comedy' , str ( url ) + '&genre=comedy' , 'grab_builds' , 'comedy.png' , '' , '' , '' )
 Ii ( 'folder' , 'Comics' , str ( url ) + '&genre=comics' , 'grab_builds' , 'comics.png' , '' , '' , '' )
 Ii ( 'folder' , 'Documentary' , str ( url ) + '&genre=documentary' , 'grab_builds' , 'documentary.png' , '' , '' , '' )
 Ii ( 'folder' , 'Downloads' , str ( url ) + '&genre=downloads' , 'grab_builds' , 'downloads.png' , '' , '' , '' )
 Ii ( 'folder' , 'Food' , str ( url ) + '&genre=food' , 'grab_builds' , 'food.png' , '' , '' , '' )
 Ii ( 'folder' , 'Gaming' , str ( url ) + '&genre=gaming' , 'grab_builds' , 'gaming.png' , '' , '' , '' )
 Ii ( 'folder' , 'Health' , str ( url ) + '&genre=health' , 'grab_builds' , 'health.png' , '' , '' , '' )
 Ii ( 'folder' , 'How To...' , str ( url ) + '&genre=howto' , 'grab_builds' , 'howto.png' , '' , '' , '' )
 Ii ( 'folder' , 'Kids' , str ( url ) + '&genre=kids' , 'grab_builds' , 'kids.png' , '' , '' , '' )
 Ii ( 'folder' , 'Live TV' , str ( url ) + '&genre=livetv' , 'grab_builds' , 'livetv.png' , '' , '' , '' )
 Ii ( 'folder' , 'Movies' , str ( url ) + '&genre=movies' , 'grab_builds' , 'movies.png' , '' , '' , '' )
 Ii ( 'folder' , 'Music' , str ( url ) + '&genre=music' , 'grab_builds' , 'music.png' , '' , '' , '' )
 Ii ( 'folder' , 'News' , str ( url ) + '&genre=news' , 'grab_builds' , 'news.png' , '' , '' , '' )
 Ii ( 'folder' , 'Photos' , str ( url ) + '&genre=photos' , 'grab_builds' , 'photos.png' , '' , '' , '' )
 Ii ( 'folder' , 'Podcasts' , str ( url ) + '&genre=podcasts' , 'grab_builds' , 'podcasts.png' , '' , '' , '' )
 Ii ( 'folder' , 'Radio' , str ( url ) + '&genre=radio' , 'grab_builds' , 'radio.png' , '' , '' , '' )
 Ii ( 'folder' , 'Religion' , str ( url ) + '&genre=religion' , 'grab_builds' , 'religion.png' , '' , '' , '' )
 Ii ( 'folder' , 'Space' , str ( url ) + '&genre=space' , 'grab_builds' , 'space.png' , '' , '' , '' )
 Ii ( 'folder' , 'Sports' , str ( url ) + '&genre=sports' , 'grab_builds' , 'sports.png' , '' , '' , '' )
 Ii ( 'folder' , 'Technology' , str ( url ) + '&genre=tech' , 'grab_builds' , 'tech.png' , '' , '' , '' )
 Ii ( 'folder' , 'Trailers' , str ( url ) + '&genre=trailers' , 'grab_builds' , 'trailers.png' , '' , '' , '' )
 Ii ( 'folder' , 'TV Shows' , str ( url ) + '&genre=tv' , 'grab_builds' , 'tv.png' , '' , '' , '' )
 Ii ( 'folder' , 'Misc.' , str ( url ) + '&genre=other' , 'grab_builds' , 'other.png' , '' , '' , '' )
 if Oo0Ooo . getSetting ( 'adult' ) == 'true' :
  Ii ( 'folder' , 'XXX' , str ( url ) + '&genre=adult' , 'grab_builds' , 'adult.png' , '' , '' , '' )
  if 8 - 8: II11iII . i1OOO % Ooo0Oo0 . oO0o0ooo % oO0o0ooo . Oo000o
def I1I11ii ( ) :
 OOoOoo00Oo = datetime . datetime . now ( )
 Iiii1iiiIiI1 = time . mktime ( OOoOoo00Oo . timetuple ( ) ) + ( OOoOoo00Oo . microsecond / 1000000. )
 I11Iii1 = str ( '%f' % Iiii1iiiIiI1 )
 I11Iii1 = I11Iii1 . replace ( '.' , '' )
 I11Iii1 = I11Iii1 [ : - 3 ]
 return I11Iii1
 if 16 - 16: Oo000o * iiiIi1i1I / Ooo0Oo0
def I1IIi ( default = "" , heading = "" , hidden = False ) :
 II1iiI = xbmc . Keyboard ( default , heading , hidden )
 if 31 - 31: OoOo % oOOoO0O0O0 + o0o0OOO0o0 + i11iIiiIii * O0oO
 II1iiI . doModal ( )
 if ( II1iiI . isConfirmed ( ) ) :
  return unicode ( II1iiI . getText ( ) , "utf-8" )
 return default
 if 45 - 45: OOO00OoOO00 * O0oO . i1OOO - O0oO + ooOO0o
 if 34 - 34: OOO00OoOO00 . iiIi
 if 78 - 78: iii11I111 % oO0o0ooo / IIII % OOO00OoOO00 - OoO0O00
 if 2 - 2: o0o0OOO0o0
 if 45 - 45: IIII / i11iIiiIii
 if 10 - 10: OoO0O00 - Ooo0Oo0 * o0o0OOO0o0 % o0o0OOO0o0 * ooOO0o - iii11I111
 if 97 - 97: ii1I11II1ii1i % O0oO + O0oO - iiiIi1i1I / Oo000o * oO0o0ooo
 if 17 - 17: Oo000o
 if 39 - 39: i1OOO . ii1I11II1ii1i
 if 45 - 45: Ooo0Oo0 * II11iII / o0o0OOO0o0
 if 77 - 77: O0oO - oOOoO0O0O0
 if 11 - 11: iii11I111
 if 26 - 26: o0o0OOO0o0 * O0oO - OOO00OoOO00
 if 27 - 27: iii11I111 * O0oO - iiiIi1i1I + Oo000o * Oo000o
 if 55 - 55: i1OOO
 if 82 - 82: O0oO - OOO00OoOO00 + iiiIi1i1I
 if 64 - 64: OoOo . IIIIII11i1I * Oo000o + IIII - iiIi . IIII
 if 70 - 70: iiIi - Ooo0Oo0 . o0o0OOO0o0 % oOOoO0O0O0 / II11iII - IIIIII11i1I
 if 55 - 55: OoO0O00 - iiiIi1i1I
 if 100 - 100: IIIIII11i1I
 if 79 - 79: o0o0OOO0o0
 if 81 - 81: OOO00OoOO00 + o0o0OOO0o0 * O0oO - o0o0OOO0o0 . OOO00OoOO00
 if 48 - 48: oOOoO0O0O0 . IIII . oO0o0ooo . II11iII % iii11I111 / OoO0O00
 if 11 - 11: o0O0 % iiiIi1i1I % OoO0O00
 if 99 - 99: i1OOO / o0o0OOO0o0 - Oo000o * iii11I111 % oO0o0ooo
 if 13 - 13: iiiIi1i1I
 if 70 - 70: O0oO + IIIIII11i1I . Ooo0Oo0 * Oo000o
 if 2 - 2: IIII . OOO00OoOO00 . ooOO0o
def I1iIII1IiiI ( ) :
 OOoooOoO0Oo = [ ]
 Oo000 = sys . argv [ 2 ]
 if len ( Oo000 ) >= 2 :
  iiIiII11i1 = sys . argv [ 2 ]
  oOo00Ooo0o0 = iiIiII11i1 . replace ( '?' , '' )
  if ( iiIiII11i1 [ len ( iiIiII11i1 ) - 1 ] == '/' ) :
   iiIiII11i1 = iiIiII11i1 [ 0 : len ( iiIiII11i1 ) - 2 ]
  i1IiII1i1I = oOo00Ooo0o0 . split ( '&' )
  OOoooOoO0Oo = { }
  for iI1ii1ii1I in range ( len ( i1IiII1i1I ) ) :
   iI1IIi11i1I1 = { }
   iI1IIi11i1I1 = i1IiII1i1I [ iI1ii1ii1I ] . split ( '=' )
   if ( len ( iI1IIi11i1I1 ) ) == 2 :
    OOoooOoO0Oo [ iI1IIi11i1I1 [ 0 ] ] = iI1IIi11i1I1 [ 1 ]
    if 60 - 60: oOOoO0O0O0 / o0O0 % iii11I111 / iii11I111 * iii11I111 . i11iIiiIii
 return OOoooOoO0Oo
 if 99 - 99: II11iII
def oO00OoOo ( ) :
 oo0000Oo00o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 IiI = xbmcgui . DialogProgress ( )
 IiI . create ( "Gotham Addon Fix" , "Please wait whilst your addons" , '' , 'are being made Gotham compatible.' )
 for i111i1i in glob . glob ( os . path . join ( oo0000Oo00o , '*.*' ) ) :
  for file in glob . glob ( os . path . join ( i111i1i , '*.*' ) ) :
   if 'addon.xml' in file :
    IiI . update ( 0 , "Fixing" , file , 'Please Wait' )
    i11I1II = open ( file ) . read ( )
    I1Iii1I = i11I1II . replace ( 'addon="xbmc.python" version="1.0"' , 'addon="xbmc.python" version="2.1.0"' ) . replace ( 'addon="xbmc.python" version="2.0"' , 'addon="xbmc.python" version="2.1.0"' )
    oOOOO = open ( file , mode = 'w' )
    oOOOO . write ( str ( I1Iii1I ) )
    oOOOO . close ( )
    if 74 - 74: ii1I11II1ii1i . IIIIII11i1I - oO0o0ooo + ooOO0o % i11iIiiIii % II11iII
 Oo0O = xbmcgui . Dialog ( )
 Oo0O . ok ( "Your addons have now been made compatible" , "If you still find you have addons that aren't working please run the addon so it throws up a script error, upload a log and post details on the forum at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B] so the team can look into it. Thank you." )
 if 78 - 78: Oo000o + II11iII + ooOO0o - ooOO0o . i11iIiiIii / iiiIi1i1I
 if 27 - 27: Oo000o - IIIIII11i1I % oOOoO0O0O0 * O0oO . ooOO0o % o0o0OOO0o0
def IiIi1i ( ) :
 Oo0O = xbmcgui . Dialog ( )
 oO0O0oO = xbmcgui . Dialog ( ) . yesno ( 'Convert Addons To Gotham' , 'This will edit your addon.xml files so they show as Gotham compatible. It\'s doubtful this will have any effect on whether or not they work but it will get rid of the annoying incompatible pop-up message. Do you wish to continue?' )
 if oO0O0oO == 0 :
  return
 elif oO0O0oO == 1 :
  oO00OoOo ( )
  if 27 - 27: IIIIII11i1I / II11iII + o0o0OOO0o0 - OOO00OoOO00 % OoOo
  if 30 - 30: O0oO % O0oO % ooOO0o . II11iII
def I1ii1 ( url ) :
 if Oo0Ooo . getSetting ( 'adult' ) == 'true' :
  iIiI1 = 'yes'
 else :
  iIiI1 = 'no'
 IIi1IiII = 'http://totalxbmc.com/totalrevolution/AddonPortal/sortby.php?sortx=name&user=%s&pass=%s&adult=%s&%s' % ( oO00oOo , OOOo0 , iIiI1 , url )
 IIiIi1iI = i1IiiiI1iI ( IIi1IiII ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIII1iII = re . compile ( 'name="(.+?)" <br> downloads="(.+?)" <br> icon="(.+?)" <br> UID="(.+?)" <br>' , re . DOTALL ) . findall ( IIiIi1iI )
 o0IIIIiI11I ( IIi1IiII , 'addons' )
 for I1II1 , iiI1IIIi , I1ii1ii11i1I , iiiI11iIIi1 in IIII1iII :
  Ii ( 'folder2' , I1II1 + '[COLOR=lime] [' + iiI1IIIi + ' downloads][/COLOR]' , iiiI11iIIi1 , 'addon_final_menu' , I1ii1ii11i1I , '' , '' )
  if 72 - 72: OoO0O00 * OOO00OoOO00
  if 67 - 67: o0O0
def iii ( url ) :
 if zip == '' :
  Oo0O . ok ( '[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]' , 'You have not set your backup storage folder.\nPlease update the addon settings and try again.' , '' , '' )
  Oo0Ooo . openSettings ( sys . argv [ 0 ] )
 oo0oO = xbmc . getInfoLabel ( "System.BuildVersion" )
 i1i1iI1iiiI = float ( oo0oO [ : 4 ] )
 if i1i1iI1iiiI < 14 :
  oOOOo = 'gotham'
 else :
  oOOOo = 'helix'
  if 31 - 31: II11iII + II11iII . i11iIiiIii / i1OOO % oOOoO0O0O0 / II11iII
 if Oo0Ooo . getSetting ( 'adult' ) == 'true' :
  iIiI1 = ''
 else :
  iIiI1 = 'no'
 IIi1IiII = 'http://totalxbmc.com/totalrevolution/Community_Builds/sortby.php?sortx=name&orderx=ASC&xbmc=%s&adult=%s&%s' % ( oOOOo , iIiI1 , url )
 IIiIi1iI = i1IiiiI1iI ( IIi1IiII ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIII1iII = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> Thumbnail="(.+?)" <br> Fanart="(.+?)" <br> downloads="(.+?)" <br> <br>' , re . DOTALL ) . findall ( IIiIi1iI )
 o0IIIIiI11I ( url , 'communitybuilds' )
 for I1II1 , id , IIiI1I111iIiI , ooO , iiI1IIIi in IIII1iII :
  Oo0oOOo ( I1II1 + '[COLOR=lime] (' + iiI1IIIi + ' downloads)[/COLOR]' , id + url , 'community_menu' , IIiI1I111iIiI , ooO , id , '' , '' , '' , '' )
  if 59 - 59: ii1I11II1ii1i * i11iIiiIii
  if 54 - 54: IIIIII11i1I % IIII - oO0o0ooo
def OOo0OOoO00o0 ( url ) :
 IIi1IiII = 'http://totalxbmc.com/totalrevolution/HardwarePortal/sortby.php?sortx=Added&orderx=DESC&%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( IIi1IiII ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIII1iII = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> thumb="(.+?)" <br><br>' , re . DOTALL ) . findall ( IIiIi1iI )
 o0IIIIiI11I ( IIi1IiII , 'hardware' )
 for I1II1 , id , Ii11I1iIiiI in IIII1iII :
  Ii ( 'folder2' , I1II1 , id , 'hardware_final_menu' , Ii11I1iIiiI , '' , '' )
  if 87 - 87: i1OOO . IIIIII11i1I % O0oO + iii11I111 + Oo000o % o0o0OOO0o0
  if 19 - 19: i11iIiiIii - OoO0O00 % oO0o0ooo
def ooIII1II1iii1i ( url ) :
 IIi1IiII = 'http://totalxbmc.com/totalrevolution/LatestNews/sortby.php?sortx=item_date&orderx=DESC&%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( IIi1IiII ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIII1iII = re . compile ( 'name="(.+?)" <br> date="(.+?)" <br> source="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( IIiIi1iI )
 for I1II1 , O0OO0oOO , ooooO , id in IIII1iII :
  if "OpenELEC" in ooooO :
   Ii ( '' , I1II1 + '  (' + O0OO0oOO + ')' , id , 'news_menu' , 'OpenELEC.png' , '' , '' )
  if "Official" in ooooO :
   Ii ( '' , I1II1 + '  (' + O0OO0oOO + ')' , id , 'news_menu' , 'XBMC.png' , '' , '' )
  if "Raspbmc" in ooooO :
   Ii ( '' , I1II1 + '  (' + O0OO0oOO + ')' , id , 'news_menu' , 'Raspbmc.png' , '' , '' )
  if "XBMC4Xbox" in ooooO :
   Ii ( '' , I1II1 + '  (' + O0OO0oOO + ')' , id , 'news_menu' , 'XBMC4Xbox.png' , '' , '' )
  if "TotalXBMC" in ooooO :
   Ii ( '' , I1II1 + '  (' + O0OO0oOO + ')' , id , 'news_menu' , 'TOTALXBMC.png' , '' , '' )
   if 92 - 92: OoOo / OoOo * Oo000o
   if 19 - 19: Oo000o
def O0o00oO0oOO ( url ) :
 IIi1IiII = 'http://totalxbmc.com/totalrevolution/TutorialPortal/sortby.php?sortx=Name&orderx=ASC&%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( IIi1IiII ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIII1iII = re . compile ( 'name="(.+?)" <br> about="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( IIiIi1iI )
 o0IIIIiI11I ( IIi1IiII , 'tutorials' )
 for I1II1 , iiiii1I1III1 , id in IIII1iII :
  Ii ( 'folder' , I1II1 , id , 'tutorial_final_menu' , 'TotalXBMC_Guides.png' , '' , iiiii1I1III1 )
  if 12 - 12: OoO0O00 . II11iII * oO0o0ooo
  if 37 - 37: iii11I111 * oO0o0ooo % i11iIiiIii % o0O0 % ooOO0o
def iiiO0 ( url , local ) :
 oo00o ( )
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( I1II1 , 'This will over-write your existing guisettings.xml.' , 'Are you sure this is the build you have installed?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if II1Ii1iI1i1 == 0 :
  return
 elif II1Ii1iI1i1 == 1 :
  o0 ( url , local )
  if 76 - 76: o0o0OOO0o0
  if 80 - 80: o0o0OOO0o0 . IIIIII11i1I / Oo000o % Oo000o
def o0 ( url , local ) :
 ooOo000OoO0o = 0
 ooooo0O0 = 1
 if os . path . exists ( O0OoO000O0OO ) :
  os . remove ( O0OoO000O0OO )
 if os . path . exists ( o0oOoO00o ) :
  os . remove ( o0oOoO00o )
 if os . path . exists ( I11 ) :
  os . remove ( I11 )
 if not os . path . exists ( iiI1IiI ) :
  os . makedirs ( iiI1IiI )
 IiI . create ( "Community Builds" , "Downloading guisettings.xml" , '' , 'Please Wait' )
 shutil . copyfile ( Oo0oO0ooo , O0OoO000O0OO )
 if local != 1 :
  i1III1iI = os . path . join ( oO0o0o0ooO0oO , 'guifix.zip' )
  downloader . download ( url , i1III1iI , IiI )
 else :
  i1III1iI = xbmc . translatePath ( url )
 ii1i ( i1III1iI )
 IiI . create ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "Checking " , '' , 'Please Wait' )
 IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
 extract . all ( i1III1iI , iiI1IiI , IiI )
 try :
  i1IiiiiIi1I = open ( iiI1IiI + 'profiles.xml' , mode = 'r' )
  ooo0O0o0OoOO = i1IiiiiIi1I . read ( )
  i1IiiiiIi1I . close ( )
  if os . path . exists ( iiI1IiI + 'profiles.xml' ) :
   II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( "PROFILES DETECTED" , 'This build has profiles included, would you like to overwrite' , 'your existing profiles or keep the ones you have?' , '' , nolabel = 'Keep my profiles' , yeslabel = 'Use new profiles' )
   if II1Ii1iI1i1 == 0 :
    pass
   elif II1Ii1iI1i1 == 1 :
    iIi11i = open ( I11 , mode = 'w' )
    time . sleep ( 1 )
    iIi11i . write ( ooo0O0o0OoOO )
    time . sleep ( 1 )
    iIi11i . close ( )
    ooooo0O0 = 0
 except : print "no profiles.xml file"
 os . rename ( iiI1IiI + 'guisettings.xml' , o0oOoO00o )
 if 98 - 98: i1OOO - OoO0O00 . oOOoO0O0O0
 time . sleep ( 1 )
 OooOOOo0 = open ( O0OoO000O0OO , mode = 'r' )
 O0O0o0o0o = file . read ( OooOOOo0 )
 file . close ( OooOOOo0 )
 Ii1IIIII = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( O0O0o0o0o )
 iiiIIiiii11 = Ii1IIIII [ 0 ] if ( len ( Ii1IIIII ) > 0 ) else ''
 IIiI1iIIiI1I1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( O0O0o0o0o )
 IiIIiI = IIiI1iIIiI1I1i [ 0 ] if ( len ( IIiI1iIIiI1I1i ) > 0 ) else ''
 oOo0Oo0O0O = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( O0O0o0o0o )
 III1II1i = oOo0Oo0O0O [ 0 ] if ( len ( oOo0Oo0O0O ) > 0 ) else ''
 iI1i1IiIIIIi = open ( o0oOoO00o , mode = 'r' )
 OooOooO0O0o0 = file . read ( iI1i1IiIIIIi )
 file . close ( iI1i1IiIIIIi )
 OOO0o0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( OooOooO0O0o0 )
 IIIIII111Ii = OOO0o0 [ 0 ] if ( len ( OOO0o0 ) > 0 ) else ''
 Ii1i1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( OooOooO0O0o0 )
 iIi1Ii1IIiI = Ii1i1i [ 0 ] if ( len ( Ii1i1i ) > 0 ) else ''
 ooo00Oo00O0 = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( OooOooO0O0o0 )
 OOOOOOoo0oO = ooo00Oo00O0 [ 0 ] if ( len ( ooo00Oo00O0 ) > 0 ) else ''
 IiIiIIiii1I = O0O0o0o0o . replace ( iiiIIiiii11 , IIIIII111Ii ) . replace ( III1II1i , OOOOOOoo0oO ) . replace ( IiIIiI , iIi1Ii1IIiI )
 iIi11i = open ( O0OoO000O0OO , mode = 'w+' )
 iIi11i . write ( str ( IiIiIIiii1I ) )
 iIi11i . close ( )
 if os . path . exists ( Oo0oO0ooo ) :
  try :
   os . remove ( Oo0oO0ooo )
   ooooo0Oo0 = True
  except :
   Oo0O . ok ( "Oops we have a problem" , 'There was an error trying to complete this process.' , 'Please try this step again, if it still fails you may' , 'need to restart Kodi and try again.' )
   ooooo0Oo0 = False
 try :
  os . rename ( O0OoO000O0OO , Oo0oO0ooo )
  os . remove ( o0oOoO00o )
 except :
  pass
 if ooooo0Oo0 == True :
  try :
   OooOOOo0 = open ( oooOOOOO , mode = 'r' )
   O0O0o0o0o = file . read ( OooOOOo0 )
   file . close ( OooOOOo0 )
   o0I1IIIi11ii11 = re . compile ( 'id="(.+?)"' ) . findall ( O0O0o0o0o )
   O0o0oo0oOO0oO = o0I1IIIi11ii11 [ 0 ] if ( len ( o0I1IIIi11ii11 ) > 0 ) else ''
   iIiIII1iI1111 = re . compile ( 'name="(.+?)"' ) . findall ( O0O0o0o0o )
   Ii1I1I111iI = iIiIII1iI1111 [ 0 ] if ( len ( iIiIII1iI1111 ) > 0 ) else ''
   I1i11I = re . compile ( 'version="(.+?)"' ) . findall ( O0O0o0o0o )
   oooOOOO0oooo = I1i11I [ 0 ] if ( len ( I1i11I ) > 0 ) else ''
   iIi11i = open ( i1iiIII111ii , mode = 'w+' )
   iIi11i . write ( 'id="' + str ( O0o0oo0oOO0oO ) + '"\nname="' + Ii1I1I111iI + '"\nversion="' + oooOOOO0oooo + '"' )
   iIi11i . close ( )
   OooOOOo0 = open ( i1iiIIiiI111 , mode = 'r' )
   O0O0o0o0o = file . read ( OooOOOo0 )
   file . close ( OooOOOo0 )
   ooo0oo00O00Oo = re . compile ( 'version="(.+?)"' ) . findall ( O0O0o0o0o )
   OOO000000OOO0 = ooo0oo00O00Oo [ 0 ] if ( len ( ooo0oo00O00Oo ) > 0 ) else ''
   IiIiIIiii1I = O0O0o0o0o . replace ( OOO000000OOO0 , oooOOOO0oooo )
   iIi11i = open ( i1iiIIiiI111 , mode = 'w' )
   iIi11i . write ( str ( IiIiIIiii1I ) )
   iIi11i . close ( )
   os . remove ( oooOOOOO )
  except :
   iIi11i = open ( i1iiIII111ii , mode = 'w+' )
   iIi11i . write ( 'id="None"\nname="Unknown"\nversion="Unknown"' )
   iIi11i . close ( )
 if os . path . exists ( iiI1IiI + 'profiles.xml' ) :
  os . remove ( iiI1IiI + 'profiles.xml' )
 if ooooo0O0 == 0 :
  Oo0O . ok ( "PROFILES DETECTED" , 'Unfortunately the only way to get the new profiles to stick is' , 'to force close kodi. Either do this via the task manager,' , 'terminal or system settings. DO NOT use the quit/exit options in Kodi.' )
  ooOoOOoooO000 ( )
 else :
  if ooooo0Oo0 == True :
   Oo0O . ok ( "guisettings.xml fix complete" , 'Please restart Kodi. If the skin doesn\'t look' , 'quite right on the next boot you may need to' , 'force close Kodi.' )
 if os . path . exists ( iiI1IiI ) :
  os . removedirs ( iiI1IiI )
 OoO0o000oOo = xbmc . translatePath ( os . path . join ( iI1Ii11111iIi , 'plugin.program.TBS' , 'notification.txt' ) )
 if os . path . exists ( OoO0o000oOo ) :
  os . remove ( OoO0o000oOo )
  if 88 - 88: o0O0 * O0oO * Ooo0Oo0 - i1OOO * oOOoO0O0O0 / IIII
  if 41 - 41: IIIIII11i1I / O0oO + o0o0OOO0o0
def oO0o0o00oOo0O ( url ) :
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/HardwarePortal/hardwaredetails.php?id=%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iIi = re . compile ( 'name="(.+?)"' ) . findall ( IIiIi1iI )
 oOOoooO0O0 = re . compile ( 'manufacturer="(.+?)"' ) . findall ( IIiIi1iI )
 o0Ooo0O00 = re . compile ( 'video_guide1="(.+?)"' ) . findall ( IIiIi1iI )
 ii1o0oooO = re . compile ( 'video_guide2="(.+?)"' ) . findall ( IIiIi1iI )
 ooOoo0oO0OoO0 = re . compile ( 'video_guide3="(.+?)"' ) . findall ( IIiIi1iI )
 oOOOOOoOO = re . compile ( 'video_guide4="(.+?)"' ) . findall ( IIiIi1iI )
 oooo00 = re . compile ( 'video_guide5="(.+?)"' ) . findall ( IIiIi1iI )
 i1oO = re . compile ( 'video_label1="(.+?)"' ) . findall ( IIiIi1iI )
 iIIi1IIi = re . compile ( 'video_label2="(.+?)"' ) . findall ( IIiIi1iI )
 i111i11I1ii = re . compile ( 'video_label3="(.+?)"' ) . findall ( IIiIi1iI )
 OOooo = re . compile ( 'video_label4="(.+?)"' ) . findall ( IIiIi1iI )
 oo0 = re . compile ( 'video_label5="(.+?)"' ) . findall ( IIiIi1iI )
 ii1O0ooooo000 = re . compile ( 'shops="(.+?)"' ) . findall ( IIiIi1iI )
 oo0O0oO0O0O = re . compile ( 'description="(.+?)"' ) . findall ( IIiIi1iI )
 OooOoOO0OO = re . compile ( 'screenshot1="(.+?)"' ) . findall ( IIiIi1iI )
 I1iiIiiii1111 = re . compile ( 'screenshot2="(.+?)"' ) . findall ( IIiIi1iI )
 I1ii1i11i = re . compile ( 'screenshot3="(.+?)"' ) . findall ( IIiIi1iI )
 Oooooo0O00o = re . compile ( 'screenshot4="(.+?)"' ) . findall ( IIiIi1iI )
 II11ii1 = re . compile ( 'screenshot5="(.+?)"' ) . findall ( IIiIi1iI )
 ii1II1II = re . compile ( 'screenshot6="(.+?)"' ) . findall ( IIiIi1iI )
 i11i11II11i = re . compile ( 'screenshot7="(.+?)"' ) . findall ( IIiIi1iI )
 II1Ii1I1i = re . compile ( 'screenshot8="(.+?)"' ) . findall ( IIiIi1iI )
 OOooOooo0OOo0 = re . compile ( 'screenshot9="(.+?)"' ) . findall ( IIiIi1iI )
 oo0o0OoOO0o0 = re . compile ( 'screenshot10="(.+?)"' ) . findall ( IIiIi1iI )
 III1III11II = re . compile ( 'screenshot11="(.+?)"' ) . findall ( IIiIi1iI )
 iIi1iI = re . compile ( 'screenshot12="(.+?)"' ) . findall ( IIiIi1iI )
 OO0Oo = re . compile ( 'screenshot13="(.+?)"' ) . findall ( IIiIi1iI )
 IIiiiiiIiIIi = re . compile ( 'screenshot14="(.+?)"' ) . findall ( IIiIi1iI )
 iiIiiIi1 = re . compile ( 'added="(.+?)"' ) . findall ( IIiIi1iI )
 i1I1ii11i1Iii = re . compile ( 'platform="(.+?)"' ) . findall ( IIiIi1iI )
 I1Ii11i = re . compile ( 'chipset="(.+?)"' ) . findall ( IIiIi1iI )
 I1iIiiiI1 = re . compile ( 'official_guide="(.+?)"' ) . findall ( IIiIi1iI )
 OOO0O00Oo = re . compile ( 'official_preview="(.+?)"' ) . findall ( IIiIi1iI )
 ii1oOOO0ooOO = re . compile ( 'thumbnail="(.+?)"' ) . findall ( IIiIi1iI )
 i11IiI1iiI11 = re . compile ( 'stock_rom="(.+?)"' ) . findall ( IIiIi1iI )
 OOoOOOO00 = re . compile ( 'CPU="(.+?)"' ) . findall ( IIiIi1iI )
 IIii1III = re . compile ( 'GPU="(.+?)"' ) . findall ( IIiIi1iI )
 ooooOoo0OO = re . compile ( 'RAM="(.+?)"' ) . findall ( IIiIi1iI )
 Oo0 = re . compile ( 'flash="(.+?)"' ) . findall ( IIiIi1iI )
 O0000Oo00o = re . compile ( 'wifi="(.+?)"' ) . findall ( IIiIi1iI )
 II1ii = re . compile ( 'bluetooth="(.+?)"' ) . findall ( IIiIi1iI )
 o00iIiiiII = re . compile ( 'LAN="(.+?)"' ) . findall ( IIiIi1iI )
 Ii1I1 = re . compile ( 'xbmc_version="(.+?)"' ) . findall ( IIiIi1iI )
 OO0ooO0 = re . compile ( 'pros="(.+?)"' ) . findall ( IIiIi1iI )
 OoOooOO0oOOo0O = re . compile ( 'cons="(.+?)"' ) . findall ( IIiIi1iI )
 I1II = re . compile ( 'library_scan="(.+?)"' ) . findall ( IIiIi1iI )
 iIIi1Ii1III = re . compile ( '4k="(.+?)"' ) . findall ( IIiIi1iI )
 Oooo00 = re . compile ( '1080="(.+?)"' ) . findall ( IIiIi1iI )
 iii1II1iI1IIi = re . compile ( '720="(.+?)"' ) . findall ( IIiIi1iI )
 Ii11iiI1 = re . compile ( '3D="(.+?)"' ) . findall ( IIiIi1iI )
 oO0OOOoooO00o0o = re . compile ( 'DTS="(.+?)"' ) . findall ( IIiIi1iI )
 I1ii1Ii1 = re . compile ( 'total_review="(.+?)"' ) . findall ( IIiIi1iI )
 OoOoOiI111I1III = re . compile ( 'CB_Premium="(.+?)"' ) . findall ( IIiIi1iI )
 if 36 - 36: oOOoO0O0O0 % OOO00OoOO00
 I1II1 = i1iIi [ 0 ] if ( len ( i1iIi ) > 0 ) else ''
 OoO0 = oOOoooO0O0 [ 0 ] if ( len ( oOOoooO0O0 ) > 0 ) else ''
 oOoO00o = o0Ooo0O00 [ 0 ] if ( len ( o0Ooo0O00 ) > 0 ) else 'None'
 oO00O0 = ii1o0oooO [ 0 ] if ( len ( ii1o0oooO ) > 0 ) else 'None'
 IIi1IIIi = ooOoo0oO0OoO0 [ 0 ] if ( len ( ooOoo0oO0OoO0 ) > 0 ) else 'None'
 O00Ooo = oOOOOOoOO [ 0 ] if ( len ( oOOOOOoOO ) > 0 ) else 'None'
 OOOO0OOO = oooo00 [ 0 ] if ( len ( oooo00 ) > 0 ) else 'None'
 ii1IIII = i1oO [ 0 ] if ( len ( i1oO ) > 0 ) else 'None'
 oO00oOooooo0 = iIIi1IIi [ 0 ] if ( len ( iIIi1IIi ) > 0 ) else 'None'
 oOo = i111i11I1ii [ 0 ] if ( len ( i111i11I1ii ) > 0 ) else 'None'
 O0OOooOoO = OOooo [ 0 ] if ( len ( OOooo ) > 0 ) else 'None'
 i1II1I1Iii1 = oo0 [ 0 ] if ( len ( oo0 ) > 0 ) else 'None'
 i1ii1IIIII = ii1O0ooooo000 [ 0 ] if ( len ( ii1O0ooooo000 ) > 0 ) else ''
 IIII1 = oo0O0oO0O0O [ 0 ] if ( len ( oo0O0oO0O0O ) > 0 ) else ''
 oOOO0 = OooOoOO0OO [ 0 ] if ( len ( OooOoOO0OO ) > 0 ) else ''
 Iii1i11iiI1 = I1iiIiiii1111 [ 0 ] if ( len ( I1iiIiiii1111 ) > 0 ) else ''
 oOOoOooO0oO0o = I1ii1i11i [ 0 ] if ( len ( I1ii1i11i ) > 0 ) else ''
 o0o0OoO0OOO0 = Oooooo0O00o [ 0 ] if ( len ( Oooooo0O00o ) > 0 ) else ''
 oO0OOOO0o0 = II11ii1 [ 0 ] if ( len ( II11ii1 ) > 0 ) else ''
 oOO0 = ii1II1II [ 0 ] if ( len ( ii1II1II ) > 0 ) else ''
 O00O00OoO = i11i11II11i [ 0 ] if ( len ( i11i11II11i ) > 0 ) else ''
 IiIiI1i1 = II1Ii1I1i [ 0 ] if ( len ( II1Ii1I1i ) > 0 ) else ''
 ii11I1IIi1i = OOooOooo0OOo0 [ 0 ] if ( len ( OOooOooo0OOo0 ) > 0 ) else ''
 iiiiiiiiiiIi = oo0o0OoOO0o0 [ 0 ] if ( len ( oo0o0OoOO0o0 ) > 0 ) else ''
 ooiiI1ii = III1III11II [ 0 ] if ( len ( III1III11II ) > 0 ) else ''
 O0OooOO = iIi1iI [ 0 ] if ( len ( iIi1iI ) > 0 ) else ''
 i1i1 = OO0Oo [ 0 ] if ( len ( OO0Oo ) > 0 ) else ''
 o0oOoOo0 = IIiiiiiIiIIi [ 0 ] if ( len ( IIiiiiiIiIIi ) > 0 ) else ''
 III1IiI1i1i = iiIiiIi1 [ 0 ] if ( len ( iiIiiIi1 ) > 0 ) else ''
 IiIi1I1 = i1I1ii11i1Iii [ 0 ] if ( len ( i1I1ii11i1Iii ) > 0 ) else ''
 o0OOOOOo0 = I1Ii11i [ 0 ] if ( len ( I1Ii11i ) > 0 ) else ''
 oooOoO = I1iIiiiI1 [ 0 ] if ( len ( I1iIiiiI1 ) > 0 ) else ''
 O0Oo0 = OOO0O00Oo [ 0 ] if ( len ( OOO0O00Oo ) > 0 ) else ''
 Ii11I1iIiiI = ii1oOOO0ooOO [ 0 ] if ( len ( ii1oOOO0ooOO ) > 0 ) else ''
 iIIIi1IiI11I1 = i11IiI1iiI11 [ 0 ] if ( len ( i11IiI1iiI11 ) > 0 ) else ''
 O0Ooo000 = OOoOOOO00 [ 0 ] if ( len ( OOoOOOO00 ) > 0 ) else ''
 IIi11iI1Iii = IIii1III [ 0 ] if ( len ( IIii1III ) > 0 ) else ''
 IiIi1ii11ii = ooooOoo0OO [ 0 ] if ( len ( ooooOoo0OO ) > 0 ) else ''
 oOOOOO0Ooooo = Oo0 [ 0 ] if ( len ( Oo0 ) > 0 ) else ''
 o0o000Oo = O0000Oo00o [ 0 ] if ( len ( O0000Oo00o ) > 0 ) else ''
 oO0o0O0o0OO00 = II1ii [ 0 ] if ( len ( II1ii ) > 0 ) else ''
 iIiiiIi = o00iIiiiII [ 0 ] if ( len ( o00iIiiiII ) > 0 ) else ''
 oo0oO = Ii1I1 [ 0 ] if ( len ( Ii1I1 ) > 0 ) else ''
 OooooOo = OO0ooO0 [ 0 ] if ( len ( OO0ooO0 ) > 0 ) else ''
 IIIiiiIiI = OoOooOO0oOOo0O [ 0 ] if ( len ( OoOooOO0oOOo0O ) > 0 ) else ''
 OO0OOoooo0o = I1II [ 0 ] if ( len ( I1II ) > 0 ) else ''
 IiIi1Ii = iIIi1Ii1III [ 0 ] if ( len ( iIIi1Ii1III ) > 0 ) else ''
 iiIIiI11II1 = Oooo00 [ 0 ] if ( len ( Oooo00 ) > 0 ) else ''
 oooOo = iii1II1iI1IIi [ 0 ] if ( len ( iii1II1iI1IIi ) > 0 ) else ''
 oOoO0Oo0 = Ii11iiI1 [ 0 ] if ( len ( Ii11iiI1 ) > 0 ) else ''
 i11i11i = oO0OOOoooO00o0o [ 0 ] if ( len ( oO0OOOoooO00o0o ) > 0 ) else ''
 iiI1iI = I1ii1Ii1 [ 0 ] if ( len ( I1ii1Ii1 ) > 0 ) else ''
 Ooo00O0 = OoOoOiI111I1III [ 0 ] if ( len ( OoOoOiI111I1III ) > 0 ) else ''
 OoO0OOoO0 = str ( '[COLOR=gold]Available From: [/COLOR]' + i1ii1IIIII + ' @ [COLOR=lime]www.totalboxshop.tv[/COLOR][CR][CR][COLOR=dodgerblue]Added: [/COLOR]' + III1IiI1i1i + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + OoO0 + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + IiIi1I1 + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + o0OOOOOo0 + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + O0Ooo000 + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + IIi11iI1Iii + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + IiIi1ii11ii + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + oOOOOO0Ooooo + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + o0o000Oo + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + oO0o0O0o0OO00 + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + iIiiiIi + '[CR][CR][COLOR=yellow]About: [/COLOR]' + IIII1 )
 iiI11i = str ( '[COLOR=gold]Availability: [/COLOR]Sorry this device is currently unavailable at [COLOR=lime]www.totalboxshop.tv[/COLOR][CR][CR][COLOR=dodgerblue]Added: [/COLOR]' + III1IiI1i1i + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + OoO0 + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + IiIi1I1 + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + o0OOOOOo0 + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + O0Ooo000 + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + IIi11iI1Iii + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + IiIi1ii11ii + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + oOOOOO0Ooooo + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + o0o000Oo + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + oO0o0O0o0OO00 + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + iIiiiIi + '[CR][CR][COLOR=yellow]About: [/COLOR]' + IIII1 )
 o0Oo = str ( '[COLOR=gold]Available From: [/COLOR]' + i1ii1IIIII + ' @ [COLOR=lime]www.totalboxshop.tv[/COLOR][CR][CR][COLOR=dodgerblue]Added: [/COLOR]' + III1IiI1i1i + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + OoO0 + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + IiIi1I1 + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + o0OOOOOo0 + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + O0Ooo000 + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + IIi11iI1Iii + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + IiIi1ii11ii + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + oOOOOO0Ooooo + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + o0o000Oo + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + oO0o0O0o0OO00 + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + iIiiiIi + '[CR][CR][COLOR=yellow]About: [/COLOR]' + iiI1iI + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + OooooOo + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + IIIiiiIiI + '[CR][CR][COLOR=gold]4k Playback:[/COLOR]  ' + IiIi1Ii + '[CR][CR][COLOR=gold]1080p Playback:[/COLOR]  ' + iiIIiI11II1 + '[CR][CR][COLOR=gold]720p Playback:[/COLOR]  ' + oooOo + '[CR][CR][COLOR=gold]DTS Compatibility:[/COLOR]  ' + i11i11i + '[CR][CR][COLOR=gold]Time taken to scan 100 movies:[/COLOR]  ' + OO0OOoooo0o )
 iiI1i = str ( '[COLOR=gold]Availability: [/COLOR]Sorry this device is currently unavailable at [COLOR=lime]www.totalboxshop.tv[/COLOR][CR][CR][COLOR=dodgerblue]Added: [/COLOR]' + III1IiI1i1i + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + OoO0 + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + IiIi1I1 + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + o0OOOOOo0 + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + O0Ooo000 + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + IIi11iI1Iii + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + IiIi1ii11ii + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + oOOOOO0Ooooo + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + o0o000Oo + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + oO0o0O0o0OO00 + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + iIiiiIi + '[CR][CR][COLOR=yellow]About: [/COLOR]' + iiI1iI + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + OooooOo + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + IIIiiiIiI + '[CR][CR][COLOR=gold]4k Playback:[/COLOR]  ' + IiIi1Ii + '[CR][CR][COLOR=gold]1080p Playback:[/COLOR]  ' + iiIIiI11II1 + '[CR][CR][COLOR=gold]720p Playback:[/COLOR]  ' + oooOo + '[CR][CR][COLOR=gold]DTS Compatibility:[/COLOR]  ' + i11i11i + '[CR][CR][COLOR=gold]Time taken to scan 100 movies:[/COLOR]  ' + OO0OOoooo0o )
 if IIII1 != '' and i1ii1IIIII != '' :
  Ii ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , OoO0OOoO0 , 'text_guide' , 'TotalXBMC_Guides.png' , oo00 , '' , '' )
 if IIII1 != '' and i1ii1IIIII == '' :
  Ii ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , iiI11i , 'text_guide' , 'TotalXBMC_Guides.png' , oo00 , '' , '' )
 if iiI1iI != '' and i1ii1IIIII != '' :
  Ii ( '' , '[COLOR=yellow][Text Guide][/COLOR]  TotalXBMC Review' , o0Oo , 'text_guide' , 'TotalXBMC_Guides.png' , oo00 , '' , '' )
 if iiI1iI != '' and i1ii1IIIII == '' :
  Ii ( '' , '[COLOR=yellow][Text Guide][/COLOR]  TotalXBMC Review' , iiI1i , 'text_guide' , 'TotalXBMC_Guides.png' , oo00 , '' , '' )
 if O0Oo0 != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Preview' , O0Oo0 , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if oooOoO != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Guide' , oooOoO , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if oOoO00o != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + ii1IIII , oOoO00o , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if oO00O0 != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oO00oOooooo0 , oO00O0 , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if IIi1IIIi != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oOo , IIi1IIIi , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if O00Ooo != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + O0OOooOoO , O00Ooo , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if OOOO0OOO != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i1II1I1Iii1 , OOOO0OOO , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
  if 3 - 3: ooOO0o / oOOoO0O0O0
  if 34 - 34: i11iIiiIii / O0oO * OOO00OoOO00 . iiIi
def ooo0O00000oo0 ( ) :
 Ii ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'hardware' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime]All Devices[/COLOR]' , '' , 'grab_hardware' , 'All.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Game Consoles' , 'device=Console' , 'grab_hardware' , 'Consoles.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Hardware][/COLOR] HTPC' , 'device=HTPC' , 'grab_hardware' , 'HTPC.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Phones' , 'device=Phone' , 'grab_hardware' , 'Phones.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Set Top Boxes' , 'device=STB' , 'grab_hardware' , 'STB.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Tablets' , 'device=Tablet' , 'grab_hardware' , 'Tablets.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Remotes/Keyboards' , 'device=Remote' , 'grab_hardware' , 'Remotes.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Gaming Controllers' , 'device=Controller' , 'grab_hardware' , 'Controllers.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Dongles' , 'device=Dongle' , 'grab_hardware' , 'Dongles.png' , '' , '' , '' )
 if 80 - 80: iiIi + iii11I111
 if 98 - 98: Ooo0Oo0 . IIII
def Oo000OoOO ( url ) :
 Ii ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Allwinner Devices' , str ( url ) + '&chip=Allwinner' , 'grab_hardware' , 'Allwinner.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=yellow][CPU][/COLOR] AMLogic Devices' , str ( url ) + '&chip=AMLogic' , 'grab_hardware' , 'AMLogic.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Intel Devices' , str ( url ) + '&chip=Intel' , 'grab_hardware' , 'Intel.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Rockchip Devices' , str ( url ) + '&chip=Rockchip' , 'grab_hardware' , 'Rockchip.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Platform][/COLOR] Android' , str ( url ) + '&platform=Android' , 'grab_hardware' , 'Android.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Platform][/COLOR] iOS' , str ( url ) + '&platform=iOS' , 'grab_hardware' , 'iOS.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Platform][/COLOR] Linux' , str ( url ) + '&platform=Linux' , 'grab_hardware' , 'Linux.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Platform][/COLOR] OpenELEC' , str ( url ) + '&platform=OpenELEC' , 'grab_hardware' , 'OpenELEC.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Platform][/COLOR] OSX' , str ( url ) + '&platform=OSX' , 'grab_hardware' , 'OSX.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Platform][/COLOR] Pure Linux' , str ( url ) + '&platform=Custom_Linux' , 'grab_hardware' , 'Custom_Linux.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][Platform][/COLOR] Windows' , str ( url ) + '&platform=Windows' , 'grab_hardware' , 'Windows.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 4GB' , str ( url ) + '&flash=4GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 8GB' , str ( url ) + '&flash=8GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 16GB' , str ( url ) + '&flash=16GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 32GB' , str ( url ) + '&flash=32GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 64GB' , str ( url ) + '&flash=64GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 1GB' , str ( url ) + '&ram=1GB' , 'grab_hardware' , 'RAM.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 2GB' , str ( url ) + '&ram=2GB' , 'grab_hardware' , 'RAM.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 4GB' , str ( url ) + '&ram=4GB' , 'grab_hardware' , 'RAM.png' , '' , '' , '' )
 if 7 - 7: Ooo0Oo0 % II11iII - oO0o0ooo + iiIi
 if 70 - 70: ii1I11II1ii1i + O0oO + i11iIiiIii - o0O0 / ooOO0o
 if 40 - 40: iii11I111 * O0oO
def IiIIIIII1i ( ) :
 iI111I11I1I1 = xbmc . getSkinDir ( )
 oo0000Oo00o = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , iI111I11I1I1 ) )
 for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( oo0000Oo00o ) :
  for oOOOO in O0Oo0o000oO :
   if 'DialogKeyboard.xml' in oOOOO :
    iI111I11I1I1 = os . path . join ( IiI1ii1Ii , oOOOO )
    i11I1II = open ( iI111I11I1I1 ) . read ( )
    OO0OOO0oOOo00O = i11I1II . replace ( '<control type="label" id="310"' , '<control type="edit" id="312"' )
    oOOOO = open ( iI111I11I1I1 , mode = 'w' )
    oOOOO . write ( OO0OOO0oOOo00O )
    oOOOO . close ( )
    i1I1i1i1iII1 ( iI111I11I1I1 )
    for iI1ii1ii1I in range ( 48 , 58 ) :
     o0OoO00o0000O ( iI1ii1ii1I , iI111I11I1I1 )
 Oo0O = xbmcgui . Dialog ( )
 Oo0O . ok ( "Skin Changes Successful" , 'A BIG thank you to Mikey1234 for this fix. The' , 'code used for this function was ported from the' , 'Xunity Maintenance add-on' )
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 39 - 39: Ooo0Oo0 / iiIi
def II11iiii ( ) :
 Oo0O = xbmcgui . Dialog ( )
 oO0O0oO = xbmcgui . Dialog ( ) . yesno ( 'Convert This Skin To Kodi (Helix)?' , 'This will fix the problem with a blank on-screen keyboard' , 'showing in skins designed for Gotham (being run on Kodi).' , 'This will only affect the currently running skin.' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if oO0O0oO == 0 :
  return
 elif oO0O0oO == 1 :
  IiIIIIII1i ( )
  if 20 - 20: OoO0O00 / OOO00OoOO00
  if 28 - 28: i1OOO * oOOoO0O0O0 % i11iIiiIii * OoO0O00 / Oo000o
def iIII1iIi ( ) :
 if Oo0O . yesno ( "Hide Passwords" , "This will hide all your passwords in your" , "add-on settings, are you sure you wish to continue?" ) :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( iiIIIII1i1iI ) :
   for oOOOO in O0Oo0o000oO :
    if oOOOO == 'settings.xml' :
     o000O0oo = open ( os . path . join ( IiI1ii1Ii , oOOOO ) ) . read ( )
     IIII1iII = re . compile ( '<setting id=(.+?)>' ) . findall ( o000O0oo )
     for OOOO in IIII1iII :
      if 'pass' in OOOO :
       if not 'option="hidden"' in OOOO :
        try :
         oo00OO0O0Ooo0 = OOOO . replace ( '/' , ' option="hidden"/' )
         oOOOO = open ( os . path . join ( IiI1ii1Ii , oOOOO ) , mode = 'w' )
         oOOOO . write ( str ( o000O0oo ) . replace ( OOOO , oo00OO0O0Ooo0 ) )
         oOOOO . close ( )
        except :
         pass
  Oo0O . ok ( "Passwords Hidden" , "Your passwords will now show as stars (hidden), if you" , "want to undo this please use the option to unhide passwords." )
  if 93 - 93: i1OOO
  if 34 - 34: Ooo0Oo0 - i1OOO * iiIi / OoOo
def iI1iiIi1 ( url ) :
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/Community_Builds/guisettings.php?id=%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 OO0oOOo0o = re . compile ( 'guisettings="(.+?)"' ) . findall ( IIiIi1iI )
 iIIiI1ii = OO0oOOo0o [ 0 ] if ( len ( OO0oOOo0o ) > 0 ) else 'None'
 o0 ( iIIiI1ii , i1iiiIi1Iii )
 if 54 - 54: i1OOO . o0o0OOO0o0 * o0O0
 if 44 - 44: Ooo0Oo0 + iii11I111 * OOO00OoOO00 - i11iIiiIii / o0o0OOO0o0
def iI11II1i1I1 ( path ) :
 o0oo00O0o = xbmc . translatePath ( os . path . join ( Oo , 'background_art' , '' ) )
 if os . path . exists ( o0oo00O0o ) :
  iiIIi ( o0oo00O0o )
  time . sleep ( 1 )
 if not os . path . exists ( o0oo00O0o ) :
  os . makedirs ( o0oo00O0o )
 try :
  IiI . create ( "Installing Artwork" , "Downloading artwork pack" , '' , 'Please Wait' )
  oO0ooOO = os . path . join ( oO0o0o0ooO0oO , I1IiiI + '_artpack.zip' )
  downloader . download ( path , oO0ooOO , IiI )
  time . sleep ( 1 )
  if 57 - 57: o0O0 * ii1I11II1ii1i * Ooo0Oo0
  IiI . create ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "Checking " , '' , 'Please Wait' )
  IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( oO0ooOO , o0oo00O0o , IiI )
 except : pass
 if 30 - 30: oOOoO0O0O0 % II11iII / iii11I111 * IIIIII11i1I * Oo000o . oO0o0ooo
 if 46 - 46: II11iII - IIIIII11i1I
def ii11I1 ( repo_id ) :
 o00oo0 = 1
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/AddonPortal/dependencyinstall.php?id=%s' % ( repo_id )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iIi = re . compile ( 'name="(.+?)"' ) . findall ( IIiIi1iI )
 i1II1Iiii1I11 = re . compile ( 'version="(.+?)"' ) . findall ( IIiIi1iI )
 i1Ii = re . compile ( 'repo_url="(.+?)"' ) . findall ( IIiIi1iI )
 ii111iI1iIi1 = re . compile ( 'data_url="(.+?)"' ) . findall ( IIiIi1iI )
 OOO = re . compile ( 'zip_url="(.+?)"' ) . findall ( IIiIi1iI )
 O0ooO0Oo00o = re . compile ( 'repo_id="(.+?)"' ) . findall ( IIiIi1iI )
 O00OoooOoOo0o00o = i1iIi [ 0 ] if ( len ( i1iIi ) > 0 ) else ''
 i1i1iI1iiiI = i1II1Iiii1I11 [ 0 ] if ( len ( i1II1Iiii1I11 ) > 0 ) else ''
 II1Ii = i1Ii [ 0 ] if ( len ( i1Ii ) > 0 ) else ''
 OOoO00ooO = ii111iI1iIi1 [ 0 ] if ( len ( ii111iI1iIi1 ) > 0 ) else ''
 I1IIIIiii1i = OOO [ 0 ] if ( len ( OOO ) > 0 ) else ''
 o0IiiiI111I = O0ooO0Oo00o [ 0 ] if ( len ( O0ooO0Oo00o ) > 0 ) else ''
 iIIi1 = xbmc . translatePath ( os . path . join ( OooO0 , O00OoooOoOo0o00o + '.zip' ) )
 ooo0o0 = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , o0IiiiI111I ) )
 try :
  downloader . download ( II1Ii , iIIi1 , IiI )
  extract . all ( iIIi1 , ooOoOoo0O , IiI )
 except :
  try :
   downloader . download ( I1IIIIiii1i , iIIi1 , IiI )
   extract . all ( iIIi1 , ooOoOoo0O , IiI )
  except :
   try :
    if not os . path . exists ( ooo0o0 ) :
     os . makedirs ( ooo0o0 )
    IIiIi1iI = i1IiiiI1iI ( OOoO00ooO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    IIII1iII = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IIiIi1iI )
    for ii1III11 in IIII1iII :
     I1iiIIIi11 = xbmc . translatePath ( os . path . join ( ooo0o0 , ii1III11 ) )
     if i1I1i111Ii not in ii1III11 and '/' not in ii1III11 :
      try :
       IiI . update ( 0 , "Downloading [COLOR=yellow]" + ii1III11 + '[/COLOR]' , '' , 'Please wait...' )
       print "downloading: " + OOoO00ooO + ii1III11
       downloader . download ( OOoO00ooO + ii1III11 , I1iiIIIi11 , IiI )
      except : print "failed to install" + ii1III11
     if '/' in ii1III11 and '..' not in ii1III11 and 'http' not in ii1III11 :
      Ii1I11ii1i = OOoO00ooO + ii1III11
      O0iIiIIIIIii ( I1iiIIIi11 , Ii1I11ii1i )
   except :
    Oo0O . ok ( "Error downloading repository" , 'There was an error downloading the [COLOR=yellow]' + O00OoooOoOo0o00o , '[/COLOR]repository. Please consider updating the add-on portal with details' , 'or report the error on the forum at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B]' )
    o00oo0 = 0
 if o00oo0 == 1 :
  time . sleep ( 1 )
  IiI . update ( 0 , "[COLOR=yellow]" + O00OoooOoOo0o00o + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing dependencies' )
  time . sleep ( 1 )
  oO0oo = 'http://totalxbmc.com/totalrevolution/AddonPortal/downloadcount.php?id=%s' % ( repo_id )
  i1IiiiI1iI ( oO0oo )
  if 84 - 84: oOOoO0O0O0 - iiIi * IIIIII11i1I / Oo000o . Oo000o
  if 93 - 93: IIIIII11i1I / i1OOO + oO0o0ooo
def I111 ( ) :
 Ii ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  What is Community Builds?' , 'url' , 'instructions_3' , 'How_To.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Creating a Community Build' , 'url' , 'instructions_1' , 'How_To.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Installing a Community Build' , 'url' , 'instructions_2' , 'How_To.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Add Your Own Guides @ [COLOR=lime]TotalXBMC.tv[/COLOR]' , 'K0XIxEodUhc' , 'play_video' , 'How_To.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Community Builds FULL GUIDE' , "ewuxVfKZ3Fs" , 'play_video' , 'howto.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  IMPORTANT initial settings' , "1vXniHsEMEg" , 'play_video' , 'howto.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Install a Community Build' , "kLsVOapuM1A" , 'play_video' , 'howto.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Fixing a half installed build (guisettings.xml fix)' , "X8QYLziFzQU" , 'play_video' , 'howto.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 1)' , "3rMScZF2h_U" , 'play_video' , 'howto.png' , '' , '' , '' )
 Ii ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 2)' , "C2IPhn0OSSw" , 'play_video' , 'howto.png' , '' , '' , '' )
 if 17 - 17: o0o0OOO0o0 + oO0o0ooo
 if 57 - 57: OoOo / O0oO
def iiIiII ( ) :
 Oo0000o0O0O ( 'Creating A Community Backup' ,
 '[COLOR=yellow]NEW METHOD[/COLOR][CR][COLOR=blue][B]Step 1:[/COLOR] Remove any sensitive data[/B][CR]Make sure you\'ve removed any sensitive data such as passwords and usernames in your addon_data folder.'
 '[CR][CR][COLOR=blue][B]Step 2:[/COLOR] Backup your system[/B][CR]Choose the backup option from the main menu, in there you\'ll find the option to create a Full Backup and this will create two zip files that you need to upload to a server.'
 '[CR][CR][COLOR=blue][B]Step 3:[/COLOR] Upload the zips[/B][CR]Upload the two zip files to a server that Kodi can access, it has to be a direct link and not somewhere that asks for captcha - Dropbox and archive.org are two good examples.'
 '[CR][CR][COLOR=blue][B]Step 4:[/COLOR] Submit build at TotalXBMC[/B]'
 '[CR]Create a thread on the Community Builds section of the forum at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B].[CR]Full details can be found on there of the template you should use when posting, once you\'ve created your support thread (NOT BEFORE) you can request to become a member of the Community Builder group and you\'ll then have access to the web form for adding your builds to the portal.'
 '[CR][CR][COLOR=yellow]OLD METHOD[/COLOR][CR][COLOR=blue][B]Step 1: Backup your system[/B][/COLOR][CR]Choose the backup option from the main menu, you will be asked whether you would like to delete your addon_data folder. If you decide to choose this option [COLOR=yellow][B]make sure[/COLOR][/B] you already have a full backup of your system as it will completely wipe your addon settings (any stored settings such as passwords or any other changes you\'ve made to addons since they were first installed). If sharing a build with the community it\'s highly advised that you wipe your addon_data but if you\'ve made changes or installed extra data packages (e.g. skin artwork packs) then backup the whole build and then manually delete these on your PC and zip back up again (more on this later).'
 '[CR][CR][COLOR=blue][B]Step 2: Edit zip file on your PC[/B][/COLOR][CR]Copy your backup.zip file to your PC, extract it and delete all the addons and addon_data that isn\'t required.'
 '[CR][COLOR=blue]What to delete:[/COLOR][CR][COLOR=lime]/addons/packages[/COLOR] This folder contains zip files of EVERY addon you\'ve ever installed - it\'s not needed.'
 '[CR][COLOR=lime]/addons/<skin.xxx>[/COLOR] Delete any skins that aren\'t used, these can be very big files.'
 '[CR][COLOR=lime]/addons/<addon_id>[/COLOR] Delete any other addons that aren\'t used, it\'s easy to forget you\'ve got things installed that are no longer needed.'
 '[CR][COLOR=lime]/userdata/addon_data/<addon_id>[/COLOR] Delete any folders that don\'t contain important changes to addons. If you delete these the associated addons will just reset to their default values.'
 '[CR][COLOR=lime]/userdata/<all other folders>[/COLOR] Delete all other folders in here such as keymaps. If you\'ve setup profiles make sure you [COLOR=yellow][B]keep the profiles directory[/COLOR][/B].'
 '[CR][COLOR=lime]/userdata/Thumbnails/[/COLOR] Delete this folder, it contains all cached artwork. You can safely delete this but must also delete the file listed below.'
 '[CR][COLOR=lime]/userdata/Database/Textures13.db[/COLOR] Delete this and it will tell XBMC to regenerate your thumbnails - must do this if delting thumbnails folder.'
 '[CR][COLOR=lime]/xbmc.log (or Kodi.log)[/COLOR] Delete your log files, this includes any crashlog files you may have.'
 '[CR][CR][COLOR=blue][B]Step 3: Compress and upload[/B][/COLOR][CR]Use a program like 7zip to create a zip file of your remaining folders and upload to a file sharing site like dropbox.'
 '[CR][CR][COLOR=blue][B]Step 4: Submit build at TotalXBMC[/B][/COLOR]'
 '[CR]Create a thread on the Community Builds section of the forum at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B].[CR]Full details can be found on there of the template you should use when posting.' )
 if 7 - 7: iiIi - o0O0 . iii11I111 / o0o0OOO0o0 * OoOo
 if 100 - 100: i1OOO / i1OOO - OOO00OoOO00 % OOO00OoOO00 * Ooo0Oo0 / ooOO0o
def IIIIIIi ( ) :
 Oo0000o0O0O ( 'Installing a community build' , '[COLOR=blue][B]Step 1 (Optional): Backup your system[/B][/COLOR][CR]We highly recommend creating a backup of your system in case you don\'t like the build and want to revert back. Choose the backup option from the main menu, you will be asked whether you would like to delete your addon_data folder, select no unless you want to lose all your settings. If you ever need your backup it\'s stored in the location you\'ve selected in the addon settings.'
 '[CR][CR][COLOR=blue][B]Step 2: Browse the Community Builds[/B][/COLOR][CR]Find a community build you like the look of and make sure you read the description as it could contain unsuitable content or have specific install instructions. Once you\'ve found the build you want to install click on the install option and you\'ll have the option of a fresh install or a merge . The merge option will leave all your existing addons and userdata in place and just add the contents of the new build whereas the fresh (wipe) option will completely wipe your existing data and replace with content on the new build. Once you make your choice the download and extraction process will begin.'
 '[CR][CR][COLOR=blue][B]Step 3: [/COLOR][COLOR=red]VERY IMPORTANT[/COLOR][/B][CR]For the install to complete properly you MUST change the skin to the relevant skin used for that build. You will see a dialog box telling you which skin to switch to and then you\'ll be taken to the appearance settings where you can switch skins.'
 '[CR][CR][COLOR=blue][B]Step 4:[/B][/COLOR] Now go back to the Community Builds addon and in the same section wehre you clicked on step 1 of the install process you now need to select step 2 so it can install the guisettings.xml. This is extremely important, if you don\'t do this step then you\'ll end up with a real mish-mash hybrid install!'
 '[CR][CR][COLOR=blue][B]Step 5:[/B][/COLOR] You will now need to restart Kodi so the settings stick, just quit and it should all be fine. If for any reason the settings did not stick and it still doesn\'t look quite right just do step 2 of the install process again (guisettings.xml fix)' )
 if 59 - 59: Ooo0Oo0 / oO0o0ooo * Oo000o % IIIIII11i1I - ii1I11II1ii1i + IIII
 if 21 - 21: O0oO
def OooO0O0Ooo ( ) :
 Oo0000o0O0O ( 'What is a community build' , 'Community Builds are pre-configured builds of XBMC/Kodi based on different users setups. Have you ever watched youtube videos or seen screenshots of Kodi in action and thought "wow I wish I could do that"? Well now you can have a brilliant setup at the click of a button, completely pre-configured by users on the [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B] forum. If you\'d like to get involved yourself and share your build with the community it\'s very simple to do, just go to the forum where you\'ll find full details or you can follow the guide in this addon.' )
 if 85 - 85: OoOo / O0oO
 if 67 - 67: oOOoO0O0O0 % Ooo0Oo0
def ii1iiIi ( url = 'http://www.iplocation.net/' , inc = 1 ) :
 IIII1iII = re . compile ( "<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>" ) . findall ( iIii1 . http_GET ( url ) . content )
 for i11ii1i1i , iIIi1IiII11 , OOOOo0oOOOOooOo , i1I111II in IIII1iII :
  if inc < 2 : Oo0O = xbmcgui . Dialog ( ) ; Oo0O . ok ( 'Check My IP' , "[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s" % i11ii1i1i , '[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s' % OOOOo0oOOOOooOo , '[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s' % i1I111II )
  inc = inc + 1
  if 65 - 65: i11iIiiIii + iiIi * IIII - iiiIi1i1I
  if 26 - 26: OoOo % OOO00OoOO00 + OOO00OoOO00 % oOOoO0O0O0 * i11iIiiIii / OoO0O00
  if 64 - 64: Ooo0Oo0 % II11iII / ii1I11II1ii1i % i1OOO - OoO0O00
def ooOoOOoooO000 ( ) :
 Oo0O . ok ( '[COLOR=blue]T[/COLOR]otal[COLOR=dodgerblue]R[/COLOR]evolution' , 'The system will now attempt to force close Kodi.' , 'You may encounter a freeze, if that happens give it a minute' , 'and if it doesn\'t close please restart your system.' )
 if xbmc . getCondVisibility ( 'system.platform.osx' ) :
  print "############   try osx force close  #################"
  try : os . system ( 'killall -9 XBMC' )
  except : pass
  try : os . system ( 'killall -9 Kodi' )
  except : pass
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  print "############   try linux force close  #################"
  try : os . system ( 'killall XBMC' )
  except : pass
  try : os . system ( 'killall Kodi' )
  except : pass
  try : os . system ( 'killall -9 xbmc.bin' )
  except : pass
  try : os . system ( 'killall -9 kodi.bin' )
  except : pass
 elif xbmc . getCondVisibility ( 'system.platform.android' ) :
  print "############   try android force close  #################"
  try : os . system ( 'adb shell am force-stop org.xbmc.kodi' )
  except : pass
  try : os . system ( 'adb shell am force-stop org.kodi' )
  except : pass
  try : os . system ( 'adb shell am force-stop org.xbmc.xbmc' )
  except : pass
  try : os . system ( 'adb shell am force-stop org.xbmc' )
  except : pass
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  print "############   try windows force close  #################"
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill XBMC.exe' )
  except : pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill Kodi.exe' )
  except : pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im Kodi.exe /f' )
  except : pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im XBMC.exe /f' )
  except : pass
 else :
  print "############   try atv force close  #################"
  try : os . system ( 'killall AppleTV' )
  except : pass
  print "############   try raspbmc force close  #################"
  try : os . system ( 'sudo initctl stop kodi' )
  except : pass
  try : os . system ( 'sudo initctl stop xbmc' )
  except : pass
 Oo0O . ok ( "WARNING  !!!" , "If you\'re seeing this message it means the force close" , "was unsuccessful. Please close XBMC/Kodi via your operating system." , '' )
 if 2 - 2: O0oO - iii11I111 + OoOo * iiiIi1i1I / OoO0O00
def iIIiI11iI1Ii1 ( ) :
 OOooO0OOoo = xbmc . translatePath ( 'special://logpath' )
 oo0oO = xbmc . getInfoLabel ( "System.BuildVersion" )
 i1i1iI1iiiI = float ( oo0oO [ : 4 ] )
 if i1i1iI1iiiI < 14 :
  o00oo = os . path . join ( OOooO0OOoo , 'xbmc.log' )
  Oo0000o0O0O ( 'XBMC Log' , o00oo )
 else :
  o00oo = os . path . join ( OOooO0OOoo , 'kodi.log' )
  Oo0000o0O0O ( 'Kodi Log' , o00oo )
  if 70 - 70: oOOoO0O0O0 - iiIi / IIII % IIII
  if 95 - 95: IIII % IIII . Oo000o
def III1ii ( ) :
 Oo0O . ok ( "Restore local guisettings fix" , "You should [COLOR=lime]ONLY[/COLOR] use this option if the guisettings fix" , "is failing to download via the addon. Installing via this" , "method means you do not receive notifications of updates" )
 iII1ii ( )
 if 76 - 76: iii11I111
def ooO000OO ( mypath , dirname ) :
 import xbmcvfs
 if 43 - 43: i1OOO * O0oO % OOO00OoOO00
 if 38 - 38: iiIi
 if not xbmcvfs . exists ( mypath ) :
  try :
   xbmcvfs . mkdirs ( mypath )
  except :
   xbmcvfs . mkdir ( mypath )
   if 34 - 34: II11iII
 OoO0o00OOOOO = os . path . join ( mypath , dirname )
 if 19 - 19: OoO0O00 * iiIi . OoO0O00 . iiiIi1i1I / iiiIi1i1I - Ooo0Oo0
 if not xbmcvfs . exists ( OoO0o00OOOOO ) :
  try :
   xbmcvfs . mkdirs ( OoO0o00OOOOO )
  except :
   xbmcvfs . mkdir ( OoO0o00OOOOO )
   if 9 - 9: O0oO * ooOO0o * O0oO
 return OoO0o00OOOOO
 if 74 - 74: o0o0OOO0o0 / OoOo
 if 58 - 58: o0o0OOO0o0 - oO0o0ooo % OoOo % IIII * o0o0OOO0o0 + OOO00OoOO00
def iIiI1i111ii ( mode ) :
 if not mode . endswith ( "premium" ) and not mode . endswith ( "public" ) and not mode . endswith ( "private" ) :
  oOooOo00OooO0oO = I1IIi ( heading = "Search for content" )
  if ( not oOooOo00OooO0oO ) : return False , 0
  O0OOOo = urllib . quote_plus ( oOooOo00OooO0oO )
  if mode == 'tutorials' :
   O0o00oO0oOO ( 'name=' + O0OOOo )
  if mode == 'hardware' :
   OOo0OOoO00o0 ( 'name=' + O0OOOo )
  if mode == 'news' :
   ooIII1II1iii1i ( 'name=' + O0OOOo )
 if mode . endswith ( "premium" ) or mode . endswith ( "public" ) or mode . endswith ( "private" ) :
  Ii ( 'folder' , 'Search By Name' , mode + '&name=' , 'search_builds' , 'Manual_Search.png' , '' , '' , '' )
  Ii ( 'folder' , 'Search By Uploader' , mode + '&author=' , 'search_builds' , 'Search_Genre.png' , '' , '' , '' )
  Ii ( 'folder' , 'Search By Audio Addons Installed' , mode + '&audio=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  Ii ( 'folder' , 'Search By Picture Addons Installed' , mode + '&pics=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  Ii ( 'folder' , 'Search By Program Addons Installed' , mode + '&progs=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  Ii ( 'folder' , 'Search By Video Addons Installed' , mode + '&vids=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  Ii ( 'folder' , 'Search By Skins Installed' , mode + '&skins=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  if 48 - 48: o0o0OOO0o0 . oOOoO0O0O0 - OOO00OoOO00 . O0oO * Ooo0Oo0 % Ooo0Oo0
  if 38 - 38: iiIi % iii11I111 - OoO0O00 * o0o0OOO0o0 / IIIIII11i1I
def I1iI11IiiI11i ( url ) :
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/LatestNews/LatestNews.php?id=%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iIi = re . compile ( 'name="(.+?)"' ) . findall ( IIiIi1iI )
 oOOII1i11i1iIi11 = re . compile ( 'author="(.+?)"' ) . findall ( IIiIi1iI )
 IIIiIIIi11I = re . compile ( 'date="(.+?)"' ) . findall ( IIiIi1iI )
 o00oooO0Oo = re . compile ( 'content="(.+?)###END###"' ) . findall ( IIiIi1iI )
 if 46 - 46: OOO00OoOO00 . oOOoO0O0O0 % oO0o0ooo - i1OOO
 I1II1 = i1iIi [ 0 ] if ( len ( i1iIi ) > 0 ) else ''
 IIi1iI1 = oOOII1i11i1iIi11 [ 0 ] if ( len ( oOOII1i11i1iIi11 ) > 0 ) else ''
 O0OO0oOO = IIIiIIIi11I [ 0 ] if ( len ( IIIiIIIi11I ) > 0 ) else ''
 O0O0o0o0o = o00oooO0Oo [ 0 ] if ( len ( o00oooO0Oo ) > 0 ) else ''
 II1I1I1i1i = I11iIiI1 ( O0O0o0o0o )
 IIII1 = str ( '[COLOR=gold]Source: [/COLOR]' + IIi1iI1 + '     [COLOR=gold]Date: [/COLOR]' + O0OO0oOO + '[CR][CR][COLOR=lime]Details: [/COLOR][CR]' + II1I1I1i1i )
 Oo0000o0O0O ( I1II1 , IIII1 )
 if 74 - 74: IIIIII11i1I % IIII * iiIi + OOO00OoOO00 * OoO0O00
 if 100 - 100: OOO00OoOO00 + Oo000o * OoOo + ii1I11II1ii1i
def oOo0O000Ooo0 ( url ) :
 if O00ooooo00 == 'true' :
  Ii ( '' , '[COLOR=orange]Latest ' + I1IiiI + ' news[/COLOR]' , I1IiiI , 'notify_msg' , 'LatestNews.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'news' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime][All News][/COLOR] From all sites' , str ( url ) + '' , 'grab_news' , 'Latest.png' , '' , '' , '' )
 Ii ( 'folder' , 'Official Kodi.tv News' , str ( url ) + '&author=Official%20Kodi' , 'grab_news' , 'XBMC.png' , '' , '' , '' )
 Ii ( 'folder' , 'OpenELEC News' , str ( url ) + '&author=OpenELEC' , 'grab_news' , 'OpenELEC.png' , '' , '' , '' )
 Ii ( 'folder' , 'Raspbmc News' , str ( url ) + '&author=Raspbmc' , 'grab_news' , 'Raspbmc.png' , '' , '' , '' )
 Ii ( 'folder' , 'TotalXBMC News' , str ( url ) + '&author=TotalXBMC' , 'grab_news' , 'TOTALXBMC.png' , '' , '' , '' )
 Ii ( 'folder' , 'XBMC4Xbox News' , str ( url ) + '&author=XBMC4Xbox' , 'grab_news' , 'XBMC4Xbox.png' , '' , '' , '' )
 if 30 - 30: o0O0
 if 75 - 75: oOOoO0O0O0 . OOO00OoOO00 - o0o0OOO0o0 * iiiIi1i1I * OoO0O00
def ooo0OO0OOooO0 ( title , message , times , icon ) :
 icon = ii11iIi1I + icon
 xbmc . executebuiltin ( "XBMC.Notification(" + title + "," + message + "," + times + "," + icon + ")" )
 if 96 - 96: OOO00OoOO00 + OOO00OoOO00 % ooOO0o % OOO00OoOO00
def IiiI1I ( url ) :
 OoO0o000oOo = xbmc . translatePath ( os . path . join ( iI1Ii11111iIi , O0O0OO0O0O0 , 'notification.txt' ) )
 if not os . path . exists ( OoO0o000oOo ) :
  OooOOOo0 = open ( OoO0o000oOo , mode = 'w' )
  OooOOOo0 . write ( '20150101000000' )
  OooOOOo0 . close ( )
 Ii11iIII = open ( OoO0o000oOo , 'r' ) . read ( )
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/Community_Builds/notify?reseller=%s' % ( I1IiiI )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 o0ooOO0OOO00o = re . compile ( 'notify="(.+?)"' ) . findall ( IIiIi1iI )
 OoOoO0ooooO0 = o0ooOO0OOO00o [ 0 ] if ( len ( o0ooOO0OOO00o ) > 0 ) else 'No news items available'
 IIIiIIIi11I = re . compile ( 'date="(.+?)"' ) . findall ( IIiIi1iI )
 IIII1ii1 = IIIiIIIi11I [ 0 ] if ( len ( IIIiIIIi11I ) > 0 ) else ''
 OOO0O0OOo = IIII1ii1 . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' )
 if int ( Ii11iIII ) < int ( OOO0O0OOo ) :
  OooOOOo0 = open ( OoO0o000oOo , mode = 'w' )
  OooOOOo0 . write ( OOO0O0OOo )
  OooOOOo0 . close ( )
  Oo0O . ok ( 'Latest ' + I1IiiI + ' News' , OoOoO0ooooO0 )
 else :
  Oo0O . ok ( 'Latest ' + I1IiiI + ' News' , OoOoO0ooooO0 )
  if 10 - 10: IIII / OoO0O00 / Ooo0Oo0 * iiIi / o0o0OOO0o0
  if 63 - 63: ii1I11II1ii1i
def i1IiiiI1iI ( url ) :
 IiiI1II1iII1IIi1IiI = urllib2 . Request ( url )
 IiiI1II1iII1IIi1IiI . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 iIi = urllib2 . urlopen ( IiiI1II1iII1IIi1IiI )
 IIiIi1iI = iIi . read ( )
 iIi . close ( )
 return IIiIi1iI . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
 if 65 - 65: ii1I11II1ii1i + o0O0 * i11iIiiIii
 if 38 - 38: o0o0OOO0o0 + IIII * oO0o0ooo % II11iII % oOOoO0O0O0 - ooOO0o
def Oo0OO00OO0Oo ( name , url , iconimage , description ) :
 IiIo00oO0o00O = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/script.tvguidedixie/' , '' ) )
 i11i11Iiii11i = os . path . join ( IiIo00oO0o00O , 'local.ini' )
 II1Ii1iI1i1 = Oo0O . yesno ( 'OffsideStreams / OnTapp.TV Integration ' , str ( description ) , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if II1Ii1iI1i1 == 0 :
  return
 elif II1Ii1iI1i1 == 1 :
  oo0000Oo00o = i11i11Iiii11i
  if not os . path . exists ( IiIo00oO0o00O ) :
   Oo0O . ok ( '[COLOR=red]OnTapp Not Installed[/COLOR]' , 'The On-Tapp.TV addon has not been found on this system, please install then run this again.' )
   if 6 - 6: II11iII - i1OOO * OoOo + II11iII % OoOo
   if 100 - 100: iiiIi1i1I % O0oO - oOOoO0O0O0 % oOOoO0O0O0 % oOOoO0O0O0 / i1OOO
  else :
   iIIiI1iiI ( url , oo0000Oo00o )
   Oo0O . ok ( 'OSS Integration complete' , 'The OffsideStreams local.ini file has now been copied to your OnTapp.TV directory' )
   if 83 - 83: Ooo0Oo0 - i1OOO - ooOO0o % o0O0 - OoO0O00 . OoOo
   if 96 - 96: iiIi + O0oO . o0O0
def OooIii1I1iI ( url ) :
 Ii ( 'folder' , '[COLOR=yellow]1. Install:[/COLOR]  Installation tutorials (e.g. flashing a new OS)' , str ( url ) + '&thirdparty=InstallTools' , 'grab_tutorials' , 'Install.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Add-on Tools:[/COLOR]  Add-on maintenance and coding tutorials' , str ( url ) + '&thirdparty=AddonTools' , 'grab_tutorials' , 'ADDONTOOLS.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Audio Tools:[/COLOR]  Audio related tutorials' , str ( url ) + '&thirdparty=AudioTools' , 'grab_tutorials' , 'AUDIOTOOLS.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Gaming Tools:[/COLOR]  Integrate a gaming section into your setup' , str ( url ) + '&thirdparty=GamingTools' , 'grab_tutorials' , 'gaming_portal.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Image Tools:[/COLOR]  Tutorials to assist with your pictures/photos' , str ( url ) + '&thirdparty=ImageTools' , 'grab_tutorials' , 'IMAGETOOLS.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Library Tools:[/COLOR]  Music and Video Library Tutorials' , str ( url ) + '&thirdparty=LibraryTools' , 'grab_tutorials' , 'LIBRARYTOOLS.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Skinning Tools:[/COLOR]  All your skinning advice' , str ( url ) + '&thirdparty=SkinningTools' , 'grab_tutorials' , 'SKINNINGTOOLS.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Video Tools:[/COLOR]  All video related tools' , str ( url ) + '&thirdparty=VideoTools' , 'grab_tutorials' , 'VIDEOTOOLS.png' , '' , '' , '' )
 if 62 - 62: Ooo0Oo0 + iiIi / i11iIiiIii
 if 90 - 90: o0o0OOO0o0 + II11iII
def iIiI ( xmlfile ) :
 IiIIIiI = i1iiI11I ( xmlfile , Oo0Ooo . getAddonInfo ( 'path' ) , 'DefaultSkin' , close_time = 34 )
 IiIIIiI . doModal ( )
 del IiIIIiI
 if 19 - 19: iiiIi1i1I . IIII * iiiIi1i1I + ooOO0o + IIII
def i11iiI ( ) :
 IIiIi1iI = i1IiiiI1iI ( 'http://totalxbmc.tv/totalrevolution/Addon_Packs/addonpacks.txt' ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIII1iII = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( IIiIi1iI )
 for I1II1 , ooo0oOOO0 , OO0ooo0oOO , oo000 , IIII1 in IIII1iII :
  Ii ( 'folder2' , I1II1 , ooo0oOOO0 , 'popularwizard' , OO0ooo0oOO , oo000 , '' , IIII1 )
  if 67 - 67: iii11I111 + Oo000o
def o0O00OooooO ( name , url , iconimage , description ) :
 Oo0000o0O0O ( name , description )
 II1Ii1iI1i1 = Oo0O . yesno ( name , 'This will install the ' + name , '' , 'Are you sure you want to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if II1Ii1iI1i1 == 0 :
  return
 elif II1Ii1iI1i1 == 1 :
  import downloader
  oo0000Oo00o = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  ooOoOoo0O = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  IiI = xbmcgui . DialogProgress ( )
  IiI . create ( "Addon Packs" , "Downloading " + name + " addon pack." , '' , 'Please Wait' )
  i1III1iI = os . path . join ( oo0000Oo00o , name + '.zip' )
  try :
   os . remove ( i1III1iI )
  except :
   pass
   downloader . download ( url , i1III1iI , IiI )
   time . sleep ( 3 )
   IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
   xbmc . executebuiltin ( "XBMC.Extract(%s,%s)" % ( i1III1iI , ooOoOoo0O ) )
   Oo0O . ok ( "Total Installer" , "All Done. Your addons will now go through the update process, it may take a minute or two until the addons are working." )
   time . sleep ( 1 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( 'UpdateAddonRepos' )
   if 77 - 77: oO0o0ooo % i1OOO
   if 74 - 74: II11iII / o0O0 % IIII
   if 52 - 52: ooOO0o % i1OOO
def O0iIiIIIIIii ( recursive_location , remote_path ) :
 if not os . path . exists ( recursive_location ) :
  os . makedirs ( recursive_location )
 IIiIi1iI = i1IiiiI1iI ( remote_path ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIII1iII = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IIiIi1iI )
 for ii1III11 in IIII1iII :
  I1iiIIIi11 = xbmc . translatePath ( os . path . join ( recursive_location , ii1III11 ) )
  if '/' not in ii1III11 :
   try :
    IiI . update ( 0 , "Downloading [COLOR=yellow]" + ii1III11 + '[/COLOR]' , '' , 'Please wait...' )
    print "downloading: " + remote_path + ii1III11
    downloader . download ( remote_path + ii1III11 , I1iiIIIi11 , IiI )
   except : print "failed to install" + ii1III11
  if '/' in ii1III11 and '..' not in ii1III11 and 'http' not in ii1III11 :
   I111oOOooo00OOooO = remote_path + ii1III11
   O0iIiIIIIIii ( I1iiIIIi11 , I111oOOooo00OOooO )
  else : pass
  if 31 - 31: oO0o0ooo / OoOo + oO0o0ooo - ii1I11II1ii1i
  if 29 - 29: oO0o0ooo + i11iIiiIii . IIIIII11i1I
def o0oo0Oo ( ) :
 Oo0O . ok ( "Register to unlock features" , "To get the most out of this addon please register at" , "the TotalXBMC forum for free." , "Visit [COLOR=lime]www.totalxbmc.tv/new-forum[/COLOR] for more details." )
 if 10 - 10: iii11I111
 if 87 - 87: iiIi % Oo000o
def ooO0o0oO0 ( ) :
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( 'Delete Addon_Data Folder?' , 'This will free up space by deleting your addon_data' , 'folder. This contains all addon related settings' , 'including username and password info.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if II1Ii1iI1i1 == 1 :
  iIIIiIi1I1i ( )
  Oo0O . ok ( "Addon_Data Removed" , '' , 'Your addon_data folder has now been removed.' , '' )
  if 66 - 66: O0oO % IIIIII11i1I
def o0o0ooOo00 ( url ) :
 OO00oO0OoO0o = str ( url ) . replace ( iiIIIII1i1iI , iI1Ii11111iIi )
 if Oo0O . yesno ( "Remove" , '' , "Do you want to Remove" ) :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( url ) :
   for oOOOO in O0Oo0o000oO :
    os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
   for OOOoO000 in o0O0Oo00 :
    shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
  os . rmdir ( url )
  try :
   for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( OO00oO0OoO0o ) :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
   os . rmdir ( OO00oO0OoO0o )
  except : pass
  xbmc . executebuiltin ( 'Container.Refresh' )
  if 5 - 5: OOO00OoOO00 % iiIi % ooOO0o % i1OOO
  if 17 - 17: Oo000o + ii1I11II1ii1i + IIII / OOO00OoOO00 / ooOO0o
def oOoo0Ooooo ( ) :
 oo00o ( )
 Ii1Ii1IiIIIi1 = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to DELETE' , 'files' , '.zip' , False , False , oO0o0o0ooO0oO )
 if Ii1Ii1IiIIIi1 != oO0o0o0ooO0oO :
  OOoo00 = ntpath . basename ( Ii1Ii1IiIIIi1 )
  II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( 'Delete Backup File' , 'This will completely remove ' + OOoo00 , 'Are you sure you want to delete?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Delete' )
  if II1Ii1iI1i1 == 1 :
   os . remove ( Ii1Ii1IiIIIi1 )
   if 22 - 22: i1OOO / i1OOO - Oo000o % oOOoO0O0O0 . OOO00OoOO00 + ooOO0o
   if 64 - 64: o0O0 % iii11I111 / Oo000o % IIII
def I1iii1 ( ) :
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( 'Remove All Crash Logs?' , 'There is absolutely no harm in doing this, these are' , 'log files generated when Kodi crashes and are' , 'only used for debugging purposes.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if II1Ii1iI1i1 == 1 :
  Ii11iI1ii1111 ( )
  Oo0O . ok ( "Crash Logs Removed" , '' , 'Your crash log files have now been removed.' , '' )
  if 19 - 19: Ooo0Oo0 % IIII . IIII
  if 40 - 40: IIIIII11i1I . O0oO / o0o0OOO0o0 * OoOo
def OOo00Oooo ( ) :
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( 'Delete Packages Folder?' , 'This will free up space by deleting the zip install' , 'files of your addons. The only downside is you\'ll no' , 'longer be able to rollback to older versions.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if II1Ii1iI1i1 == 1 :
  iii11II1I ( )
  Oo0O . ok ( "Packages Removed" , '' , 'Your zip install files have now been removed.' , '' )
  if 15 - 15: i1OOO . o0o0OOO0o0 * oO0o0ooo % oOOoO0O0O0
  if 21 - 21: iiiIi1i1I - oO0o0ooo . IIII
def i1I11iIiII ( ) :
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( 'Clear Cached Images?' , 'This will clear your textures13.db file and remove' , 'your Thumbnails folder. These will automatically be' , 'repopulated after a restart.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if II1Ii1iI1i1 == 1 :
  Ii1iiI1i1 ( )
  iiIIi ( I1i1iiI1 )
  II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( 'Quit Kodi Now?' , 'Cache has been successfully deleted.' , 'You must now restart Kodi, would you like to quit now?' , '' , nolabel = 'I\'ll restart later' , yeslabel = 'Yes, quit' )
  if II1Ii1iI1i1 == 1 :
   ooOoOOoooO000 ( )
   if 3 - 3: OOO00OoOO00 . ooOO0o / iiIi
   if 89 - 89: IIII . o0o0OOO0o0 . iiIi * o0o0OOO0o0 - O0oO
def Ii1iiI1i1 ( ) :
 OoOO0o0o0 = xbmc . translatePath ( 'special://home/userdata/Database/Textures13.db' )
 try :
  iI111ii1iIiI = database . connect ( OoOO0o0o0 )
  OoO0oo0 = iI111ii1iIiI . cursor ( )
  OoO0oo0 . execute ( "DROP TABLE IF EXISTS path" )
  OoO0oo0 . execute ( "VACUUM" )
  iI111ii1iIiI . commit ( )
  OoO0oo0 . execute ( "DROP TABLE IF EXISTS sizes" )
  OoO0oo0 . execute ( "VACUUM" )
  iI111ii1iIiI . commit ( )
  OoO0oo0 . execute ( "DROP TABLE IF EXISTS texture" )
  OoO0oo0 . execute ( "VACUUM" )
  iI111ii1iIiI . commit ( )
  OoO0oo0 . execute ( """CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""" )
  iI111ii1iIiI . commit ( )
  OoO0oo0 . execute ( """CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""" )
  iI111ii1iIiI . commit ( )
  OoO0oo0 . execute ( """CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""" )
  iI111ii1iIiI . commit ( )
 except :
  pass
  if 19 - 19: iiiIi1i1I / iiiIi1i1I % Oo000o
  if 34 - 34: o0O0 - II11iII + OoOo - iiIi % iii11I111
def ii ( ) :
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/Community_Builds/reseller?reseller=%s&token=%s' % ( I1IiiI , IIi1IiiiI1Ii )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IiIIi1I1I11Ii = re . compile ( 'path="(.+?)"' ) . findall ( IIiIi1iI )
 I11ii1iI11 = re . compile ( 'reseller="(.+?)"' ) . findall ( IIiIi1iI )
 i11ii111i1ii = re . compile ( 'premium="(.+?)"' ) . findall ( IIiIi1iI )
 Oo0O0O = I11ii1iI11 [ 0 ] if ( len ( I11ii1iI11 ) > 0 ) else 'None'
 IiIiiI1ii111 = i11ii111i1ii [ 0 ] if ( len ( i11ii111i1ii ) > 0 ) else 'None'
 exec Oo0O0O
 exec IiIiiI1ii111
 if 30 - 30: Oo000o + ii1I11II1ii1i % IIII
 if 89 - 89: Oo000o
def ii1i ( url ) :
 o00O00O0Oo0 = zipfile . ZipFile ( url , "r" )
 for Ii1Ii1IiIIIi1 in o00O00O0Oo0 . namelist ( ) :
  if 'guisettings.xml' in Ii1Ii1IiIIIi1 :
   i11I1II = o00O00O0Oo0 . read ( Ii1Ii1IiIIIi1 )
   OoOiI11IiI1i1 = '<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>' % iI111I11I1I1
   IIII1iII = re . compile ( OoOiI11IiI1i1 ) . findall ( i11I1II )
   for type , ooOoOoO0 , Iii1II1ii in IIII1iII :
    Iii1II1ii = Iii1II1ii . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    xbmc . executebuiltin ( "Skin.Set%s(%s,%s)" % ( type . title ( ) , ooOoOoO0 , Iii1II1ii ) )
  if 'favourites.xml' in Ii1Ii1IiIIIi1 :
   i11I1II = o00O00O0Oo0 . read ( Ii1Ii1IiIIIi1 )
   oOOOO = open ( oOOoo00O0O , mode = 'w' )
   oOOOO . write ( i11I1II )
   oOOOO . close ( )
  if 'sources.xml' in Ii1Ii1IiIIIi1 :
   i11I1II = o00O00O0Oo0 . read ( Ii1Ii1IiIIIi1 )
   oOOOO = open ( i1111 , mode = 'w' )
   oOOOO . write ( i11I1II )
   oOOOO . close ( )
  if 'advancedsettings.xml' in Ii1Ii1IiIIIi1 :
   i11I1II = o00O00O0Oo0 . read ( Ii1Ii1IiIIIi1 )
   oOOOO = open ( i11 , mode = 'w' )
   oOOOO . write ( i11I1II )
   oOOOO . close ( )
  if 'RssFeeds.xml' in Ii1Ii1IiIIIi1 :
   i11I1II = o00O00O0Oo0 . read ( Ii1Ii1IiIIIi1 )
   oOOOO = open ( Oo0o0000o0o0 , mode = 'w' )
   oOOOO . write ( i11I1II )
   oOOOO . close ( )
  if 'keyboard.xml' in Ii1Ii1IiIIIi1 :
   i11I1II = o00O00O0Oo0 . read ( Ii1Ii1IiIIIi1 )
   oOOOO = open ( oOo0oooo00o , mode = 'w' )
   oOOOO . write ( i11I1II )
   oOOOO . close ( )
   if 95 - 95: iiIi
   if 29 - 29: Oo000o / i1OOO % oOOoO0O0O0
def ii1iIII1ii ( name , url , description ) :
 if 'Backup' in name :
  oo00o ( )
  I11Oo0O0O0O0OO = open ( url ) . read ( )
  o0OoOooOO0o0 = os . path . join ( oO0o0o0ooO0oO , description . split ( 'Your ' ) [ 1 ] )
  oOOOO = open ( o0OoOooOO0o0 , mode = 'w' )
  oOOOO . write ( I11Oo0O0O0O0OO )
  oOOOO . close ( )
 else :
  if 'guisettings.xml' in description :
   i11I1II = open ( os . path . join ( oO0o0o0ooO0oO , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   OoOiI11IiI1i1 = '<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>' % iI111I11I1I1
   IIII1iII = re . compile ( OoOiI11IiI1i1 ) . findall ( i11I1II )
   for type , ooOoOoO0 , Iii1II1ii in IIII1iII :
    Iii1II1ii = Iii1II1ii . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    xbmc . executebuiltin ( "Skin.Set%s(%s,%s)" % ( type . title ( ) , ooOoOoO0 , Iii1II1ii ) )
  else :
   o0OoOooOO0o0 = os . path . join ( url )
   I11Oo0O0O0O0OO = open ( os . path . join ( oO0o0o0ooO0oO , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   oOOOO = open ( o0OoOooOO0o0 , mode = 'w' )
   oOOOO . write ( I11Oo0O0O0O0OO )
   oOOOO . close ( )
 Oo0O . ok ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "" , 'All Done !' , '' )
 if 55 - 55: IIIIII11i1I % oO0o0ooo . IIII * iiIi / IIII . Oo000o
 if 26 - 26: ooOO0o / o0o0OOO0o0 - o0o0OOO0o0
def oO00oO00O0Oo ( name , url , video , description , skins , guisettingslink , artpack ) :
 OO0o0o0oo = 1
 oo00o ( )
 if os . path . exists ( O0OoO000O0OO ) :
  if os . path . exists ( Oo0oO0ooo ) :
   os . remove ( O0OoO000O0OO )
  else :
   os . rename ( O0OoO000O0OO , Oo0oO0ooo )
 if os . path . exists ( o0oOoO00o ) :
  os . remove ( o0oOoO00o )
 if not os . path . exists ( oooOOOOO ) :
  OooOOOo0 = open ( oooOOOOO , mode = 'w+' )
 if os . path . exists ( iiI1IiI ) :
  os . removedirs ( iiI1IiI )
 try : os . rename ( Oo0oO0ooo , O0OoO000O0OO )
 except :
  Oo0O . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit XBMC and try again' , '' )
  return
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( name , 'We highly recommend backing up your existing build before' , 'installing any community builds.' , 'Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
 if II1Ii1iI1i1 == 0 :
  iIiII1 = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Community Builds' , 'My Builds' ) )
  if not os . path . exists ( iIiII1 ) :
   os . makedirs ( iIiII1 )
  oOooOo00OooO0oO = I1IIi ( heading = "Enter a name for this backup" )
  if ( not oOooOo00OooO0oO ) : return False , 0
  O0OOOo = urllib . quote_plus ( oOooOo00OooO0oO )
  i11I1I1iiI = xbmc . translatePath ( os . path . join ( iIiII1 , O0OOOo + '.zip' ) )
  I1i1iii1Ii = [ 'plugin.program.TBS' ]
  iI = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' ]
  iii1 = "Creating full backup of existing build"
  II1iIi1IiIii = "Archiving..."
  I111I11I111 = ""
  iiiiI11ii = "Please Wait"
  iI1iIIIi1i ( ooOo , i11I1I1iiI , iii1 , II1iIi1IiIii , I111I11I111 , iiiiI11ii , I1i1iii1Ii , iI )
 i111iii1I1 = xbmcgui . Dialog ( ) . yesno ( name , 'Would you like to keep your existing database' , 'files or overwrite? Overwriting will wipe any' , 'existing library you may have scanned in.' , nolabel = 'Overwrite' , yeslabel = 'Keep Existing' )
 if i111iii1I1 == 0 : pass
 elif i111iii1I1 == 1 :
  if os . path . exists ( II ) :
   shutil . rmtree ( II )
  try :
   shutil . copytree ( O0oo0OO0 , II , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
  except :
   OO0o0o0oo = xbmcgui . Dialog ( ) . yesno ( name , 'There was an error trying to backup some databases.' , 'Continuing may wipe your existing library. Do you' , 'wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if OO0o0o0oo == 1 : pass
   if OO0o0o0oo == 0 : return
  i11I1I1iiI = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Database.zip' ) )
  oOOo000oOoO0 ( II , i11I1I1iiI )
 if OO0o0o0oo == 0 : return
 time . sleep ( 1 )
 IiI . create ( "Community Builds" , "Downloading " + description + " build." , '' , 'Please Wait' )
 i1III1iI = os . path . join ( oo0o0O00 , description + '.zip' )
 if not os . path . exists ( oo0o0O00 ) :
  os . makedirs ( oo0o0O00 )
 downloader . download ( url , i1III1iI , IiI )
 i1IiiiiIi1I = open ( o0oO0 , mode = 'r' )
 ooo0O0o0OoOO = i1IiiiiIi1I . read ( )
 i1IiiiiIi1I . close ( )
 ii1i ( i1III1iI )
 IiI . create ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "Checking " , '' , 'Please Wait' )
 IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
 extract . all ( i1III1iI , ooOo , IiI )
 time . sleep ( 1 )
 iiIiII1 = str ( artpack )
 i1i1IiIiIi1Ii = str ( video )
 if video != '' :
  iI11II1i1I1 ( i1i1IiIiIi1Ii )
 if video == '' and artpack != '' :
  iI11II1i1I1 ( iiIiII1 )
 OooOOOo0 = open ( oooOOOOO , mode = 'r' )
 O0O0o0o0o = file . read ( OooOOOo0 )
 file . close ( OooOOOo0 )
 o0I1IIIi11ii11 = re . compile ( 'id="(.+?)"' ) . findall ( O0O0o0o0o )
 O0o0oo0oOO0oO = o0I1IIIi11ii11 [ 0 ] if ( len ( o0I1IIIi11ii11 ) > 0 ) else ''
 iIiIII1iI1111 = re . compile ( 'name="(.+?)"' ) . findall ( O0O0o0o0o )
 Ii1I1I111iI = iIiIII1iI1111 [ 0 ] if ( len ( iIiIII1iI1111 ) > 0 ) else ''
 I1i11I = re . compile ( 'version="(.+?)"' ) . findall ( O0O0o0o0o )
 oooOOOO0oooo = I1i11I [ 0 ] if ( len ( I1i11I ) > 0 ) else ''
 iIi11i = open ( i1iiIII111ii , mode = 'w+' )
 iIi11i . write ( 'id="' + str ( O0o0oo0oOO0oO ) + '"\nname="' + Ii1I1I111iI + ' [COLOR=yellow](Partially installed)[/COLOR]"\nversion="' + oooOOOO0oooo + '"' )
 iIi11i . close ( )
 oO0oo = 'http://totalxbmc.com/totalrevolution/Community_Builds/downloadcount.php?id=%s' % ( O0o0oo0oOO0oO )
 i1IiiiI1iI ( oO0oo )
 OooOOOo0 = open ( i1iiIIiiI111 , mode = 'r' )
 O0O0o0o0o = file . read ( OooOOOo0 )
 file . close ( OooOOOo0 )
 ooo0oo00O00Oo = re . compile ( 'version="(.+?)"' ) . findall ( O0O0o0o0o )
 OOO000000OOO0 = ooo0oo00O00Oo [ 0 ] if ( len ( ooo0oo00O00Oo ) > 0 ) else ''
 IiIiIIiii1I = O0O0o0o0o . replace ( OOO000000OOO0 , oooOOOO0oooo )
 iIi11i = open ( i1iiIIiiI111 , mode = 'w' )
 iIi11i . write ( str ( IiIiIIiii1I ) )
 iIi11i . close ( )
 os . remove ( oooOOOOO )
 if ooo0OO == 'false' :
  os . remove ( i1III1iI )
 ii111iI = open ( o0oO0 , mode = 'w+' )
 ii111iI . write ( ooo0O0o0OoOO )
 ii111iI . close ( )
 try :
  os . rename ( Oo0oO0ooo , o0oOoO00o )
 except :
  print "NO GUISETTINGS DOWNLOADED"
 time . sleep ( 1 )
 OooOOOo0 = open ( O0OoO000O0OO , mode = 'r' )
 O0O0o0o0o = file . read ( OooOOOo0 )
 file . close ( OooOOOo0 )
 Ii1IIIII = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( O0O0o0o0o )
 iiiIIiiii11 = Ii1IIIII [ 0 ] if ( len ( Ii1IIIII ) > 0 ) else ''
 IIiI1iIIiI1I1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( O0O0o0o0o )
 IiIIiI = IIiI1iIIiI1I1i [ 0 ] if ( len ( IIiI1iIIiI1I1i ) > 0 ) else ''
 oOo0Oo0O0O = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( O0O0o0o0o )
 III1II1i = oOo0Oo0O0O [ 0 ] if ( len ( oOo0Oo0O0O ) > 0 ) else ''
 try :
  iI1i1IiIIIIi = open ( o0oOoO00o , mode = 'r' )
  OooOooO0O0o0 = file . read ( iI1i1IiIIIIi )
  file . close ( iI1i1IiIIIIi )
  OOO0o0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( OooOooO0O0o0 )
  IIIIII111Ii = OOO0o0 [ 0 ] if ( len ( OOO0o0 ) > 0 ) else ''
  Ii1i1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( OooOooO0O0o0 )
  iIi1Ii1IIiI = Ii1i1i [ 0 ] if ( len ( Ii1i1i ) > 0 ) else ''
  ooo00Oo00O0 = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( OooOooO0O0o0 )
  OOOOOOoo0oO = ooo00Oo00O0 [ 0 ] if ( len ( ooo00Oo00O0 ) > 0 ) else ''
  IiIiIIiii1I = O0O0o0o0o . replace ( iiiIIiiii11 , IIIIII111Ii ) . replace ( III1II1i , OOOOOOoo0oO ) . replace ( IiIIiI , iIi1Ii1IIiI )
  iIi11i = open ( O0OoO000O0OO , mode = 'w+' )
  iIi11i . write ( str ( IiIiIIiii1I ) )
  iIi11i . close ( )
 except :
  print "NO GUISETTINGS DOWNLOADED"
 if os . path . exists ( Oo0oO0ooo ) :
  os . remove ( Oo0oO0ooo )
 os . rename ( O0OoO000O0OO , Oo0oO0ooo )
 try :
  os . remove ( o0oOoO00o )
 except :
  pass
 if i111iii1I1 == 1 :
  extract . all ( i11I1I1iiI , O0oo0OO0 , IiI )
  if OO0o0o0oo != 1 :
   shutil . rmtree ( II )
   if 9 - 9: iiiIi1i1I
 IiI . close ( )
 os . makedirs ( iiI1IiI )
 time . sleep ( 1 )
 xbmc . executebuiltin ( 'UnloadSkin()' )
 time . sleep ( 1 )
 xbmc . executebuiltin ( 'ReloadSkin()' )
 time . sleep ( 1 )
 xbmc . executebuiltin ( "ActivateWindow(appearancesettings)" )
 while xbmc . executebuiltin ( "Window.IsActive(appearancesettings)" ) :
  xbmc . sleep ( 500 )
 try : xbmc . executebuiltin ( "LoadProfile(Master user)" )
 except : pass
 Oo0O . ok ( 'Step 1 complete' , 'Change the skin to: [COLOR=lime]' + skins , '[/COLOR]Once done come back and choose install step 2 which will' , 're-install the guisettings.xml - this file contains all custom skin settings.' )
 xbmc . executebuiltin ( "ActivateWindow(appearancesettings)" )
 O0II11i11II ( guisettingslink )
 if 30 - 30: OoOo * ii1I11II1ii1i % IIIIII11i1I % oO0o0ooo * Oo000o
 if 17 - 17: II11iII + IIII % OOO00OoOO00
 if 36 - 36: i11iIiiIii + iii11I111 % OOO00OoOO00 . oO0o0ooo - i1OOO
def OooOo0o0OO ( ) :
 iiI1ii1IIiI = 0
 OO0o0o0oo = 0
 iIiI ( 'totalxbmc.xml' )
 oo00o ( )
 Ii1Ii1IiIIIi1 = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to restore' , 'files' , '.zip' , False , False , oO0o0o0ooO0oO )
 if Ii1Ii1IiIIIi1 == '' :
  return
 if os . path . exists ( O0OoO000O0OO ) :
  if os . path . exists ( Oo0oO0ooo ) :
   os . remove ( O0OoO000O0OO )
  else :
   os . rename ( O0OoO000O0OO , Oo0oO0ooo )
 if os . path . exists ( o0oOoO00o ) :
  os . remove ( o0oOoO00o )
 if not os . path . exists ( oooOOOOO ) :
  OooOOOo0 = open ( oooOOOOO , mode = 'w+' )
 if os . path . exists ( iiI1IiI ) :
  os . removedirs ( iiI1IiI )
 try : os . rename ( Oo0oO0ooo , O0OoO000O0OO )
 except :
  Oo0O . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit XBMC and try again' , '' )
  return
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( I1II1 , 'We highly recommend backing up your existing build before' , 'installing any builds.' , 'Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
 if II1Ii1iI1i1 == 0 :
  iIiII1 = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Community Builds' , 'My Builds' ) )
  if not os . path . exists ( iIiII1 ) :
   os . makedirs ( iIiII1 )
  oOooOo00OooO0oO = I1IIi ( heading = "Enter a name for this backup" )
  if ( not oOooOo00OooO0oO ) : return False , 0
  O0OOOo = urllib . quote_plus ( oOooOo00OooO0oO )
  i11I1I1iiI = xbmc . translatePath ( os . path . join ( iIiII1 , O0OOOo + '.zip' ) )
  I1i1iii1Ii = [ 'plugin.program.TBS' ]
  iI = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' ]
  iii1 = "Creating full backup of existing build"
  II1iIi1IiIii = "Archiving..."
  I111I11I111 = ""
  iiiiI11ii = "Please Wait"
  iI1iIIIi1i ( ooOo , i11I1I1iiI , iii1 , II1iIi1IiIii , I111I11I111 , iiiiI11ii , I1i1iii1Ii , iI )
 i111iii1I1 = xbmcgui . Dialog ( ) . yesno ( I1II1 , 'Would you like to keep your existing database' , 'files or overwrite? Overwriting will wipe any' , 'existing music or video library you may have scanned in.' , nolabel = 'Overwrite' , yeslabel = 'Keep Existing' )
 if i111iii1I1 == 0 : pass
 elif i111iii1I1 == 1 :
  if os . path . exists ( II ) :
   shutil . rmtree ( II )
  try :
   shutil . copytree ( O0oo0OO0 , II , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
  except :
   OO0o0o0oo = xbmcgui . Dialog ( ) . yesno ( I1II1 , 'There was an error trying to backup some databases.' , 'Continuing may wipe your existing library. Do you' , 'wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if OO0o0o0oo == 1 : pass
   if OO0o0o0oo == 0 : iiI1ii1IIiI = 1 ; return
  i11I1I1iiI = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Database.zip' ) )
  oOOo000oOoO0 ( II , i11I1I1iiI )
 if iiI1ii1IIiI == 1 :
  return
 else :
  time . sleep ( 1 )
  i1IiiiiIi1I = open ( o0oO0 , mode = 'r' )
  ooo0O0o0OoOO = i1IiiiiIi1I . read ( )
  i1IiiiiIi1I . close ( )
  ii1i ( Ii1Ii1IiIIIi1 )
  IiI . create ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "Checking " , '' , 'Please Wait' )
  IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( Ii1Ii1IiIIIi1 , ooOo , IiI )
  time . sleep ( 1 )
  OOoo00 = ntpath . basename ( Ii1Ii1IiIIIi1 )
  iIi11i = open ( i1iiIII111ii , mode = 'w+' )
  iIi11i . write ( 'id="none"\nname="' + OOoo00 + ' [COLOR=yellow](Partially installed)[/COLOR]"\nversion="none"' )
  iIi11i . close ( )
  ii111iI = open ( o0oO0 , mode = 'w+' )
  ii111iI . write ( ooo0O0o0OoOO )
  ii111iI . close ( )
  try :
   os . rename ( Oo0oO0ooo , o0oOoO00o )
  except :
   print "NO GUISETTINGS DOWNLOADED"
  time . sleep ( 1 )
  OooOOOo0 = open ( O0OoO000O0OO , mode = 'r' )
  O0O0o0o0o = file . read ( OooOOOo0 )
  file . close ( OooOOOo0 )
  Ii1IIIII = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( O0O0o0o0o )
  iiiIIiiii11 = Ii1IIIII [ 0 ] if ( len ( Ii1IIIII ) > 0 ) else ''
  IIiI1iIIiI1I1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( O0O0o0o0o )
  IiIIiI = IIiI1iIIiI1I1i [ 0 ] if ( len ( IIiI1iIIiI1I1i ) > 0 ) else ''
  oOo0Oo0O0O = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( O0O0o0o0o )
  III1II1i = oOo0Oo0O0O [ 0 ] if ( len ( oOo0Oo0O0O ) > 0 ) else ''
  try :
   iI1i1IiIIIIi = open ( o0oOoO00o , mode = 'r' )
   OooOooO0O0o0 = file . read ( iI1i1IiIIIIi )
   file . close ( iI1i1IiIIIIi )
   OOO0o0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( OooOooO0O0o0 )
   IIIIII111Ii = OOO0o0 [ 0 ] if ( len ( OOO0o0 ) > 0 ) else ''
   Ii1i1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( OooOooO0O0o0 )
   iIi1Ii1IIiI = Ii1i1i [ 0 ] if ( len ( Ii1i1i ) > 0 ) else ''
   ooo00Oo00O0 = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( OooOooO0O0o0 )
   OOOOOOoo0oO = ooo00Oo00O0 [ 0 ] if ( len ( ooo00Oo00O0 ) > 0 ) else ''
   IiIiIIiii1I = O0O0o0o0o . replace ( iiiIIiiii11 , IIIIII111Ii ) . replace ( III1II1i , OOOOOOoo0oO ) . replace ( IiIIiI , iIi1Ii1IIiI )
   iIi11i = open ( O0OoO000O0OO , mode = 'w+' )
   iIi11i . write ( str ( IiIiIIiii1I ) )
   iIi11i . close ( )
  except :
   print "NO GUISETTINGS DOWNLOADED"
  if os . path . exists ( Oo0oO0ooo ) :
   os . remove ( Oo0oO0ooo )
  os . rename ( O0OoO000O0OO , Oo0oO0ooo )
  try :
   os . remove ( o0oOoO00o )
  except :
   pass
  if i111iii1I1 == 1 :
   extract . all ( i11I1I1iiI , O0oo0OO0 , IiI )
   if OO0o0o0oo != 1 :
    shutil . rmtree ( II )
  os . makedirs ( iiI1IiI )
  time . sleep ( 1 )
  xbmc . executebuiltin ( 'UnloadSkin()' )
  time . sleep ( 1 )
  xbmc . executebuiltin ( 'ReloadSkin()' )
  time . sleep ( 1 )
  xbmc . executebuiltin ( "ActivateWindow(appearancesettings)" )
  while xbmc . executebuiltin ( "Window.IsActive(appearancesettings)" ) :
   xbmc . sleep ( 500 )
  try : xbmc . executebuiltin ( "LoadProfile(Master user)" )
  except : pass
  Oo0O . ok ( '[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]' , 'Step 1 complete. Now please change the skin to' , 'the one this build was designed for. Once done come back' , 'to this addon and restore the guisettings_fix.zip' )
  xbmc . executebuiltin ( "ActivateWindow(appearancesettings)" )
  if 35 - 35: iii11I111 * OoO0O00 . ooOO0o . ooOO0o - Ooo0Oo0 % II11iII
  if 42 - 42: OoOo - o0o0OOO0o0 % IIII
def iII1ii ( ) :
 import time
 oo00o ( )
 iII11IiI1 = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the guisettings zip file you want to restore' , 'files' , '.zip' , False , False , oO0o0o0ooO0oO )
 if iII11IiI1 == '' :
  return
 else :
  i1iiiIi1Iii = 1
  iiiO0 ( iII11IiI1 , i1iiiIi1Iii )
  if 86 - 86: o0o0OOO0o0 % Ooo0Oo0 - II11iII + O0oO % iiiIi1i1I . iii11I111
  if 4 - 4: o0O0 + II11iII
def ii11I11 ( ) :
 if IiIi11iIIi1Ii == 'true' :
  OOOoO ( )
 Ii ( '' , '[COLOR=lime]RESTORE LOCAL BUILD[/COLOR]' , 'url' , 'restore_local_CB' , 'Restore.png' , '' , '' , 'Back Up Your Full System' )
 Ii ( '' , '[COLOR=dodgerblue]Restore Local guisettings file[/COLOR]' , 'url' , 'LocalGUIDialog' , 'Restore.png' , '' , '' , 'Back Up Your Full System' )
 if 75 - 75: iiIi
 if os . path . exists ( os . path . join ( oO0o0o0ooO0oO , 'addons.zip' ) ) :
  Ii ( '' , 'Restore Your Addons' , 'addons' , 'restore_zip' , 'Restore.png' , '' , '' , 'Restore Your Addons' )
  if 23 - 23: ii1I11II1ii1i * OoO0O00
 if os . path . exists ( os . path . join ( oO0o0o0ooO0oO , 'addon_data.zip' ) ) :
  Ii ( '' , 'Restore Your Addon UserData' , 'addon_data' , 'restore_zip' , 'Restore.png' , '' , '' , 'Restore Your Addon UserData' )
  if 80 - 80: O0oO / i11iIiiIii + IIII
 if os . path . exists ( os . path . join ( oO0o0o0ooO0oO , 'guisettings.xml' ) ) :
  Ii ( '' , 'Restore Guisettings.xml' , Oo0oO0ooo , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your guisettings.xml' )
  if 38 - 38: iii11I111 % i1OOO + o0O0 * IIII * Ooo0Oo0
 if os . path . exists ( os . path . join ( oO0o0o0ooO0oO , 'favourites.xml' ) ) :
  Ii ( '' , 'Restore Favourites.xml' , oOOoo00O0O , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your favourites.xml' )
  if 83 - 83: o0o0OOO0o0 - i1OOO - O0oO / iiiIi1i1I - IIIIII11i1I
 if os . path . exists ( os . path . join ( oO0o0o0ooO0oO , 'sources.xml' ) ) :
  Ii ( '' , 'Restore Source.xml' , i1111 , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your sources.xml' )
  if 81 - 81: Oo000o - Ooo0Oo0 * iii11I111 / O0oO
 if os . path . exists ( os . path . join ( oO0o0o0ooO0oO , 'advancedsettings.xml' ) ) :
  Ii ( '' , 'Restore Advancedsettings.xml' , i11 , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your advancedsettings.xml' )
  if 21 - 21: iiiIi1i1I
 if os . path . exists ( os . path . join ( oO0o0o0ooO0oO , 'keyboard.xml' ) ) :
  Ii ( '' , 'Restore Advancedsettings.xml' , oOo0oooo00o , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your keyboard.xml' )
  if 63 - 63: oOOoO0O0O0 . IIIIII11i1I * oOOoO0O0O0 + o0o0OOO0o0
 if os . path . exists ( os . path . join ( oO0o0o0ooO0oO , 'RssFeeds.xml' ) ) :
  Ii ( '' , 'Restore RssFeeds.xml' , Oo0o0000o0o0 , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your RssFeeds.xml' )
  if 46 - 46: o0O0 + ii1I11II1ii1i * o0O0 - Oo000o
  if 79 - 79: ii1I11II1ii1i - Ooo0Oo0 * iii11I111 - II11iII . iii11I111
def iiII1IIii1i1 ( url ) :
 oo00o ( )
 if 'addons' in url :
  i1iiiIIi11II = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'addons.zip' ) )
  o0oooOo0oo = iiIIIII1i1iI
  i1iI1IIi1I = iiIIIII1i1iI
  i11I1I1iiI = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'addons.zip' ) )
 else :
  i1iiiIIi11II = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'addon_data.zip' ) )
  o0oooOo0oo = iI1Ii11111iIi
 if 'Backup' in I1II1 :
  iii11II1I ( )
  IiI . create ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "Backing Up" , '' , 'Please Wait' )
  oooOooooO0oOO = zipfile . ZipFile ( i1iiiIIi11II , 'w' , zipfile . ZIP_DEFLATED )
  Iiiiii1iI = len ( o0oooOo0oo )
  IIi = [ ]
  ooOooo0 = [ ]
  for oO0OO0 , o0O0Oo00 , O0Oo0o000oO in os . walk ( o0oooOo0oo ) :
   for file in O0Oo0o000oO :
    ooOooo0 . append ( file )
  oO0o00oOOooO0 = len ( ooOooo0 )
  for oO0OO0 , o0O0Oo00 , O0Oo0o000oO in os . walk ( o0oooOo0oo ) :
   for file in O0Oo0o000oO :
    IIi . append ( file )
    IiIi1ii111i1 = len ( IIi ) / float ( oO0o00oOOooO0 ) * 100
    IiI . update ( int ( IiIi1ii111i1 ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
    i1i1i1I = os . path . join ( oO0OO0 , file )
    if not 'temp' in o0O0Oo00 :
     if not 'plugin.program.TBS' in o0O0Oo00 :
      import time
      oOoo000 = '01/01/1980'
      OooOo00o = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( i1i1i1I ) ) )
      if OooOo00o > oOoo000 :
       oooOooooO0oOO . write ( i1i1i1I , i1i1i1I [ Iiiiii1iI : ] )
  oooOooooO0oOO . close ( )
  IiI . close ( )
  Oo0O . ok ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "You Are Now Backed Up" , '' , '' )
 else :
  IiI . create ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "Checking " , '' , 'Please Wait' )
  IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( i1iiiIIi11II , o0oooOo0oo , IiI )
  time . sleep ( 1 )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  if 'Backup' in I1II1 :
   ooOoOOoooO000 ( )
   Oo0O . ok ( "Community Builds - Install Complete" , 'To ensure the skin settings are set correctly XBMC will now' , 'close. If XBMC doesn\'t close please force close (pull power' , 'or force close in your OS - [COLOR=lime]DO NOT exit via XBMC menu[/COLOR])' )
  else :
   Oo0O . ok ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "You Are Now Restored" , '' , '' )
   if 52 - 52: IIII / ooOO0o % ii1I11II1ii1i
def Ii11I1I11II ( url ) :
 IIiiiI = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
 oO0Oooo0OoO = ooO000OO ( IIiiiI , 'speedtestfiles' )
 Iii = os . path . join ( oO0Oooo0OoO , I1I11ii ( ) + '.speedtest' )
 i1IIIIiiI11 = iIIiI1iiI ( url , Iii )
 os . remove ( Iii )
 I1iii1I = ( ( O0o0Oo / i1IIIIiiI11 ) * 8 / ( 1024 * 1024 ) )
 oooII111 = ( OO0oOoo * 8 / ( 1024 * 1024 ) )
 if I1iii1I < 2 :
  I11iIi = 'Very low quality streams may work'
  Ii1IIiII1I = 'Expect buffering, do not try HD'
 elif I1iii1I < 2.5 :
  I11iIi = 'You should be ok for SD content only'
  Ii1IIiII1I = 'SD/DVD quality should be ok, do not try HD'
 elif I1iii1I < 5 :
  I11iIi = 'Some HD streams may struggle, SD will be fine'
  Ii1IIiII1I = 'Most will be fine, some Blurays may struggle'
 elif I1iii1I < 10 :
  I11iIi = 'All streams including HD should stream fine'
  Ii1IIiII1I = 'Most will be fine, some Blurays may struggle'
 else :
  I11iIi = 'All streams including HD should stream fine'
  Ii1IIiII1I = 'You can play all files with no problems'
 print "Average Speed: " + str ( I1iii1I )
 print "Max. Speed: " + str ( oooII111 )
 Oo0O = xbmcgui . Dialog ( )
 OOO00O = Oo0O . ok ( 'Speed Test - Results' ,
 '[COLOR blue]Average Speed:[/COLOR] %.02f Mb/s ' % I1iii1I ,
 '[COLOR blue]Live Streams:[/COLOR] ' + I11iIi ,
 '[COLOR blue]Online Video:[/COLOR] ' + Ii1IIiII1I ,
 )
 if 85 - 85: iiIi . i11iIiiIii - i11iIiiIii . oO0o0ooo . iiiIi1i1I % IIII
 if 20 - 20: O0oO + O0oO * ii1I11II1ii1i * o0o0OOO0o0 % IIIIII11i1I * oO0o0ooo
def OooOo ( url ) :
 oOooOo00OooO0oO = I1IIi ( heading = "Search for add-ons" )
 if 87 - 87: i1OOO * iiiIi1i1I + OoOo . OOO00OoOO00 - i1OOO
 if ( not oOooOo00OooO0oO ) : return False , 0
 if 33 - 33: ii1I11II1ii1i / IIIIII11i1I / ooOO0o - oOOoO0O0O0 - o0O0
 O0OOOo = urllib . quote_plus ( oOooOo00OooO0oO )
 url += O0OOOo
 I1ii1 ( url )
 if 8 - 8: i11iIiiIii . OoO0O00 / o0o0OOO0o0 / iii11I111 / ooOO0o - Oo000o
 if 32 - 32: OoOo . o0O0 * iiIi
def O0oooo0O ( url ) :
 oOooOo00OooO0oO = I1IIi ( heading = "Search for content" )
 if 15 - 15: o0O0 % IIII * OOO00OoOO00 . ii1I11II1ii1i + IIIIII11i1I * iiiIi1i1I
 if ( not oOooOo00OooO0oO ) : return False , 0
 if 16 - 16: IIIIII11i1I - IIIIII11i1I / oOOoO0O0O0 - iiiIi1i1I
 O0OOOo = urllib . quote_plus ( oOooOo00OooO0oO )
 url += O0OOOo
 iii ( url )
 if 30 - 30: OoOo - iiiIi1i1I + OOO00OoOO00
 if 65 - 65: IIIIII11i1I / ii1I11II1ii1i . o0o0OOO0o0 . Ooo0Oo0 / iiIi % o0o0OOO0o0
def Oo0Oo ( url ) :
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/Community_Builds/community_builds.php?id=%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iIi = re . compile ( 'name="(.+?)"' ) . findall ( IIiIi1iI )
 oOOII1i11i1iIi11 = re . compile ( 'author="(.+?)"' ) . findall ( IIiIi1iI )
 i1II1Iiii1I11 = re . compile ( 'version="(.+?)"' ) . findall ( IIiIi1iI )
 if 60 - 60: OoOo . II11iII % O0oO / oO0o0ooo / IIIIII11i1I
 I1II1 = i1iIi [ 0 ] if ( len ( i1iIi ) > 0 ) else ''
 IIi1iI1 = oOOII1i11i1iIi11 [ 0 ] if ( len ( oOOII1i11i1iIi11 ) > 0 ) else ''
 i1i1iI1iiiI = i1II1Iiii1I11 [ 0 ] if ( len ( i1II1Iiii1I11 ) > 0 ) else ''
 if 19 - 19: i11iIiiIii . oO0o0ooo + ii1I11II1ii1i / OOO00OoOO00 . iii11I111 * i1OOO
 Oo0O . ok ( I1II1 , 'Author: ' + IIi1iI1 , 'Latest Version: ' + i1i1iI1iiiI , '' )
 return
 if 59 - 59: o0o0OOO0o0 / iii11I111 % i1OOO
 if 84 - 84: o0o0OOO0o0 / oO0o0ooo . II11iII % oOOoO0O0O0
def oOoO000 ( ) :
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/login/login_details.php?user=%s&pass=%s' % ( oO00oOo , OOOo0 )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 Oo00o00Oo = re . compile ( 'posts="(.+?)"' ) . findall ( IIiIi1iI )
 i1I1i1I111 = re . compile ( 'messages="(.+?)"' ) . findall ( IIiIi1iI )
 oOo00OO0ooOOO = re . compile ( 'unread="(.+?)"' ) . findall ( IIiIi1iI )
 i1i1I1Ii1IIii = re . compile ( 'email="(.+?)"' ) . findall ( IIiIi1iI )
 oooOOoo = i1I1i1I111 [ 0 ] if ( len ( i1I1i1I111 ) > 0 ) else ''
 iI1iii1iIiiI = oOo00OO0ooOOO [ 0 ] if ( len ( oOo00OO0ooOOO ) > 0 ) else ''
 II1iiiiI1 = i1i1I1Ii1IIii [ 0 ] if ( len ( i1i1I1Ii1IIii ) > 0 ) else ''
 IiiIiiIIII = Oo00o00Oo [ 0 ] if ( len ( Oo00o00Oo ) > 0 ) else ''
 Oo0O . ok ( 'TotalXBMC Details for ' + oO00oOo , 'Email: ' + II1iiiiI1 , 'Unread Messages: ' + iI1iii1iIiiI + '/' + oooOOoo , 'Posts: ' + IiiIiiIIII )
 if 88 - 88: iiiIi1i1I . O0oO / oOOoO0O0O0
 if 47 - 47: iiiIi1i1I + iii11I111 . i1OOO
def o0IIIIiI11I ( url , type ) :
 if type == 'communitybuilds' :
  IiiIiIIi1 = 'grab_builds'
  if url . endswith ( "visibility=premium" ) :
   Ii ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&reseller=' + urllib . quote ( I1IiiI ) + '&token=' + IIi1IiiiI1Ii + '&visibility=premium' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
  if url . endswith ( "visibility=reseller_private" ) :
   Ii ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&reseller=' + urllib . quote ( I1IiiI ) + '&token=' + IIi1IiiiI1Ii + '&visibility=reseller_private' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
  if url . endswith ( "visibility=public" ) :
   Ii ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=public' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
  if url . endswith ( "visibility=private" ) :
   Ii ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=private' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
 if type == 'tutorials' :
  IiiIiIIi1 = 'grab_tutorials'
 if type == 'hardware' :
  IiiIiIIi1 = 'grab_hardware'
 if type == 'addons' :
  IiiIiIIi1 = 'grab_addons'
  Ii ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloads&orderx=DESC' , IiiIiIIi1 , 'Popular.png' , '' , '' , '' )
 if type == 'hardware' :
  Ii ( 'folder' , '[COLOR=lime]Filter Results[/COLOR]' , url , 'hardware_filter_menu' , 'Filter.png' , '' , '' , '' )
 if type != 'addons' :
  Ii ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloadcount&orderx=DESC' , IiiIiIIi1 , 'Popular.png' , '' , '' , '' )
 if type == 'tutorials' or type == 'hardware' :
  Ii ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=Added&orderx=DESC' , IiiIiIIi1 , 'Latest.png' , '' , '' , '' )
 else :
  Ii ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=created&orderx=DESC' , IiiIiIIi1 , 'Latest.png' , '' , '' , '' )
  Ii ( 'folder' , '[COLOR=dodgerblue]Sort by Recently Updated[/COLOR]' , str ( url ) + '&sortx=updated&orderx=DESC' , IiiIiIIi1 , 'Recently_Updated.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Sort by A-Z[/COLOR]' , str ( url ) + '&sortx=name&orderx=ASC' , IiiIiIIi1 , 'AtoZ.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Sort by Z-A[/COLOR]' , str ( url ) + '&sortx=name&orderx=DESC' , IiiIiIIi1 , 'ZtoA.png' , '' , '' , '' )
 if type == 'public_CB' :
  Ii ( 'folder' , '[COLOR=dodgerblue]Sort by Genre[/COLOR]' , url , 'genres' , 'Search_Genre.png' , '' , '' , '' )
  Ii ( 'folder' , '[COLOR=dodgerblue]Sort by Country/Language[/COLOR]' , url , 'countries' , 'Search_Country.png' , '' , '' , '' )
  if 40 - 40: OoO0O00 . II11iII * IIIIII11i1I
  if 6 - 6: oO0o0ooo - ii1I11II1ii1i . oO0o0ooo + oOOoO0O0O0 . OOO00OoOO00
def oo0O ( ) :
 Oo0000o0O0O ( 'Speed Test Instructions' , '[COLOR=blue][B]What file should I use: [/B][/COLOR][CR]This function will download a file and will work out your speed based on how long it took to download. You will then be notified of '
 'what quality streams you can expect to stream without buffering. You can choose to download a 10MB, 16MB, 32MB, 64MB or 128MB file to use with the test. Using the larger files will give you a better '
 'indication of how reliable your speeds are but obviously if you have a limited amount of bandwidth allowance you may want to opt for a smaller file.'
 '[CR][CR][COLOR=blue][B]How accurate is this speed test:[/B][/COLOR][CR]Not very accurate at all! As this test is based on downloading a file from a server it\'s reliant on the server not having a go-slow day '
 'but the servers used should be pretty reliable. The 10MB file is hosted on a different server to the others so if you\'re not getting the results expected please try another file. If you have a fast fiber '
 'connection the chances are your speed will show as considerably slower than your real download speed due to the server not being able to send the file as fast as your download speed allows. Essentially the '
 'test results will be limited by the speed of the server but you will at least be able to see if it\'s your connection that\'s causing buffering or if it\'s the host you\'re trying to stream from'
 '[CR][CR][COLOR=blue][B]What is the differnce between Live Streams and Online Video:[/COLOR][/B][CR]When you run the test you\'ll see results based on your speeds and these let you know the quality you should expect to '
 'be able stream with your connection. Live Streams as the title suggests are like traditional TV channels, they are being streamed live so for example if you wanted to watch CNN this would fall into this category. '
 'Online Videos relates to movies, tv shows, youtube clips etc. Basically anything that isn\'t live - if you\'re new to the world of streaming then think of it as On Demand content, this is content that\'s been recorded and stored on the web.'
 '[CR][CR][COLOR=blue][B]Why am I still getting buffering:[/COLOR][/B][CR]The results you get from this test are strictly based on your download speed, there are many other factors that can cause buffering and contrary to popular belief '
 'having a massively fast internet connection will not make any difference to your buffering issues if the server you\'re trying to get the content from is unable to send it fast enough. This can often happen and is usually '
 'down to heavy traffic (too many users accessing the same server). A 10 Mb/s connection should be plenty fast enough for almost all content as it\'s very rare a server can send it any quicker than that.'
 '[CR][CR][COLOR=blue][B]What\'s the difference between MB/s and Mb/s:[/COLOR][/B][CR]A lot of people think the speed they see advertised by their ISP is Megabytes (MB/S) per second - this is not true. Speeds are usually shown as Mb/s '
 'which is Megabit per second - there are 8 of these to a megabyte so if you want to work out how many megabytes per second you\'re getting you need to divide the speed by 8. It may sound sneaky but really it\'s just the unit that has always been used.'
 '[CR][CR]Visit the forum at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B] for more information. A direct link to the buffering thread explaining what you can do to improve your viewing experience can be found at [COLOR=yellow]http://bit.ly/bufferingfix[/COLOR]'
 '[CR][CR]Hope to see you on the forum soon - [COLOR=dodgerblue]whufclee[/COLOR]' )
 if 23 - 23: oO0o0ooo * i1OOO / II11iII . o0o0OOO0o0 % i11iIiiIii
def ooOoo ( ) :
 Ii ( '' , '[COLOR=blue]Instructions - Read me first[/COLOR]' , 'none' , 'speed_instructions' , 'howto.png' , '' , '' , '' )
 Ii ( '' , 'Download 16MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/16MB.txt' , 'runtest' , 'Download16.png' , '' , '' , '' )
 Ii ( '' , 'Download 32MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/32MB.txt' , 'runtest' , 'Download32.png' , '' , '' , '' )
 Ii ( '' , 'Download 64MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/64MB.txt' , 'runtest' , 'Download64.png' , '' , '' , '' )
 Ii ( '' , 'Download 128MB file - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/128MB.txt' , 'runtest' , 'Download128.png' , '' , '' , '' )
 Ii ( '' , 'Download 10MB file   - [COLOR=yellow]Server 2[/COLOR]' , 'http://www.wswd.net/testdownloadfiles/10MB.zip' , 'runtest' , 'Download10.png' , '' , '' , '' )
 if 41 - 41: OoO0O00 % OoO0O00 - ooOO0o % iiiIi1i1I - IIII - OoO0O00
 if 66 - 66: OoOo % II11iII
def II1I1iIIiIIii ( name , url ) :
 Oo0000o0O0O ( name , url )
 if 65 - 65: i11iIiiIii - i1OOO * oOOoO0O0O0 + i1OOO / ooOO0o + OoOo
 if 35 - 35: IIIIII11i1I + iiIi - oO0o0ooo % Oo000o % ii1I11II1ii1i
def o0OOOO ( ) :
 Ii ( 'folder' , '[COLOR=yellow]Add-on Maintenance/Fixes[/COLOR]' , 'none' , 'addonfixes' , 'Addon_Fixes.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue]Backup/Restore My Content[/COLOR]' , 'none' , 'backup_restore' , 'Backup.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange]Clean/Wipe Options[/COLOR]' , 'none' , 'wipetools' , 'Addon_Fixes.png' , '' , '' , '' )
 Ii ( '' , 'Check My IP Address' , 'none' , 'ipcheck' , 'Check_IP.png' , '' , '' , '' )
 Ii ( '' , 'Check XBMC/Kodi Version' , 'none' , 'xbmcversion' , 'Version_Check.png' , '' , '' , '' )
 Ii ( '' , 'Convert Physical Paths To Special' , ooOo , 'fix_special' , 'Special_Paths.png' , '' , '' , '' )
 Ii ( '' , 'Force Close Kodi' , 'url' , 'kill_xbmc' , 'Kill_XBMC.png' , '' , '' , '' )
 Ii ( 'folder' , 'Test My Download Speed' , 'none' , 'speedtest_menu' , 'Speed_Test.png' , '' , '' , '' )
 Ii ( '' , 'Upload Log' , 'none' , 'uploadlog' , 'Log_File.png' , '' , '' , '' )
 Ii ( '' , 'View My Log' , 'none' , 'log' , 'View_Log.png' , '' , '' , '' )
 if 58 - 58: OoOo % oO0o0ooo . oO0o0ooo * iiiIi1i1I - ooOO0o . IIII
 if 10 - 10: O0oO
def I11i1i11IiIi1 ( url ) :
 Ii ( 'folder' , '[COLOR=yellow]1. Add-on Maintenance[/COLOR]' , str ( url ) + '&type=Maintenance' , 'grab_tutorials' , 'Maintenance.png' , '' , '' , '' )
 Ii ( 'folder' , 'Audio Add-ons' , str ( url ) + '&type=Audio' , 'grab_tutorials' , 'Audio.png' , '' , '' , '' )
 Ii ( 'folder' , 'Picture Add-ons' , str ( url ) + '&type=Pictures' , 'grab_tutorials' , 'Pictures.png' , '' , '' , '' )
 Ii ( 'folder' , 'Program Add-ons' , str ( url ) + '&type=Programs' , 'grab_tutorials' , 'Programs.png' , '' , '' , '' )
 Ii ( 'folder' , 'Video Add-ons' , str ( url ) + '&type=Video' , 'grab_tutorials' , 'Video.png' , '' , '' , '' )
 if 8 - 8: OoO0O00 - oO0o0ooo * iiIi % iii11I111 * IIII
 if 26 - 26: o0O0 / OoO0O00 . OoO0O00
def I1i11IIIi ( url ) :
 oO0oo = 'http://totalxbmc.com/totalrevolution/TutorialPortal/downloadcount.php?id=%s' % ( url )
 i1IiiiI1iI ( oO0oo )
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/TutorialPortal/tutorialdetails.php?id=%s' % ( url )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iIi = re . compile ( 'name="(.+?)"' ) . findall ( IIiIi1iI )
 oOOII1i11i1iIi11 = re . compile ( 'author="(.+?)"' ) . findall ( IIiIi1iI )
 o0Ooo0O00 = re . compile ( 'video_guide1="(.+?)"' ) . findall ( IIiIi1iI )
 ii1o0oooO = re . compile ( 'video_guide2="(.+?)"' ) . findall ( IIiIi1iI )
 ooOoo0oO0OoO0 = re . compile ( 'video_guide3="(.+?)"' ) . findall ( IIiIi1iI )
 oOOOOOoOO = re . compile ( 'video_guide4="(.+?)"' ) . findall ( IIiIi1iI )
 oooo00 = re . compile ( 'video_guide5="(.+?)"' ) . findall ( IIiIi1iI )
 i1oO = re . compile ( 'video_label1="(.+?)"' ) . findall ( IIiIi1iI )
 iIIi1IIi = re . compile ( 'video_label2="(.+?)"' ) . findall ( IIiIi1iI )
 i111i11I1ii = re . compile ( 'video_label3="(.+?)"' ) . findall ( IIiIi1iI )
 OOooo = re . compile ( 'video_label4="(.+?)"' ) . findall ( IIiIi1iI )
 oo0 = re . compile ( 'video_label5="(.+?)"' ) . findall ( IIiIi1iI )
 III1IIIIIiiI = re . compile ( 'about="(.+?)"' ) . findall ( IIiIi1iI )
 i1iIii = re . compile ( 'step1="(.+?)"' ) . findall ( IIiIi1iI )
 O0o00 = re . compile ( 'step2="(.+?)"' ) . findall ( IIiIi1iI )
 I1IIi1iI1iiI = re . compile ( 'step3="(.+?)"' ) . findall ( IIiIi1iI )
 iiI11I1ii11 = re . compile ( 'step4="(.+?)"' ) . findall ( IIiIi1iI )
 O0OoO0oooOO = re . compile ( 'step5="(.+?)"' ) . findall ( IIiIi1iI )
 i1ii11I111Ii = re . compile ( 'step6="(.+?)"' ) . findall ( IIiIi1iI )
 OOoO00O = re . compile ( 'step7="(.+?)"' ) . findall ( IIiIi1iI )
 iio00O0o00oo = re . compile ( 'step8="(.+?)"' ) . findall ( IIiIi1iI )
 iIiiII = re . compile ( 'step9="(.+?)"' ) . findall ( IIiIi1iI )
 iII1I = re . compile ( 'step10="(.+?)"' ) . findall ( IIiIi1iI )
 o00oOOo0Oo = re . compile ( 'step11="(.+?)"' ) . findall ( IIiIi1iI )
 Oooo0o0oO = re . compile ( 'step12="(.+?)"' ) . findall ( IIiIi1iI )
 o0OOoOooO0ooO = re . compile ( 'step13="(.+?)"' ) . findall ( IIiIi1iI )
 IiiiIi = re . compile ( 'step14="(.+?)"' ) . findall ( IIiIi1iI )
 IiI111 = re . compile ( 'step15="(.+?)"' ) . findall ( IIiIi1iI )
 OooOoOO0OO = re . compile ( 'screenshot1="(.+?)"' ) . findall ( IIiIi1iI )
 I1iiIiiii1111 = re . compile ( 'screenshot2="(.+?)"' ) . findall ( IIiIi1iI )
 I1ii1i11i = re . compile ( 'screenshot3="(.+?)"' ) . findall ( IIiIi1iI )
 Oooooo0O00o = re . compile ( 'screenshot4="(.+?)"' ) . findall ( IIiIi1iI )
 II11ii1 = re . compile ( 'screenshot5="(.+?)"' ) . findall ( IIiIi1iI )
 ii1II1II = re . compile ( 'screenshot6="(.+?)"' ) . findall ( IIiIi1iI )
 i11i11II11i = re . compile ( 'screenshot7="(.+?)"' ) . findall ( IIiIi1iI )
 II1Ii1I1i = re . compile ( 'screenshot8="(.+?)"' ) . findall ( IIiIi1iI )
 OOooOooo0OOo0 = re . compile ( 'screenshot9="(.+?)"' ) . findall ( IIiIi1iI )
 oo0o0OoOO0o0 = re . compile ( 'screenshot10="(.+?)"' ) . findall ( IIiIi1iI )
 III1III11II = re . compile ( 'screenshot11="(.+?)"' ) . findall ( IIiIi1iI )
 iIi1iI = re . compile ( 'screenshot12="(.+?)"' ) . findall ( IIiIi1iI )
 OO0Oo = re . compile ( 'screenshot13="(.+?)"' ) . findall ( IIiIi1iI )
 IIiiiiiIiIIi = re . compile ( 'screenshot14="(.+?)"' ) . findall ( IIiIi1iI )
 OO0OO00ooO0 = re . compile ( 'screenshot15="(.+?)"' ) . findall ( IIiIi1iI )
 if 68 - 68: II11iII * iii11I111 - IIII - oOOoO0O0O0 + o0o0OOO0o0 * i11iIiiIii
 I1II1 = i1iIi [ 0 ] if ( len ( i1iIi ) > 0 ) else ''
 IIi1iI1 = oOOII1i11i1iIi11 [ 0 ] if ( len ( oOOII1i11i1iIi11 ) > 0 ) else ''
 oOoO00o = o0Ooo0O00 [ 0 ] if ( len ( o0Ooo0O00 ) > 0 ) else 'None'
 oO00O0 = ii1o0oooO [ 0 ] if ( len ( ii1o0oooO ) > 0 ) else 'None'
 IIi1IIIi = ooOoo0oO0OoO0 [ 0 ] if ( len ( ooOoo0oO0OoO0 ) > 0 ) else 'None'
 O00Ooo = oOOOOOoOO [ 0 ] if ( len ( oOOOOOoOO ) > 0 ) else 'None'
 OOOO0OOO = oooo00 [ 0 ] if ( len ( oooo00 ) > 0 ) else 'None'
 ii1IIII = i1oO [ 0 ] if ( len ( i1oO ) > 0 ) else 'None'
 oO00oOooooo0 = iIIi1IIi [ 0 ] if ( len ( iIIi1IIi ) > 0 ) else 'None'
 oOo = i111i11I1ii [ 0 ] if ( len ( i111i11I1ii ) > 0 ) else 'None'
 O0OOooOoO = OOooo [ 0 ] if ( len ( OOooo ) > 0 ) else 'None'
 i1II1I1Iii1 = oo0 [ 0 ] if ( len ( oo0 ) > 0 ) else 'None'
 iiiii1I1III1 = III1IIIIIiiI [ 0 ] if ( len ( III1IIIIIiiI ) > 0 ) else ''
 OoOiII11IiIi = '[CR][CR][COLOR=dodgerblue]Step 1:[/COLOR][CR]' + i1iIii [ 0 ] if ( len ( i1iIii ) > 0 ) else ''
 iII1I1i = '[CR][CR][COLOR=dodgerblue]Step 2:[/COLOR][CR]' + O0o00 [ 0 ] if ( len ( O0o00 ) > 0 ) else ''
 IIiii = '[CR][CR][COLOR=dodgerblue]Step 3:[/COLOR][CR]' + I1IIi1iI1iiI [ 0 ] if ( len ( I1IIi1iI1iiI ) > 0 ) else ''
 ooOoOooo00Oo = '[CR][CR][COLOR=dodgerblue]Step 4:[/COLOR][CR]' + iiI11I1ii11 [ 0 ] if ( len ( iiI11I1ii11 ) > 0 ) else ''
 ooo00O0OOo = '[CR][CR][COLOR=dodgerblue]Step 5:[/COLOR][CR]' + O0OoO0oooOO [ 0 ] if ( len ( O0OoO0oooOO ) > 0 ) else ''
 IiI1 = '[CR][CR][COLOR=dodgerblue]Step 6:[/COLOR][CR]' + i1ii11I111Ii [ 0 ] if ( len ( i1ii11I111Ii ) > 0 ) else ''
 Iii1IIII1Iii = '[CR][CR][COLOR=dodgerblue]Step 7:[/COLOR][CR]' + OOoO00O [ 0 ] if ( len ( OOoO00O ) > 0 ) else ''
 OOOOOOo0o0O0o = '[CR][CR][COLOR=dodgerblue]Step 8:[/COLOR][CR]' + iio00O0o00oo [ 0 ] if ( len ( iio00O0o00oo ) > 0 ) else ''
 IIIIIIiIIIi1iii1 = '[CR][CR][COLOR=dodgerblue]Step 9:[/COLOR][CR]' + iIiiII [ 0 ] if ( len ( iIiiII ) > 0 ) else ''
 iii11III1I = '[CR][CR][COLOR=dodgerblue]Step 10:[/COLOR][CR]' + iII1I [ 0 ] if ( len ( iII1I ) > 0 ) else ''
 oO0oO0O = '[CR][CR][COLOR=dodgerblue]Step 11:[/COLOR][CR]' + o00oOOo0Oo [ 0 ] if ( len ( o00oOOo0Oo ) > 0 ) else ''
 ooooOO000oooO0 = '[CR][CR][COLOR=dodgerblue]Step 12:[/COLOR][CR]' + Oooo0o0oO [ 0 ] if ( len ( Oooo0o0oO ) > 0 ) else ''
 oOO00 = '[CR][CR][COLOR=dodgerblue]Step 13:[/COLOR][CR]' + o0OOoOooO0ooO [ 0 ] if ( len ( o0OOoOooO0ooO ) > 0 ) else ''
 oO0o00 = '[CR][CR][COLOR=dodgerblue]Step 14:[/COLOR][CR]' + IiiiIi [ 0 ] if ( len ( IiiiIi ) > 0 ) else ''
 Oo0OOOO0oOoo0 = '[CR][CR][COLOR=dodgerblue]Step 15:[/COLOR][CR]' + IiI111 [ 0 ] if ( len ( IiI111 ) > 0 ) else ''
 oOOO0 = OooOoOO0OO [ 0 ] if ( len ( OooOoOO0OO ) > 0 ) else ''
 Iii1i11iiI1 = I1iiIiiii1111 [ 0 ] if ( len ( I1iiIiiii1111 ) > 0 ) else ''
 oOOoOooO0oO0o = I1ii1i11i [ 0 ] if ( len ( I1ii1i11i ) > 0 ) else ''
 o0o0OoO0OOO0 = Oooooo0O00o [ 0 ] if ( len ( Oooooo0O00o ) > 0 ) else ''
 oO0OOOO0o0 = II11ii1 [ 0 ] if ( len ( II11ii1 ) > 0 ) else ''
 oOO0 = ii1II1II [ 0 ] if ( len ( ii1II1II ) > 0 ) else ''
 O00O00OoO = i11i11II11i [ 0 ] if ( len ( i11i11II11i ) > 0 ) else ''
 IiIiI1i1 = II1Ii1I1i [ 0 ] if ( len ( II1Ii1I1i ) > 0 ) else ''
 ii11I1IIi1i = OOooOooo0OOo0 [ 0 ] if ( len ( OOooOooo0OOo0 ) > 0 ) else ''
 iiiiiiiiiiIi = oo0o0OoOO0o0 [ 0 ] if ( len ( oo0o0OoOO0o0 ) > 0 ) else ''
 ooiiI1ii = III1III11II [ 0 ] if ( len ( III1III11II ) > 0 ) else ''
 O0OooOO = iIi1iI [ 0 ] if ( len ( iIi1iI ) > 0 ) else ''
 i1i1 = OO0Oo [ 0 ] if ( len ( OO0Oo ) > 0 ) else ''
 o0oOoOo0 = IIiiiiiIiIIi [ 0 ] if ( len ( IIiiiiiIiIIi ) > 0 ) else ''
 O0O = OO0OO00ooO0 [ 0 ] if ( len ( OO0OO00ooO0 ) > 0 ) else ''
 IIII1 = str ( '[COLOR=gold]Author: [/COLOR]' + IIi1iI1 + '[CR][CR][COLOR=lime]About: [/COLOR]' + iiiii1I1III1 + OoOiII11IiIi + iII1I1i + IIiii + ooOoOooo00Oo + ooo00O0OOo + IiI1 + Iii1IIII1Iii + OOOOOOo0o0O0o + IIIIIIiIIIi1iii1 + iii11III1I + oO0oO0O + ooooOO000oooO0 + oOO00 + oO0o00 + Oo0OOOO0oOoo0 )
 if OoOiII11IiIi != '' :
  Ii ( '' , '[COLOR=yellow][Text Guide][/COLOR]  ' + I1II1 , IIII1 , 'text_guide' , 'How_To.png' , oo00 , iiiii1I1III1 , '' )
 if oOoO00o != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + ii1IIII , oOoO00o , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if oO00O0 != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oO00oOooooo0 , oO00O0 , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if IIi1IIIi != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oOo , IIi1IIIi , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if O00Ooo != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + O0OOooOoO , O00Ooo , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
 if OOOO0OOO != 'None' :
  Ii ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i1II1I1Iii1 , OOOO0OOO , 'play_video' , 'Video_Guide.png' , oo00 , '' , '' )
  if 37 - 37: iiiIi1i1I + iii11I111 - IIIIII11i1I * ii1I11II1ii1i
  if 35 - 35: iii11I111 * iiiIi1i1I * oO0o0ooo / IIII
def I1iIIIiiii ( ) :
 Ii ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'tutorials' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime]All Guides[/COLOR] Everything in one place' , '' , 'grab_tutorials' , 'All.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime]XBMC / Kodi[/COLOR] Specific' , '' , 'xbmc_menu' , 'XBMC.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime]XBMC4Xbox[/COLOR] Specific' , '&platform=XBMC4Xbox' , 'xbmc_menu' , 'XBMC4Xbox.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] Android' , '&platform=Android' , 'platform_menu' , 'Android.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] Apple TV' , '&platform=ATV' , 'platform_menu' , 'ATV.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] ATV2 & iOS' , '&platform=iOS' , 'platform_menu' , 'iOS.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] Linux' , '&platform=Linux' , 'platform_menu' , 'Linux.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] Pure Linux' , '&platform=Custom_Linux' , 'platform_menu' , 'Custom_Linux.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] OpenELEC' , '&platform=OpenELEC' , 'platform_menu' , 'OpenELEC.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSMC' , '&platform=OSMC' , 'platform_menu' , 'OSMC.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSX' , '&platform=OSX' , 'platform_menu' , 'OSX.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] Raspbmc' , '&platform=Raspbmc' , 'platform_menu' , 'Raspbmc.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange][Platform][/COLOR] Windows' , '&platform=Windows' , 'platform_menu' , 'Windows.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Allwinner Devices' , '&hardware=Allwinner' , 'platform_menu' , 'Allwinner.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Amazon Fire TV' , '&hardware=AFTV' , 'platform_menu' , 'AFTV.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] AMLogic Devices' , '&hardware=AMLogic' , 'platform_menu' , 'AMLogic.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Boxee' , '&hardware=Boxee' , 'platform_menu' , 'Boxee.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Intel Devices' , '&hardware=Intel' , 'platform_menu' , 'Intel.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Raspberry Pi' , '&hardware=RaspberryPi' , 'platform_menu' , 'RaspberryPi.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Rockchip Devices' , '&hardware=Rockchip' , 'platform_menu' , 'Rockchip.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Xbox' , '&hardware=Xbox' , 'platform_menu' , 'Xbox_Original.png' , '' , '' , '' )
 if 44 - 44: O0oO / Oo000o * OOO00OoOO00 * o0O0 . Oo000o * i11iIiiIii
def Oo0000o0O0O ( heading , anounce ) :
 class O0o0oo0O ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( heading )
   try : oOOOO = open ( anounce ) ; Ooo00OOo000 = oOOOO . read ( )
   except : Ooo00OOo000 = anounce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( Ooo00OOo000 ) )
   return
 O0o0oo0O ( )
 if 12 - 12: Oo000o . oO0o0ooo % OoOo
 if 28 - 28: Oo000o - oO0o0ooo % iiiIi1i1I * O0oO
def oO0oOooO00oo ( ) :
 Oo0O = xbmcgui . Dialog ( )
 if Oo0O . yesno ( "Make Add-on Passwords Visible?" , "This will make all your add-on passwords visible." , "Are you sure you wish to continue?" ) :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( iiIIIII1i1iI ) :
   for oOOOO in O0Oo0o000oO :
    if oOOOO == 'settings.xml' :
     o000O0oo = open ( os . path . join ( IiI1ii1Ii , oOOOO ) ) . read ( )
     IIII1iII = re . compile ( '<setting id=(.+?)>' ) . findall ( o000O0oo )
     for OOOO in IIII1iII :
      if 'pass' in OOOO :
       if 'option="hidden"' in OOOO :
        try :
         oo00OO0O0Ooo0 = OOOO . replace ( ' option="hidden"' , '' )
         oOOOO = open ( os . path . join ( IiI1ii1Ii , oOOOO ) , mode = 'w' )
         oOOOO . write ( str ( o000O0oo ) . replace ( OOOO , oo00OO0O0Ooo0 ) )
         oOOOO . close ( )
        except :
         pass
  Oo0O . ok ( "Passwords Are now visible" , "Your passwords will now be visible in your add-on settings." , "If you want to undo this please use the option to" , "hide passwords." )
  if 82 - 82: IIII / i1OOO * oOOoO0O0O0 * IIIIII11i1I . iii11I111
  if 21 - 21: ii1I11II1ii1i + iiIi
def OOooooO ( ) :
 if Oo0Ooo . getSetting ( 'email' ) == '' :
  Oo0O = xbmcgui . Dialog ( )
  Oo0O . ok ( "No Email Address Set" , "A new window will Now open for you to enter your" , "Email address. The logfile will be sent here" )
  Oo0Ooo . openSettings ( )
 xbmc . executebuiltin ( 'XBMC.RunScript(special://home/addons/plugin.program.TBS/uploadLog.py)' )
 if 80 - 80: II11iII + o0o0OOO0o0 . ooOO0o
 if 76 - 76: oO0o0ooo * OOO00OoOO00
def ii111 ( localbuildcheck , localversioncheck , localidcheck ) :
 OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/login/login_details.php?user=%s&pass=%s' % ( oO00oOo , OOOo0 )
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIiiI11 = re . compile ( 'login_msg="(.+?)"' ) . findall ( IIiIi1iI )
 IiIII = IIiiI11 [ 0 ] if ( len ( IIiiI11 ) > 0 ) else ''
 Ii1IiI1i1ii ( localbuildcheck , localversioncheck , localidcheck , IiIII )
 if 92 - 92: oO0o0ooo % OoO0O00
def iiiI1IiI ( ) :
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( 'UpdateAddonRepos' )
 xbmcgui . Dialog ( ) . ok ( 'Force Refresh Started Successfully' , 'Depending on the speed of your device it could take a few minutes for the update to take effect.' , '' , '[COLOR=blue]For all your XBMC/Kodi support visit[/COLOR] [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B]' )
 return
 if 2 - 2: IIIIII11i1I % O0oO % iii11I111 % OoOo - iiIi
 if 20 - 20: OoOo
def o0oo00oo0oO ( ) :
 ii1ii = Oo0Ooo . getSetting ( 'startupvideo' )
 if not os . path . exists ( oOOoO0 ) :
  os . makedirs ( oOOoO0 )
 if not os . path . exists ( i1iiIIiiI111 ) :
  OooOOOo0 = open ( i1iiIIiiI111 , mode = 'w+' )
  OooOOOo0 . write ( 'date="01011001"\nversion="0.0"' )
  OooOOOo0 . close ( )
 if not os . path . exists ( i1iiIII111ii ) :
  OooOOOo0 = open ( i1iiIII111ii , mode = 'w+' )
  OooOOOo0 . write ( 'id="None"\nname="None"' )
  OooOOOo0 . close ( )
 if IiIi11iIIi1Ii == 'true' :
  OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/unlocked.txt'
 else :
  OOOo00oo0oO = 'http://totalxbmc.com/totalrevolution/vanilla.txt'
 IIiIi1iI = i1IiiiI1iI ( OOOo00oo0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 Ii1iii11I = re . compile ( 'date="(.+?)"' ) . findall ( IIiIi1iI )
 Ii11iIiiI = re . compile ( 'video="https://www.youtube.com/watch\?v=(.+?)"' ) . findall ( IIiIi1iI )
 IIII1ii1 = Ii1iii11I [ 0 ] if ( len ( Ii1iii11I ) > 0 ) else ''
 iiII = Ii11iIiiI [ 0 ] if ( len ( Ii11iIiiI ) > 0 ) else ''
 if 30 - 30: i1OOO
 OooOOOo0 = open ( i1iiIIiiI111 , mode = 'r' )
 O0O0o0o0o = file . read ( OooOOOo0 )
 file . close ( OooOOOo0 )
 oOooOOOOoo0O = re . compile ( 'date="(.+?)"' ) . findall ( O0O0o0o0o )
 iIi11ii1 = oOooOOOOoo0O [ 0 ] if ( len ( oOooOOOOoo0O ) > 0 ) else ''
 ooo0oo00O00Oo = re . compile ( 'version="(.+?)"' ) . findall ( O0O0o0o0o )
 OOO000000OOO0 = ooo0oo00O00Oo [ 0 ] if ( len ( ooo0oo00O00Oo ) > 0 ) else ''
 iI1i1IiIIIIi = open ( i1iiIII111ii , mode = 'r' )
 OooOooO0O0o0 = file . read ( iI1i1IiIIIIi )
 file . close ( iI1i1IiIIIIi )
 iII = re . compile ( 'id="(.+?)"' ) . findall ( OooOooO0O0o0 )
 O0oo = iII [ 0 ] if ( len ( iII ) > 0 ) else 'None'
 IIIIIiI = re . compile ( 'name="(.+?)"' ) . findall ( OooOooO0O0o0 )
 Oo0000O0OOooO = IIIIIiI [ 0 ] if ( len ( IIIIIiI ) > 0 ) else ''
 if int ( iIi11ii1 ) < int ( IIII1ii1 ) and ii1ii == 'true' :
  IiIiIIiii1I = O0O0o0o0o . replace ( iIi11ii1 , IIII1ii1 )
  iIi11i = open ( i1iiIIiiI111 , mode = 'w' )
  iIi11i . write ( str ( IiIiIIiii1I ) )
  iIi11i . close ( )
  yt . PlayVideo ( iiII , forcePlayer = True )
  xbmc . sleep ( 500 )
  while xbmc . Player ( ) . isPlaying ( ) :
   xbmc . sleep ( 500 )
 ii111 ( Oo0000O0OOooO , OOO000000OOO0 , O0oo )
 if 34 - 34: oO0o0ooo
 if 57 - 57: OOO00OoOO00 . Oo000o % OoOo
def iiIii1I ( ) :
 I1I11 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
 if os . path . exists ( I1I11 ) == True :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( I1I11 ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     try :
      os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
     except :
      pass
    for OOOoO000 in o0O0Oo00 :
     try :
      shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     except :
      pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  iI1i1iI1iI = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( iI1i1iI1iI ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
  I1IIiIi = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( I1IIiIi ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     if 93 - 93: Ooo0Oo0 - OOO00OoOO00 + OoOo . Ooo0Oo0 / oOOoO0O0O0
 o0000oO = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.module.simple.downloader' ) , '' )
 if os . path . exists ( o0000oO ) == True :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( o0000oO ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     if 83 - 83: iiiIi1i1I
 iii1IiiIiIIiI = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.image.music.slideshow/cache' ) , '' )
 if os . path . exists ( iii1IiiIiIIiI ) == True :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( iii1IiiIiIIiI ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     if 93 - 93: ooOO0o % iii11I111
 IiIIii = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache' ) , '' )
 if os . path . exists ( IiIIii ) == True :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( IiIIii ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     if 74 - 74: o0o0OOO0o0 / Oo000o
 O0Oo0Oo00o0o = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.itv/Images' ) , '' )
 if os . path . exists ( O0Oo0Oo00o0o ) == True :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( O0Oo0Oo00o0o ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     if 17 - 17: ooOO0o / OoOo . OOO00OoOO00 + OoOo / iii11I111 . iiIi
 iII11 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.navi-x/cache' ) , '' )
 if os . path . exists ( iII11 ) == True :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( iII11 ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     if 96 - 96: oOOoO0O0O0 * iii11I111 * Oo000o + iii11I111 % oO0o0ooo + i11iIiiIii
 i1iI11Ii1i = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.phstreams/Cache' ) , '' )
 if os . path . exists ( i1iI11Ii1i ) == True :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( i1iI11Ii1i ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     if 45 - 45: oO0o0ooo . iiIi . O0oO / Ooo0Oo0
 ii1iI11 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.audio.ramfm/cache' ) , '' )
 if os . path . exists ( ii1iI11 ) == True :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( ii1iI11 ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     if 87 - 87: Ooo0Oo0 * II11iII + Oo000o * i11iIiiIii % ooOO0o . IIII
 OO0Ii = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.whatthefurk/cache' ) , '' )
 if os . path . exists ( OO0Ii ) == True :
  for IiI1ii1Ii , o0O0Oo00 , O0Oo0o000oO in os . walk ( OO0Ii ) :
   oooOOOoOOOo0O = 0
   oooOOOoOOOo0O += len ( O0Oo0o000oO )
   if oooOOOoOOOo0O > 0 :
    for oOOOO in O0Oo0o000oO :
     os . unlink ( os . path . join ( IiI1ii1Ii , oOOOO ) )
    for OOOoO000 in o0O0Oo00 :
     shutil . rmtree ( os . path . join ( IiI1ii1Ii , OOOoO000 ) )
     if 55 - 55: Ooo0Oo0 / OoO0O00 . oO0o0ooo * O0oO % O0oO - OoOo
 try :
  o0o0O0oOooOo = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.genesis' ) , 'cache.db' )
  iI111ii1iIiI = database . connect ( o0o0O0oOooOo )
  OoO0oo0 = iI111ii1iIiI . cursor ( )
  OoO0oo0 . execute ( "DROP TABLE IF EXISTS rel_list" )
  OoO0oo0 . execute ( "VACUUM" )
  iI111ii1iIiI . commit ( )
  OoO0oo0 . execute ( "DROP TABLE IF EXISTS rel_lib" )
  OoO0oo0 . execute ( "VACUUM" )
  iI111ii1iIiI . commit ( )
 except :
  pass
  if 75 - 75: ii1I11II1ii1i . oO0o0ooo + OOO00OoOO00 - II11iII - IIIIII11i1I . oOOoO0O0O0
  if 19 - 19: Oo000o * o0O0 % IIIIII11i1I + oOOoO0O0O0
def I1i1ii1ii ( ) :
 iIiII1 = xbmc . translatePath ( os . path . join ( oO0o0o0ooO0oO , 'Community Builds' , 'My Builds' ) )
 II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( "ABSOLUTELY CERTAIN?!!!" , 'Are you absolutely certain you want to wipe?' , '' , 'All addons and settings will be completely wiped!' , yeslabel = 'Yes' , nolabel = 'No' )
 if II1Ii1iI1i1 == 1 :
  if iI111I11I1I1 != "skin.confluence" :
   Oo0O . ok ( '[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]' , 'Please switch to the default Confluence skin' , 'before performing a wipe.' , '' )
   xbmc . executebuiltin ( "ActivateWindow(appearancesettings)" )
   return
  else :
   II1Ii1iI1i1 = xbmcgui . Dialog ( ) . yesno ( "VERY IMPORTANT" , 'This will completely wipe your install.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'No' , nolabel = 'Yes' )
   if II1Ii1iI1i1 == 0 :
    if not os . path . exists ( iIiII1 ) :
     os . makedirs ( iIiII1 )
    oOooOo00OooO0oO = I1IIi ( heading = "Enter a name for this backup" )
    if ( not oOooOo00OooO0oO ) : return False , 0
    O0OOOo = urllib . quote_plus ( oOooOo00OooO0oO )
    i11I1I1iiI = xbmc . translatePath ( os . path . join ( iIiII1 , O0OOOo + '.zip' ) )
    I1i1iii1Ii = [ 'plugin.program.TBS' , 'service.TBS.update' ]
    iI = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' ]
    iii1 = "Creating full backup of existing build"
    II1iIi1IiIii = "Archiving..."
    I111I11I111 = ""
    iiiiI11ii = "Please Wait"
    iI1iIIIi1i ( ooOo , i11I1I1iiI , iii1 , II1iIi1IiIii , I111I11I111 , iiiiI11ii , I1i1iii1Ii , iI )
    Ii1iiI1i1 ( )
    i1ii = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , O0O0OO0O0O0 , '' ) )
    oOOOOO0 = xbmc . translatePath ( os . path . join ( ooOo , '..' , 'TBS.zip' ) )
    oOOo000oOoO0 ( i1ii , oOOOOO0 )
    IIi1I1 = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , 'script.module.addon.common' , '' ) )
    oO00o0oOoo = xbmc . translatePath ( os . path . join ( ooOo , '..' , 'TBSdep.zip' ) )
    oOOo000oOoO0 ( IIi1I1 , oO00o0oOoo )
    oOOI1 = xbmc . translatePath ( os . path . join ( iiIIIII1i1iI , 'service.TBS.update' , '' ) )
    OOI1i = xbmc . translatePath ( os . path . join ( ooOo , '..' , 'TBSserv.zip' ) )
    oOOo000oOoO0 ( IIi1I1 , oO00o0oOoo )
    i1II1iII1 = xbmc . translatePath ( os . path . join ( iI1Ii11111iIi , 'plugin.program.TBS' , '' ) )
    I11II11IiI11 = xbmc . translatePath ( os . path . join ( ooOo , '..' , 'TBSdata.zip' ) )
    oOOo000oOoO0 ( i1II1iII1 , I11II11IiI11 )
    iiIIi ( ooOo )
    if not os . path . exists ( i1ii ) :
     os . makedirs ( i1ii )
    if not os . path . exists ( IIi1I1 ) :
     os . makedirs ( IIi1I1 )
    if not os . path . exists ( oOOI1 ) :
     os . makedirs ( oOOI1 )
    if not os . path . exists ( i1II1iII1 ) :
     os . makedirs ( i1II1iII1 )
    time . sleep ( 1 )
    ii1i ( oOOOOO0 )
    IiI . create ( "Restoring TBS add-on" , "Checking " , '' , 'Please Wait' )
    IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
    extract . all ( oOOOOO0 , i1ii , IiI )
    ii1i ( oO00o0oOoo )
    extract . all ( oO00o0oOoo , IIi1I1 , IiI )
    IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
    ii1i ( OOI1i )
    extract . all ( OOI1i , oOOI1 , IiI )
    IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
    ii1i ( I11II11IiI11 )
    extract . all ( I11II11IiI11 , i1II1iII1 , IiI )
    IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
    IiI . close ( )
    time . sleep ( 1 )
    ooOoOOoooO000 ( )
   else : return
   if 97 - 97: i1OOO / o0o0OOO0o0 % i1OOO / oO0o0ooo * OoO0O00 % II11iII
   if 17 - 17: o0o0OOO0o0
def ooi11I ( ) :
 Ii ( '' , 'Clear Cache' , 'url' , 'clear_cache' , 'Clear_Cache.png' , '' , '' , '' )
 Ii ( '' , 'Clear My Cached Artwork' , 'none' , 'remove_textures' , 'Delete_Cached_Artwork.png' , '' , '' , '' )
 Ii ( '' , 'Delete Addon_Data' , 'url' , 'remove_addon_data' , 'Delete_Addon_Data.png' , '' , '' , '' )
 Ii ( '' , 'Delete Old Builds/Zips From Device' , 'url' , 'remove_build' , 'Delete_Builds.png' , '' , '' , '' )
 Ii ( '' , 'Delete Old Crash Logs' , 'url' , 'remove_crash_logs' , 'Delete_Crash_Logs.png' , '' , '' , '' )
 Ii ( '' , 'Delete Packages Folder' , 'url' , 'remove_packages' , 'Delete_Packages.png' , '' , '' , '' )
 Ii ( '' , 'Wipe My Install (Fresh Start)' , 'none' , 'wipe_xbmc' , 'Fresh_Start.png' , '' , '' , '' )
 if 48 - 48: OOO00OoOO00 + O0oO % OOO00OoOO00
 if 84 - 84: IIIIII11i1I % Oo000o . Oo000o . OoO0O00 * oOOoO0O0O0
def iIOO0O ( url ) :
 Ii ( 'folder' , '[COLOR=yellow]1. Install[/COLOR]' , str ( url ) + '&tags=Install&XBMC=1' , 'grab_tutorials' , 'Install.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=lime]2. Settings[/COLOR]' , str ( url ) + '&tags=Settings' , 'grab_tutorials' , 'Settings.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=orange]3. Add-ons[/COLOR]' , str ( url ) , 'tutorial_addon_menu' , 'Addons.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Audio' , str ( url ) + '&tags=Audio' , 'grab_tutorials' , 'Audio.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Errors' , str ( url ) + '&tags=Errors' , 'grab_tutorials' , 'Errors.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Gaming' , str ( url ) + '&tags=Gaming' , 'grab_tutorials' , 'gaming_portal.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  LiveTV' , str ( url ) + '&tags=LiveTV' , 'grab_tutorials' , 'LiveTV.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Maintenance' , str ( url ) + '&tags=Maintenance' , 'grab_tutorials' , 'Maintenance.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Pictures' , str ( url ) + '&tags=Pictures' , 'grab_tutorials' , 'Pictures.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Profiles' , str ( url ) + '&tags=Profiles' , 'grab_tutorials' , 'Profiles.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Skins' , str ( url ) + '&tags=Skins' , 'grab_tutorials' , 'Skin.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Video' , str ( url ) + '&tags=Video' , 'grab_tutorials' , 'Video.png' , '' , '' , '' )
 Ii ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Weather' , str ( url ) + '&tags=Weather' , 'grab_tutorials' , 'Weather.png' , '' , '' , '' )
 if 34 - 34: Oo000o - Ooo0Oo0 * IIII . iiiIi1i1I / oO0o0ooo
 if 66 - 66: iiIi / i11iIiiIii % i1OOO
def i1Ii1i11ii ( url ) :
 oo0oO = xbmc . getInfoLabel ( "System.BuildVersion" )
 i1i1iI1iiiI = float ( oo0oO [ : 4 ] )
 if i1i1iI1iiiI < 14 :
  oO0O0oo = 'You are running XBMC'
 else :
  oO0O0oo = 'You are running Kodi'
 Oo0O = xbmcgui . Dialog ( )
 Oo0O . ok ( oO0O0oo , "Your version is: %s" % i1i1iI1iiiI )
 if 64 - 64: II11iII % II11iII + OoOo + iiIi
 if 79 - 79: iiIi - IIII % O0oO + IIII - oOOoO0O0O0 % II11iII
iiIiII11i1 = I1iIII1IiiI ( )
i1I1i111Ii = None
oO0ooOO = None
ooO0000o00O = None
IIi1iI1 = None
iIIOOo0O = None
OO00oO0OoO0o = None
IIII1 = None
II1iiiiI1 = None
oo000 = None
Oo0oo0O0o00O = None
OO0ooo0oOO = None
IIiIi1iI = None
i1iiiIi1Iii = None
oooOOoo = None
iiOo0ooo = None
I1II1 = None
IiiIiiIIII = None
O0Ooo = None
ooo = None
I1i11 = None
Oo00o00 = None
OO0ooo0o0 = None
IIiIIIIii = None
iiIiIIIiiI = None
iI1iii1iIiiI = None
ooo0oOOO0 = None
i1i1iI1iiiI = None
oO00o0 = None
oO0ooOoO = None
IiIII = None
OoOo0O0 = None
if 39 - 39: O0oO . iiiIi1i1I % i1OOO . OOO00OoOO00 / OoO0O00 * iiiIi1i1I
try : i1I1i111Ii = urllib . unquote_plus ( iiIiII11i1 [ "addon_id" ] )
except : pass
try : iIiI1 = urllib . unquote_plus ( iiIiII11i1 [ "adult" ] )
except : pass
try : oO0ooOO = urllib . unquote_plus ( iiIiII11i1 [ "artpack" ] )
except : pass
try : ooO0000o00O = urllib . unquote_plus ( iiIiII11i1 [ "audioaddons" ] )
except : pass
try : IIi1iI1 = urllib . unquote_plus ( iiIiII11i1 [ "author" ] )
except : pass
try : iIIOOo0O = urllib . unquote_plus ( iiIiII11i1 [ "buildname" ] )
except : pass
try : OO00oO0OoO0o = urllib . unquote_plus ( iiIiII11i1 [ "data_path" ] )
except : pass
try : IIII1 = urllib . unquote_plus ( iiIiII11i1 [ "description" ] )
except : pass
try : II1iiiiI1 = urllib . unquote_plus ( iiIiII11i1 [ "email" ] )
except : pass
try : oo000 = urllib . unquote_plus ( iiIiII11i1 [ "fanart" ] )
except : pass
try : Oo0oo0O0o00O = urllib . unquote_plus ( iiIiII11i1 [ "forum" ] )
except : pass
try : iIIiI1ii = urllib . unquote_plus ( iiIiII11i1 [ "guisettingslink" ] )
except : pass
try : OO0ooo0oOO = urllib . unquote_plus ( iiIiII11i1 [ "iconimage" ] )
except : pass
try : IIiIi1iI = urllib . unquote_plus ( iiIiII11i1 [ "link" ] )
except : pass
try : i1iiiIi1Iii = urllib . unquote_plus ( iiIiII11i1 [ "local" ] )
except : pass
try : oooOOoo = urllib . unquote_plus ( iiIiII11i1 [ "messages" ] )
except : pass
try : iiOo0ooo = str ( iiIiII11i1 [ "mode" ] )
except : pass
try : I1II1 = urllib . unquote_plus ( iiIiII11i1 [ "name" ] )
except : pass
try : oO00oOOo0Oo = urllib . unquote_plus ( iiIiII11i1 [ "pictureaddons" ] )
except : pass
try : IiiIiiIIII = urllib . unquote_plus ( iiIiII11i1 [ "posts" ] )
except : pass
try : O0Ooo = urllib . unquote_plus ( iiIiII11i1 [ "programaddons" ] )
except : pass
try : ooo = urllib . unquote_plus ( iiIiII11i1 [ "provider_name" ] )
except : pass
try : Oo00o00 = urllib . unquote_plus ( iiIiII11i1 [ "repo_link" ] )
except : pass
try : I1i11 = urllib . unquote_plus ( iiIiII11i1 [ "repo_id" ] )
except : pass
try : OO0ooo0o0 = urllib . unquote_plus ( iiIiII11i1 [ "skins" ] )
except : pass
try : IIiIIIIii = urllib . unquote_plus ( iiIiII11i1 [ "sources" ] )
except : pass
try : iiIiIIIiiI = urllib . unquote_plus ( iiIiII11i1 [ "updated" ] )
except : pass
try : iI1iii1iIiiI = urllib . unquote_plus ( iiIiII11i1 [ "unread" ] )
except : pass
try : ooo0oOOO0 = urllib . unquote_plus ( iiIiII11i1 [ "url" ] )
except : pass
try : i1i1iI1iiiI = urllib . unquote_plus ( iiIiII11i1 [ "version" ] )
except : pass
try : oO00o0 = urllib . unquote_plus ( iiIiII11i1 [ "video" ] )
except : pass
try : oO0ooOoO = urllib . unquote_plus ( iiIiII11i1 [ "videoaddons" ] )
except : pass
try : IiIII = urllib . unquote_plus ( iiIiII11i1 [ "welcometext" ] )
except : pass
try : OoOo0O0 = urllib . unquote_plus ( iiIiII11i1 [ "zip_link" ] )
except : pass
if 12 - 12: oO0o0ooo / OoOo
if iiOo0ooo == None and IiIi11iIIi1Ii == 'true' : o0oo00oo0oO ( )
elif iiOo0ooo == None : Ii1IiI1i1ii ( '' , '' , '' , '' )
elif iiOo0ooo == 'addon_final_menu' : OOOOoOoo0O0O0 ( ooo0oOOO0 )
elif iiOo0ooo == 'addon_categories' : III1iII1I1ii ( )
elif iiOo0ooo == 'addon_countries' : iIIi1i1 ( )
elif iiOo0ooo == 'addon_genres' : iIi1Ii1i1iI ( )
elif iiOo0ooo == 'addon_install' : ii111IiiI1 ( I1II1 , OoOo0O0 , Oo00o00 , I1i11 , i1I1i111Ii , ooo , Oo0oo0O0o00O , OO00oO0OoO0o )
elif iiOo0ooo == 'addon_removal_menu' : OoOoOo00o0 ( )
elif iiOo0ooo == 'addonfix' : OoO00o0 ( )
elif iiOo0ooo == 'addonfixes' : II1i ( )
elif iiOo0ooo == 'addonmenu' : i1iiIiI1Ii1i ( )
elif iiOo0ooo == 'addon_settings' : i1iiiii1 ( )
elif iiOo0ooo == 'backup' : BACKUP ( )
elif iiOo0ooo == 'backup_option' : iiI11I ( )
elif iiOo0ooo == 'backup_restore' : O0O0oOOo0O ( )
elif iiOo0ooo == 'categories' : Ii1IiI1i1ii ( )
elif iiOo0ooo == 'check_storage' : OOOooo0OooOoO ( )
elif iiOo0ooo == 'clear_cache' : OOoOOo0O00O ( )
elif iiOo0ooo == 'community' : OoO ( )
elif iiOo0ooo == 'community_backup' : IiIIi1IiiI1 ( )
elif iiOo0ooo == 'community_menu' : i1ii1111i1i ( ooo0oOOO0 , oO00o0 )
elif iiOo0ooo == 'countries' : i1ii11 ( ooo0oOOO0 )
elif iiOo0ooo == 'description' : iiii111IiIIi1 ( I1II1 , ooo0oOOO0 , iIIOOo0O , IIi1iI1 , i1i1iI1iiiI , IIII1 , iiIiIIIiiI , OO0ooo0o0 , oO0ooOoO , ooO0000o00O , O0Ooo , oO00oOOo0Oo , IIiIIIIii , iIiI1 )
elif iiOo0ooo == 'fix_special' : o00o ( ooo0oOOO0 )
elif iiOo0ooo == 'genres' : OoO0o0000O ( ooo0oOOO0 )
elif iiOo0ooo == 'gotham' : IiIi1i ( )
elif iiOo0ooo == 'grab_addons' : I1ii1 ( ooo0oOOO0 )
elif iiOo0ooo == 'grab_builds' : iii ( ooo0oOOO0 )
elif iiOo0ooo == 'grab_builds_premium' : Grab_Builds_Premium ( ooo0oOOO0 )
elif iiOo0ooo == 'grab_hardware' : OOo0OOoO00o0 ( ooo0oOOO0 )
elif iiOo0ooo == 'grab_news' : ooIII1II1iii1i ( ooo0oOOO0 )
elif iiOo0ooo == 'grab_tutorials' : O0o00oO0oOO ( ooo0oOOO0 )
elif iiOo0ooo == 'guisettingsfix' : iiiO0 ( ooo0oOOO0 , i1iiiIi1Iii )
elif iiOo0ooo == 'hardware_filter_menu' : Oo000OoOO ( ooo0oOOO0 )
elif iiOo0ooo == 'hardware_final_menu' : oO0o0o00oOo0O ( ooo0oOOO0 )
elif iiOo0ooo == 'hardware_root_menu' : ooo0O00000oo0 ( )
elif iiOo0ooo == 'helix' : II11iiii ( )
elif iiOo0ooo == 'hide_passwords' : iIII1iIi ( )
elif iiOo0ooo == 'ipcheck' : ii1iiIi ( )
elif iiOo0ooo == 'instructions' : I111 ( )
elif iiOo0ooo == 'instructions_1' : iiIiII ( )
elif iiOo0ooo == 'instructions_2' : IIIIIIi ( )
elif iiOo0ooo == 'instructions_3' : OooO0O0Ooo ( )
elif iiOo0ooo == 'instructions_4' : Instructions_4 ( )
elif iiOo0ooo == 'instructions_5' : Instructions_5 ( )
elif iiOo0ooo == 'instructions_6' : Instructions_6 ( )
elif iiOo0ooo == 'LocalGUIDialog' : III1ii ( )
elif iiOo0ooo == 'log' : iIIiI11iI1Ii1 ( )
elif iiOo0ooo == 'manual_search' : iIiI1i111ii ( ooo0oOOO0 )
elif iiOo0ooo == 'manual_search_builds' : Manual_Search_Builds ( )
elif iiOo0ooo == 'news_root_menu' : oOo0O000Ooo0 ( ooo0oOOO0 )
elif iiOo0ooo == 'news_menu' : I1iI11IiiI11i ( ooo0oOOO0 )
elif iiOo0ooo == 'notify_msg' : IiiI1I ( ooo0oOOO0 )
elif iiOo0ooo == 'OSS' : Oo0OO00OO0Oo ( I1II1 , ooo0oOOO0 , OO0ooo0oOO , IIII1 )
elif iiOo0ooo == 'play_video' : yt . PlayVideo ( ooo0oOOO0 )
elif iiOo0ooo == 'platform_menu' : OooIii1I1iI ( ooo0oOOO0 )
elif iiOo0ooo == 'popular' : i11iiI ( )
elif iiOo0ooo == 'popularwizard' : o0O00OooooO ( I1II1 , ooo0oOOO0 , OO0ooo0oOO , IIII1 )
elif iiOo0ooo == 'register' : o0oo0Oo ( )
elif iiOo0ooo == 'remove_addon_data' : ooO0o0oO0 ( )
elif iiOo0ooo == 'remove_addons' : o0o0ooOo00 ( ooo0oOOO0 )
elif iiOo0ooo == 'remove_build' : oOoo0Ooooo ( )
elif iiOo0ooo == 'remove_crash_logs' : I1iii1 ( )
elif iiOo0ooo == 'remove_packages' : OOo00Oooo ( )
elif iiOo0ooo == 'remove_textures' : i1I11iIiII ( )
elif iiOo0ooo == 'restore' : RESTORE ( )
elif iiOo0ooo == 'restore_backup' : ii1iIII1ii ( I1II1 , ooo0oOOO0 , IIII1 )
elif iiOo0ooo == 'restore_local_CB' : OooOo0o0OO ( )
elif iiOo0ooo == 'restore_local_gui' : iII1ii ( )
elif iiOo0ooo == 'restore_option' : ii11I11 ( )
elif iiOo0ooo == 'restore_zip' : iiII1IIii1i1 ( ooo0oOOO0 )
elif iiOo0ooo == 'restore_community' : oO00oO00O0Oo ( I1II1 , ooo0oOOO0 , oO00o0 , IIII1 , OO0ooo0o0 , iIIiI1ii , oO0ooOO )
elif iiOo0ooo == 'runtest' : Ii11I1I11II ( ooo0oOOO0 )
elif iiOo0ooo == 'search_addons' : OooOo ( ooo0oOOO0 )
elif iiOo0ooo == 'search_builds' : O0oooo0O ( ooo0oOOO0 )
elif iiOo0ooo == 'Search_Private' : Private_Search ( ooo0oOOO0 )
elif iiOo0ooo == 'showinfo' : Oo0Oo ( ooo0oOOO0 )
elif iiOo0ooo == 'SortBy' : o0IIIIiI11I ( BuildURL , type )
elif iiOo0ooo == 'speed_instructions' : oo0O ( )
elif iiOo0ooo == 'speedtest_menu' : ooOoo ( )
elif iiOo0ooo == 'text_guide' : II1I1iIIiIIii ( I1II1 , ooo0oOOO0 )
elif iiOo0ooo == 'tools' : o0OOOO ( )
elif iiOo0ooo == 'tutorial_final_menu' : I1i11IIIi ( ooo0oOOO0 )
elif iiOo0ooo == 'tutorial_addon_menu' : I11i1i11IiIi1 ( ooo0oOOO0 )
elif iiOo0ooo == 'tutorial_root_menu' : I1iIIIiiii ( )
elif iiOo0ooo == 'unhide_passwords' : oO0oOooO00oo ( )
elif iiOo0ooo == 'update' : iiiI1IiI ( )
elif iiOo0ooo == 'uploadlog' : OOooooO ( )
elif iiOo0ooo == 'user_info' : oOoO000 ( )
elif iiOo0ooo == 'wipetools' : ooi11I ( )
elif iiOo0ooo == 'xbmc_menu' : iIOO0O ( ooo0oOOO0 )
elif iiOo0ooo == 'xbmcversion' : i1Ii1i11ii ( ooo0oOOO0 )
elif iiOo0ooo == 'wipe_xbmc' : I1i1ii1ii ( )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
