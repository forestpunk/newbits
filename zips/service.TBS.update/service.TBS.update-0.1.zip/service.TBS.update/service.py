import urllib , urllib2 , re , xbmcplugin , xbmcgui , xbmc , xbmcaddon , os , sys , time , xbmcvfs
import shutil
import time
if 64 - 64: i11iIiiIii
OO0o = xbmcgui . Dialog ( )
Oo0Ooo = xbmcgui . DialogProgress ( )
O0O0OO0O0O0 = xbmcaddon . Addon ( id = 'plugin.program.TBS' )
iiiii = 'plugin.program.TBS'
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
II1 = '/storage/backup/'
O00ooooo00 = os . path . join ( II1 , 'addon_data' , '' )
I1IiiI = os . path . join ( II1 , 'cache' , '' )
IIi1IiiiI1Ii = [ "plugin.video.genesis" , "script.tvguidedixie" ]
I11i11Ii = '/storage/.cache/'
oO00oOo = xbmc . translatePath ( 'special://home/userdata/firstrun/' )
OOOo0 = O0O0OO0O0O0 . getSetting ( 'resellername' )
Oooo000o = O0O0OO0O0O0 . getSetting ( 'internetcheck' )
IiIi11iIIi1Ii = O0O0OO0O0O0 . getSetting ( 'notifycheck' )
Oo0O = O0O0OO0O0O0 . getSetting ( 'cbnotifycheck' )
IiI = xbmc . translatePath ( os . path . join ( ooo0OO , iiiii , 'id.xml' ) )
#xbmc.sleep(20) #Give time for other services to complete initial run so we can then start removing files.
def ooOo ( ) :
 Oo = xbmc . getInfoLabel ( 'Network.IPAddress' )
 o0O = xbmc . Player ( ) . isPlaying ( )
 if Oo == '' and o0O == 0 :
  OO0o . ok ( "NOT CONNECTED" , 'This device is not connected to the internet' , 'Please check your Wi-Fi settings or make sure' , 'the ethernet cable is plugged in.' )
  if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
def O0oOO0o0 ( ) :
 print "#### Box Seller Service - CHECK FOR NOTIFICATION ###"
 o0O = xbmc . Player ( ) . isPlaying ( )
 if o0O == 0 :
  i1ii1iIII = xbmc . translatePath ( os . path . join ( ooo0OO , 'plugin.program.TBS' , 'tbsnotification.txt' ) )
  if not os . path . exists ( i1ii1iIII ) :
   Oo0oO0oo0oO00 = open ( i1ii1iIII , mode = 'w' )
   Oo0oO0oo0oO00 . write ( '20150101000000' )
   Oo0oO0oo0oO00 . close ( )
  i111I = open ( i1ii1iIII , 'r' ) . read ( )
  II1Ii1iI1i = 'http://totalxbmc.com/totalrevolution/Community_Builds/notify?reseller=%s' % ( OOOo0 )
  iiI1iIiI = OOo ( II1Ii1iI1i ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  Ii1IIii11 = re . compile ( 'notify="(.+?)"' ) . findall ( iiI1iIiI )
  Oooo0000 = Ii1IIii11 [ 0 ] if ( len ( Ii1IIii11 ) > 0 ) else 'No news items available'
  i11 = re . compile ( 'date="(.+?)"' ) . findall ( iiI1iIiI )
  I11 = i11 [ 0 ] if ( len ( i11 ) > 0 ) else '10000000000000'
  Oo0o0000o0o0 = I11 . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' )
  if int ( i111I ) < int ( Oo0o0000o0o0 ) :
   print "New Notification Message from " + OOOo0
   OO0o . ok ( 'Update From ' + OOOo0 , Oooo0000 )
   Oo0oO0oo0oO00 = open ( i1ii1iIII , mode = 'w' )
   Oo0oO0oo0oO00 . write ( Oo0o0000o0o0 )
   Oo0oO0oo0oO00 . close ( )
  else :
   pass
   if 86 - 86: iiiii11iII1 % O0o
def oO0 ( ) :
 print "#### Box Seller Service - CHECK FOR CB Notification ###"
 if IIIi1i1I != 'None' :
  o0O = xbmc . Player ( ) . isPlaying ( )
  if o0O == 0 :
   OOoOoo00oo = xbmc . translatePath ( os . path . join ( ooo0OO , 'plugin.program.TBS' , 'notification.txt' ) )
   if not os . path . exists ( OOoOoo00oo ) :
    Oo0oO0oo0oO00 = open ( OOoOoo00oo , mode = 'w' )
    Oo0oO0oo0oO00 . write ( '20150101000000' )
    Oo0oO0oo0oO00 . close ( )
   i111I = open ( OOoOoo00oo , 'r' ) . read ( )
   II1Ii1iI1i = 'http://totalxbmc.com/totalrevolution/Community_Builds/notify?id=%s' % ( IIIi1i1I )
   iiI1iIiI = OOo ( II1Ii1iI1i ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
   Ii1IIii11 = re . compile ( 'notify="(.+?)"' ) . findall ( iiI1iIiI )
   Oooo0000 = Ii1IIii11 [ 0 ] if ( len ( Ii1IIii11 ) > 0 ) else 'No news items available'
   i11 = re . compile ( 'date="(.+?)"' ) . findall ( iiI1iIiI )
   I11 = i11 [ 0 ] if ( len ( i11 ) > 0 ) else '10000000000000'
   Oo0o0000o0o0 = I11 . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' )
   if int ( i111I ) < int ( Oo0o0000o0o0 ) :
    print "New CB Notification Message"
    OO0o . ok ( 'Community Build Update' , Oooo0000 )
    Oo0oO0oo0oO00 = open ( OOoOoo00oo , mode = 'w' )
    Oo0oO0oo0oO00 . write ( Oo0o0000o0o0 )
    Oo0oO0oo0oO00 . close ( )
   else :
    pass
    if 41 - 41: i11IiIiiIIIII / IiiIII111ii / i1iIIi1
def ii11iIi1I ( ) :
 xbmc . sleep ( 30000 )
 ooOo ( )
 if Oo0O == 'true' :
  iI111I11I1I1 = 1
  while iI111I11I1I1 < 11 :
   xbmc . sleep ( 30000 )
   ooOo ( )
   iI111I11I1I1 += 1
   if iI111I11I1I1 == 10 :
    try : oO0 ( )
    except : pass
    iI111I11I1I1 = 1
    if 55 - 55: iI1I % iiiIi - OO / i1I111I - I1I1IIiiIiI1 . iiIiIIi
def ooOoo0O ( ) :
 xbmc . sleep ( 5000 )
 try : O0oOO0o0 ( )
 except : pass
 xbmc . sleep ( 5000 )
 try : oO0 ( )
 except : pass
 xbmc . sleep ( 300000 )
 ooOoo0O ( )
 if 76 - 76: i1II1I11 / i1I / OO0oOoo / OO0oOoo % O0o
def oOo00Oo00O ( ) :
 xbmc . sleep ( 20000 )
 try : O0oOO0o0 ( )
 except : pass
 xbmc . sleep ( 5000 )
 try : oO0 ( )
 except : pass
 iI111I11I1I1 = 1
 while iI111I11I1I1 < 11 :
  xbmc . sleep ( 30000 )
  ooOo ( )
  iI111I11I1I1 += 1
  if iI111I11I1I1 == 10 :
   try : O0oOO0o0 ( )
   except : pass
   if Oo0O == 'true' :
    xbmc . sleep ( 5000 )
    try : oO0 ( )
    except : pass
   iI111I11I1I1 = 1
   if 43 - 43: iiiii11iII1 - iiIiIIi * IiII
def OOo ( url ) :
 O0O00o0OOO0 = urllib2 . Request ( url )
 O0O00o0OOO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 Ii1iIIIi1ii = urllib2 . urlopen ( O0O00o0OOO0 )
 iiI1iIiI = Ii1iIIIi1ii . read ( )
 Ii1iIIIi1ii . close ( )
 return iiI1iIiI . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
 if 80 - 80: i1I111I * i11iIiiIii / i1I
print "###### TBS Update Service ######"
if not os . path . exists ( IiI ) :
 Oo0oO0oo0oO00 = open ( IiI , mode = 'w+' )
 Oo0oO0oo0oO00 . write ( 'id="None"\nname="None"' )
 Oo0oO0oo0oO00 . close ( )
Oo0oO0oo0oO00 = open ( IiI , mode = 'r' )
I11II1i = file . read ( Oo0oO0oo0oO00 )
file . close ( Oo0oO0oo0oO00 )
IIIII = re . compile ( 'id="(.+?)"' ) . findall ( I11II1i )
IIIi1i1I = IIIII [ 0 ] if ( len ( IIIII ) > 0 ) else 'None'
if not os . path . exists ( oO00oOo ) and OOOo0 != '' :
 xbmc . sleep ( 2000 )
 Oo = xbmc . getInfoLabel ( 'Network.IPAddress' )
 o0O = xbmc . Player ( ) . isPlaying ( )
 if not os . path . exists ( oO00oOo ) and Oo != '' and o0O == 0 :
  ooooooO0oo = OO0o . yesno ( "Install Packs Available" , '[COLOR=yellow]Would you like to view the packs available on this device?[/COLOR]' , '[COLOR=lime]IMPORTANT:[/COLOR] Packs may contain add-ons offering access to' , 'content deemed unlawful in your country. Please check your local laws before installing.' )
  if ooooooO0oo == 1 :
   os . makedirs ( oO00oOo )
   xbmc . executebuiltin ( 'ActivateWindow(10001,"plugin://plugin.program.TBS/?mode=community",return)' )
  if ooooooO0oo == 0 :
   OO0o . ok ( 'Vanilla Setup' , 'You now have a vanilla Kodi setup, a complete blank' , 'canvas to create to your own taste. If you wish to install' , 'any content you can still find it in the [COLOR=lime]TotalBoxShop[/COLOR] add-on.' )
   os . makedirs ( oO00oOo )
if Oooo000o == 'true' and IiIi11iIIi1Ii == 'false' :
 ii11iIi1I ( )
if IiIi11iIIi1Ii == 'true' and Oooo000o == 'false' :
 ooOoo0O ( )
if IiIi11iIIi1Ii == 'true' and Oooo000o == 'true' :
 oOo00Oo00O ( )
else : pass
if 49 - 49: i1iIIi1 * IiII / ooOoO0o / i11iIiiIii / i1iIIi1
if 28 - 28: OO - i1II1I11 . i1II1I11 + IiiIII111ii - I1Ii111 + iII111i
if 95 - 95: i11IiIiiIIIII % iiiIi . iII111i
if 15 - 15: OO0oOoo / I1I1IIiiIiI1 . I1I1IIiiIiI1 - ooOoO0o
if 53 - 53: i1II1I11 + iiiii11iII1 * iiiIi
if 61 - 61: ooOoO0o * OO / I1Ii111 . i11iIiiIii . IiiIII111ii
if 60 - 60: i1I111I / i1I111I
if 46 - 46: I1I1IIiiIiI1 * OO - i11IiIiiIIIII * iiiIi - i1I
if 83 - 83: I1Ii111
if 31 - 31: o00O0oo - OO . i1I % IiiIII111ii - iII111i
if 4 - 4: o00O0oo / OO0oOoo . iiIiIIi
if 58 - 58: OO * i11iIiiIii / IiiIII111ii % i1I - iI1I / iiiIi
if 50 - 50: iiiii11iII1
if 34 - 34: iiiii11iII1 * o00O0oo % iiIiIIi * IiiIII111ii - iiiii11iII1
if 33 - 33: i1iIIi1 + OO * i11IiIiiIIIII - O0o / iiiIi % I1I1IIiiIiI1
if 21 - 21: i11IiIiiIIIII * IiII % iiiIi * ooOoO0o
if 16 - 16: iII111i - i1I * IiII + iiIiIIi
if 50 - 50: o00O0oo - OO0oOoo * iI1I / i1I + i1iIIi1
if 88 - 88: I1I1IIiiIiI1 / i1I + iiIiIIi - o00O0oo / OO0oOoo - IiiIII111ii
if 15 - 15: iI1I + IiiIII111ii - I1Ii111 / OO
if 58 - 58: i11iIiiIii % i1I111I
if 71 - 71: OO + OO0oOoo % i11iIiiIii + iI1I - i1II1I11
if 88 - 88: IiiIII111ii - i11IiIiiIIIII % OO
if 16 - 16: iiiii11iII1 * iiiIi % i1II1I11
if 86 - 86: iiiii11iII1 + I1I1IIiiIiI1 % i11iIiiIii * iiiIi . OO0oOoo * i1I111I
if 44 - 44: iiiIi
if 88 - 88: i1I % I1I1IIiiIiI1 . o00O0oo
if 38 - 38: i1iIIi1
if 57 - 57: iII111i / iiiIi * i1I / IiiIII111ii . o00O0oo
if 26 - 26: iiIiIIi
if 91 - 91: i11IiIiiIIIII . iI1I + i11IiIiiIIIII - iiIiIIi / I1Ii111
if 39 - 39: iI1I / OO0oOoo - o00O0oo
if 98 - 98: iI1I / i1I111I % iiiIi . IiiIII111ii
if 91 - 91: iiiIi % O0o
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
